import CoreGraphics
import Foundation
import ImageIO

let size = 1024
let side = CGFloat(size)

let space = CGColorSpaceCreateDeviceRGB()
guard let ctx = CGContext(
    data: nil, width: size, height: size,
    bitsPerComponent: 8, bytesPerRow: 0, space: space,
    // 用 noneSkipLast（不透明 RGBX）而不是 premultipliedLast（RGBA）：
    // App Store 会拒收带 alpha 通道的 1024×1024 图标
    // （"can't be transparent nor contain an alpha channel"）。
    // 本图是全幅渐变背景、没有任何透明区域，直接以不透明格式渲染即可，
    // 顺带省下约 25% 体积。
    bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue
) else { fatalError("无法创建绘图上下文") }

func rgb(_ hex: UInt32, _ a: CGFloat = 1) -> CGColor {
    CGColor(srgbRed: CGFloat((hex >> 16) & 0xFF) / 255,
            green: CGFloat((hex >> 8) & 0xFF) / 255,
            blue: CGFloat(hex & 0xFF) / 255,
            alpha: a)
}

// ── 背景：靛蓝 → 紫罗兰对角渐变 ──
let bgColors = [rgb(0x3B2FA8), rgb(0x5B34C4), rgb(0x8B4FD0)] as CFArray
let bg = CGGradient(colorsSpace: space, colors: bgColors, locations: [0, 0.55, 1])!
ctx.drawLinearGradient(bg,
                       start: CGPoint(x: 0, y: side),
                       end: CGPoint(x: side, y: 0),
                       options: [])

// ── 调色盘本体（白色，带拇指孔，用 evenOdd 挖空）──
let paletteCenter = CGPoint(x: side * 0.50, y: side * 0.545)
let paletteRadius = side * 0.315
let holeCenter = CGPoint(x: side * 0.375, y: side * 0.375)
let holeRadius = side * 0.085

let palette = CGMutablePath()
palette.addEllipse(in: CGRect(x: paletteCenter.x - paletteRadius, y: paletteCenter.y - paletteRadius,
                              width: paletteRadius * 2, height: paletteRadius * 2))
palette.addEllipse(in: CGRect(x: holeCenter.x - holeRadius, y: holeCenter.y - holeRadius,
                              width: holeRadius * 2, height: holeRadius * 2))
ctx.saveGState()
ctx.addPath(palette)
ctx.setFillColor(rgb(0xFFFFFF, 0.96))
ctx.fillPath(using: .evenOdd)
ctx.restoreGState()

// ── 颜料格：沿调色盘内圈排布，用工程里真实的分类色 ──
let pigments: [(UInt32, Double)] = [
    (0xD6303A, 155),  // 红
    (0xF08030, 118),  // 橙
    (0xF2C200,  80),  // 黄
    (0x3E9B4F,  42),  // 绿
    (0x2E5BFF,   4),  // 蓝
    (0x7B4FA8, -34),  // 紫
]
let wellOrbit = paletteRadius * 0.62
let wellRadius = side * 0.058

for (hex, degrees) in pigments {
    let radians = degrees * .pi / 180
    let center = CGPoint(x: paletteCenter.x + cos(radians) * wellOrbit,
                         y: paletteCenter.y + sin(radians) * wellOrbit)

    // 格子的凹陷感：先画一圈深色，再画颜料色。
    ctx.setFillColor(rgb(0x000000, 0.10))
    ctx.fillEllipse(in: CGRect(x: center.x - wellRadius * 1.06, y: center.y - wellRadius * 1.06,
                               width: wellRadius * 2.12, height: wellRadius * 2.12))
    ctx.setFillColor(rgb(hex))
    ctx.fillEllipse(in: CGRect(x: center.x - wellRadius, y: center.y - wellRadius,
                               width: wellRadius * 2, height: wellRadius * 2))
}

// ── 右下角：二维码定位符，点题"扫码建库" ──
func drawFinder(at origin: CGPoint, module: CGFloat) {
    let outer = module * 7
    ctx.setFillColor(rgb(0xFFFFFF))
    // 外环（7×7 减去 5×5）
    let outerPath = CGMutablePath()
    outerPath.addRoundedRect(in: CGRect(x: origin.x, y: origin.y, width: outer, height: outer),
                             cornerWidth: module * 1.6, cornerHeight: module * 1.6)
    outerPath.addRoundedRect(in: CGRect(x: origin.x + module, y: origin.y + module,
                                        width: module * 5, height: module * 5),
                             cornerWidth: module, cornerHeight: module)
    ctx.addPath(outerPath)
    ctx.fillPath(using: .evenOdd)

    // 中心 3×3
    ctx.addPath(CGPath(roundedRect: CGRect(x: origin.x + module * 2, y: origin.y + module * 2,
                                           width: module * 3, height: module * 3),
                       cornerWidth: module * 0.8, cornerHeight: module * 0.8, transform: nil))
    ctx.fillPath()
}

let module = side * 0.0355
let finderOrigin = CGPoint(x: side * 0.655, y: side * 0.088)
drawFinder(at: finderOrigin, module: module)
drawFinder(at: CGPoint(x: finderOrigin.x + module * 8.4, y: finderOrigin.y), module: module)

// ── 输出 ──
guard let image = ctx.makeImage() else { fatalError("无法生成位图") }
let outPath = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "/tmp/artstock-icon/icon-1024.png"
let url = URL(fileURLWithPath: outPath)
guard let dest = CGImageDestinationCreateWithURL(url as CFURL, "public.png" as CFString, 1, nil) else {
    fatalError("无法创建 PNG 输出")
}
CGImageDestinationAddImage(dest, image, nil)
guard CGImageDestinationFinalize(dest) else { fatalError("无法写入 PNG") }
print("已生成：\(outPath)")
