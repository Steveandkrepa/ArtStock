#!/usr/bin/env bash
#
# 二维码解析器功能测试。
#
# 为什么需要它：本工程的核心是"扫码建库"，而解析器是纯逻辑、无 UI 依赖，
# 可以脱离 iOS SDK 直接在 macOS 上编译运行。这样即使手头没有 Xcode，
# 也能验证最容易出错的那一层。
#
# 用法：
#   ./scripts/run-parser-tests.sh

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

SRC=ArtStock
OUT="${TMPDIR:-/tmp}/artstock-parser-tests"
mkdir -p "$OUT"

echo "==> 编译解析器测试"
swiftc -swift-version 5 \
  -module-cache-path "$ROOT/.build-cache" \
  -o "$OUT/ParserTests" \
  Tests/ParserTests/MaterialStub.swift \
  "$SRC/Models/MaterialCategory.swift" \
  "$SRC/Models/MeasurementUnit.swift" \
  "$SRC/Models/StockEntryKind.swift" \
  "$SRC/Models/ScannedMaterialDraft.swift" \
  "$SRC/DesignSystem/Formatters.swift" \
  "$SRC/DesignSystem/Theme.swift" \
  "$SRC/Services/QRPayloadParser.swift" \
  Tests/ParserTests/main.swift

echo "==> 运行"
"$OUT/ParserTests"
