//
//  WetnessSession.swift
//  ArtStock — 美术材料余量管理
//
//  一次"颜料保湿监测"的完整记录。
//
//  这个模型同时承担两件事：
//    1. 计时器状态 —— 正在监测的会话、什么时候该补水
//    2. 实测校准的数据源 —— 用户观测到的真实时长存在这里，
//       反推出的 K 也回写到这里，形成可追溯的校准历史
//
//  ⚠️ 关于 calibrationUsed 的语义（很容易搞错）：
//     它存的是**基础常数 K**，也就是用户实测校准出来的那个值
//     （或未校准时颜料体系的默认起点值），**不含**容器保湿倍数。
//     容器倍数由 closure 字段单独表示，在 DryingModel.forecast 里才乘上去。
//     如果把已经乘过倍数的"有效常数"存进来，重新计算时就会重复计入容器影响。
//

import Foundation
import SwiftData

/// 会话状态。
enum WetnessStatus: String, CaseIterable, Codable, Identifiable, Sendable {
    /// 正在监测。
    case running
    /// 刚刚补过水，继续监测。
    case misted
    /// 主动结束（颜料收工了）。
    case finished
    /// 中途放弃（不想要了 / 数据无效）。
    case abandoned

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .running: return "监测中"
        case .misted: return "已补水"
        case .finished: return "已结束"
        case .abandoned: return "已放弃"
        }
    }

    var symbolName: String {
        switch self {
        case .running: return "drop.circle.fill"
        case .misted: return "spraybottle.fill"
        case .finished: return "checkmark.circle.fill"
        case .abandoned: return "xmark.circle"
        }
    }

    var isActive: Bool {
        self == .running || self == .misted
    }
}

@Model
final class WetnessSession {

    // MARK: - 时间

    var startedAt: Date
    var endedAt: Date?

    // MARK: - 环境快照（开始时的天气）

    var temperatureC: Double
    var relativeHumidity: Double
    /// 天气来源地点名，便于回溯"当时到底是哪儿的湿度"。
    var placeName: String

    // MARK: - 颜料与容器

    var paintSystemRaw: String
    var closureRaw: String

    // MARK: - 模型参数

    /// 基础标定常数 K（kPa·h），**不含**容器倍数。见文件头的说明。
    var calibrationUsed: Double
    /// 当时用的是不是用户实测校准过的 K。
    var wasCalibrated: Bool

    // MARK: - 冻结的历史预测

    /// 建模当时的建议补水时刻。存下来而不是每次重算，
    /// 这样用户事后回看时看到的是"当时预测了什么"，而不是被新参数改写的结果。
    var predictedRemistAt: Date
    var predictedSkinningAt: Date
    /// 建模当时建议的喷雾下数（0 表示当时还没标定）。
    var spraysPerRemist: Int

    // MARK: - 状态

    var statusRaw: String
    /// 补过几次水。
    var mistCount: Int
    var note: String

    /// 可选关联到某条材料档案（比如"这一盘是群青 + 镉红"）。
    var material: Material?

    // MARK: - 实测校准

    /// 用户点下"现在需要补水了"的真实时刻。
    var observedRemistAt: Date?
    /// 由这次观测反推出的 K。nil 表示还没校准过或数据不可用。
    var derivedCalibration: Double?

    init(
        startedAt: Date = .now,
        temperatureC: Double,
        relativeHumidity: Double,
        placeName: String,
        paintSystem: PaintSystem,
        closure: PaletteClosure,
        calibrationUsed: Double,
        wasCalibrated: Bool,
        predictedRemistAt: Date,
        predictedSkinningAt: Date,
        spraysPerRemist: Int,
        status: WetnessStatus = .running,
        note: String = "",
        material: Material? = nil
    ) {
        self.startedAt = startedAt
        self.temperatureC = temperatureC
        self.relativeHumidity = relativeHumidity
        self.placeName = placeName
        self.paintSystemRaw = paintSystem.rawValue
        self.closureRaw = closure.rawValue
        self.calibrationUsed = calibrationUsed
        self.wasCalibrated = wasCalibrated
        self.predictedRemistAt = predictedRemistAt
        self.predictedSkinningAt = predictedSkinningAt
        self.spraysPerRemist = spraysPerRemist
        self.statusRaw = status.rawValue
        self.mistCount = 0
        self.note = note
        self.material = material
    }

    // MARK: - 便捷构造

    /// 用一次预报创建会话。
    static func make(
        forecast: DryingForecast,
        input: DryingInput,
        placeName: String,
        material: Material? = nil
    ) -> WetnessSession {
        WetnessSession(
            startedAt: input.startedAt,
            temperatureC: input.temperatureC,
            relativeHumidity: input.relativeHumidity,
            placeName: placeName,
            paintSystem: input.paintSystem,
            closure: input.closure,
            // 存基础常数，不含容器倍数
            calibrationUsed: input.calibrationOverride ?? input.paintSystem.defaultCalibration,
            wasCalibrated: forecast.isCalibrated,
            predictedRemistAt: forecast.remistDeadline,
            predictedSkinningAt: input.startedAt.addingTimeInterval(forecast.skinningHours * 3600),
            spraysPerRemist: forecast.spraysPerRemist,
            material: material
        )
    }
}

// MARK: - 枚举桥接

extension WetnessSession {

    var paintSystem: PaintSystem {
        get { PaintSystem(rawValue: paintSystemRaw) ?? .other }
        set { paintSystemRaw = newValue.rawValue }
    }

    var closure: PaletteClosure {
        get { PaletteClosure(rawValue: closureRaw) ?? .open }
        set { closureRaw = newValue.rawValue }
    }

    var status: WetnessStatus {
        get { WetnessStatus(rawValue: statusRaw) ?? .finished }
        set { statusRaw = newValue.rawValue }
    }
}

// MARK: - 派生状态

extension WetnessSession {

    /// 按当前参数重算预报。用于界面实时显示剩余时间。
    ///
    /// 注意它与 `predictedRemistAt` 的区别：后者是**冻结的历史记录**，
    /// 这里是**实时值**。改了湿度或容器之后两者会分叉，这是刻意的。
    var currentForecast: DryingForecast {
        DryingModel.forecast(DryingInput(
            temperatureC: temperatureC,
            relativeHumidity: relativeHumidity,
            paintSystem: paintSystem,
            closure: closure,
            calibrationOverride: wasCalibrated ? calibrationUsed : nil,
            minutesPerSpray: WetnessPreferences.minutesPerSpray,
            startedAt: startedAt
        ))
    }

    /// 距离建议补水还剩多久。负数表示已经超时。
    var timeUntilRemist: TimeInterval {
        predictedRemistAt.timeIntervalSinceNow
    }

    /// 是否已经过了建议补水时刻。
    var isOverdue: Bool {
        status.isActive && timeUntilRemist < 0
    }

    /// 已经超时多久。
    var overdueInterval: TimeInterval {
        max(0, -timeUntilRemist)
    }

    /// 紧急程度 0–1：0 表示刚洗完，1 表示已达/超过补水时刻。
    var urgency: Double {
        let total = predictedRemistAt.timeIntervalSince(startedAt)
        guard total > 0 else { return 1 }
        let elapsed = Date.now.timeIntervalSince(startedAt)
        return min(max(elapsed / total, 0), 1)
    }

    /// 一句话状态描述。
    var statusSummary: String {
        switch status {
        case .finished:
            return "已结束"
        case .abandoned:
            return "已放弃"
        case .running, .misted:
            if isOverdue {
                return "已超过建议补水时间 \(Fmt.duration(overdueInterval))"
            }
            return "还有 \(Fmt.duration(timeUntilRemist)) 该补水"
        }
    }

    /// 当时的观测时长（小时）。用于校准。
    var observedHours: Double? {
        guard let observedRemistAt else { return nil }
        let hours = observedRemistAt.timeIntervalSince(startedAt) / 3600
        return hours > 0 ? hours : nil
    }
}
