//
//  MaterialCategory.swift
//  ArtStock — 美术材料余量管理
//
//  分类枚举。持久层统一以 rawValue(String) 存储，避免 SwiftData 对枚举特性支持不足。
//

import Foundation

/// 美术材料分类。
enum MaterialCategory: String, CaseIterable, Codable, Identifiable, Sendable {
    case pigment
    case ink
    case paper
    case canvas
    case brush
    case medium
    case solvent
    case adhesive
    case clay
    case tool
    case digital
    case other

    var id: String { rawValue }

    /// 中文显示名。
    var displayName: String {
        switch self {
        case .pigment: return "颜料"
        case .ink: return "墨水墨汁"
        case .paper: return "纸张卡纸"
        case .canvas: return "画布画板"
        case .brush: return "画笔刀具"
        case .medium: return "媒介调和"
        case .solvent: return "溶剂稀释"
        case .adhesive: return "胶粘材料"
        case .clay: return "泥塑雕塑"
        case .tool: return "工具器材"
        case .digital: return "数码耗材"
        case .other: return "其他"
        }
    }

    /// SF Symbol 名称。
    var symbolName: String {
        switch self {
        case .pigment: return "paintpalette.fill"
        case .ink: return "drop.fill"
        case .paper: return "doc.plaintext.fill"
        case .canvas: return "rectangle.on.rectangle.angled"
        case .brush: return "paintbrush.pointed.fill"
        case .medium: return "flask.fill"
        case .solvent: return "wind"
        case .adhesive: return "tape.fill"
        case .clay: return "cube.fill"
        case .tool: return "wrench.and.screwdriver.fill"
        case .digital: return "printer.fill"
        case .other: return "shippingbox.fill"
        }
    }

    /// 排序权重（侧边栏顺序）。
    var sortIndex: Int {
        MaterialCategory.allCases.firstIndex(of: self) ?? Int.max
    }

    /// 打字搜索时可用于匹配的别名。
    var searchAliases: [String] {
        switch self {
        case .pigment: return ["颜料", "水彩", "丙烯", "油画", "国画", "色粉", "pigment", "paint"]
        case .ink: return ["墨水", "墨汁", "ink", "toner"]
        case .paper: return ["纸", "纸张", "卡纸", "宣纸", "水彩纸", "paper"]
        case .canvas: return ["画布", "画板", "canvas", "board"]
        case .brush: return ["笔", "画笔", "毛笔", "刮刀", "brush", "knife"]
        case .medium: return ["媒介", "调和", "底料", "medium", "gesso"]
        case .solvent: return ["溶剂", "稀释", "洗笔液", "solvent", "thinner"]
        case .adhesive: return ["胶", "胶水", "胶带", "adhesive", "glue", "tape"]
        case .clay: return ["泥", "陶", "雕塑", "clay", "sculpt"]
        case .tool: return ["工具", "器材", "tool", "equipment"]
        case .digital: return ["数码", "打印", "纸张耗材", "digital", "print"]
        case .other: return ["其他", "杂项", "other", "misc"]
        }
    }
}

// MARK: - 中文别名解析（二维码里写了 "水彩" 也能落到 .pigment）

extension MaterialCategory {
    /// 用宽松匹配把任意文本映射到分类；无法识别时返回 nil。
    static func match(_ text: String) -> MaterialCategory? {
        let needle = text.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !needle.isEmpty else { return nil }

        // 1. 原始 rawValue 精确匹配（英文）
        if let exact = MaterialCategory(rawValue: needle) { return exact }

        // 2. 显示名 / 别名精确匹配
        for category in MaterialCategory.allCases {
            if category.displayName.lowercased() == needle { return category }
            if category.searchAliases.contains(where: { $0.lowercased() == needle }) { return category }
        }

        // 3. 别名包含匹配（取最长命中，避免 "胶带" 命中 "胶" 之外更短的干扰）
        var best: (category: MaterialCategory, length: Int)?
        for category in MaterialCategory.allCases {
            for alias in category.searchAliases {
                let lowered = alias.lowercased()
                if needle.contains(lowered) {
                    if best == nil || lowered.count > best!.length {
                        best = (category, lowered.count)
                    }
                }
            }
        }
        return best?.category
    }
}
