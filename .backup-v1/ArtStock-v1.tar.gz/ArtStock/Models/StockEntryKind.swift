//
//  StockEntryKind.swift
//  ArtStock — 美术材料余量管理
//

import Foundation

/// 出入库流水类型。
enum StockEntryKind: String, CaseIterable, Codable, Identifiable, Sendable {
    /// 建档时的初始余量。
    case initial
    /// 入库 / 补货。
    case restock
    /// 领用 / 消耗。
    case consume
    /// 盘点修正（把余量直接设为某个值）。
    case adjust
    /// 报损 / 报废。
    case discard

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .initial: return "建档"
        case .restock: return "入库"
        case .consume: return "领用"
        case .adjust: return "盘点"
        case .discard: return "报损"
        }
    }

    var symbolName: String {
        switch self {
        case .initial: return "sparkles"
        case .restock: return "arrow.down.circle.fill"
        case .consume: return "arrow.up.circle.fill"
        case .adjust: return "slider.horizontal.3"
        case .discard: return "trash.circle.fill"
        }
    }

    /// 该类型是否增加余量。
    var isIncrease: Bool {
        switch self {
        case .initial, .restock: return true
        case .consume, .discard, .adjust: return false
        }
    }

    /// 录入时数量语义：`.adjust` 是"绝对值"，其余是"增减量"。
    var amountSemantic: AmountSemantic {
        switch self {
        case .adjust: return .absolute
        default: return .delta
        }
    }

    enum AmountSemantic: Sendable {
        case delta
        case absolute
    }

    /// 用户可以手动发起的类型（建档由系统自动生成，不出现在操作菜单里）。
    static var selectableKinds: [StockEntryKind] {
        [.restock, .consume, .adjust, .discard]
    }
}

/// 余量健康状态。由 `Material.stockLevel` 计算得出，不落库。
enum StockLevel: String, CaseIterable, Codable, Sendable {
    /// 已耗尽。
    case empty
    /// 低于阈值，需要补货。
    case low
    /// 正常。
    case healthy

    var displayName: String {
        switch self {
        case .empty: return "已用完"
        case .low: return "余量偏低"
        case .healthy: return "充足"
        }
    }

    var symbolName: String {
        switch self {
        case .empty: return "xmark.octagon.fill"
        case .low: return "exclamationmark.triangle.fill"
        case .healthy: return "checkmark.circle.fill"
        }
    }

    /// 需要出现在"待补货"看板里的状态。
    var needsAttention: Bool {
        self != .healthy
    }
}
