//
//  StockEntry.swift
//  ArtStock — 美术材料余量管理
//
//  出入库流水。每次余量变化都必须留下一条记录，保证可追溯。
//

import Foundation
import SwiftData

@Model
final class StockEntry {

    /// 变动类型（StockEntryKind.rawValue）。
    var kindRaw: String

    /// 本次变动的数量绝对值（`abs(balanceAfter - balanceBefore)`）。
    /// 盘点没造成差异时为 0。想看方向请用 `signedDelta`。
    var amount: Double

    /// 变动发生后该材料的余量快照，便于历史回溯时不必重算。
    var balanceAfter: Double

    /// 变动前的余量快照。
    var balanceBefore: Double

    var note: String
    var createdAt: Date

    /// 操作人（iPad 上多人共用一台设备时有用）。
    var operatorName: String

    /// 触发这次变动的扫码内容（手动操作时为空）。
    var scanPayload: String

    /// 所属材料。级联删除由 Material 侧声明。
    var material: Material?

    init(
        kind: StockEntryKind,
        amount: Double,
        balanceBefore: Double,
        balanceAfter: Double,
        createdAt: Date = .now,
        note: String = "",
        operatorName: String = "",
        scanPayload: String = "",
        material: Material? = nil
    ) {
        self.kindRaw = kind.rawValue
        self.amount = amount
        self.balanceBefore = balanceBefore
        self.balanceAfter = balanceAfter
        self.createdAt = createdAt
        self.note = note
        self.operatorName = operatorName
        self.scanPayload = scanPayload
        self.material = material
    }
}

// MARK: - 枚举桥接

extension StockEntry {

    var kind: StockEntryKind {
        get { StockEntryKind(rawValue: kindRaw) ?? .adjust }
        set { kindRaw = newValue.rawValue }
    }

    /// 带符号的变动量，便于在流水列表里显示 "+120 mL" / "−30 mL"。
    var signedDelta: Double {
        balanceAfter - balanceBefore
    }

    /// 展示用带符号文案。
    var deltaText: String {
        let delta = signedDelta
        guard let unit = material?.unit else {
            return delta == 0 ? "±0" : String(format: "%+.2f", delta)
        }
        return Fmt.signedQuantity(delta, unit: unit)
    }
}
