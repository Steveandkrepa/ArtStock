//
//  ScannedMaterialDraft.swift
//  ArtStock — 美术材料余量管理
//
//  扫码解析结果。这是「扫码 → 建库」之间的中间产物：
//  解析器只负责把二维码内容变成结构化草稿，落库由用户确认后触发。
//

import Foundation

/// 二维码内容的解析来源。
enum PayloadSource: String, CaseIterable, Codable, Identifiable, Sendable {
    case json
    case keyValue
    case url
    case gs1
    case plain

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .json: return "JSON 载荷"
        case .keyValue: return "键值文本"
        case .url: return "链接载荷"
        case .gs1: return "GS1 应用标识"
        case .plain: return "纯文本编码"
        }
    }

    var symbolName: String {
        switch self {
        case .json: return "curlybraces"
        case .keyValue: return "list.bullet.rectangle"
        case .url: return "link"
        case .gs1: return "barcode"
        case .plain: return "textformat"
        }
    }

    /// 解析出的字段越丰富，建档时的自动化程度越高。
    var automationHint: String {
        switch self {
        case .json: return "字段最完整，可直接生成档案"
        case .url: return "从链接参数中提取到字段"
        case .keyValue: return "从键值对中提取到字段"
        case .gs1: return "标准条码，通常仅有编码与批次"
        case .plain: return "仅作为编码，其余信息需手工补充"
        }
    }
}

/// 二维码符号类型的展示映射。
///
/// 只依赖原始字符串，避免模型层 import AVFoundation。
enum ScanSymbology {

    static func displayName(forRawValue raw: String) -> String {
        switch raw {
        case "org.iso.QRCode": return "QR 码"
        case "org.gs1.EAN-13": return "EAN-13"
        case "org.gs1.EAN-8": return "EAN-8"
        case "org.gs1.UPC-E": return "UPC-E"
        case "org.iso.Code128": return "Code 128"
        case "org.iso.Code39": return "Code 39"
        case "org.iso.Code93": return "Code 93"
        case "org.iso.ITF14": return "ITF-14"
        case "org.iso.PDF417": return "PDF417"
        case "org.iso.Aztec": return "Aztec"
        case "org.iso.DataMatrix": return "Data Matrix"
        default: return raw.isEmpty ? "未知" : raw
        }
    }

    /// 是否为本应用自己生成的标签（自描述 JSON / artstock:// 链接）。
    static func isOwnLabel(payload: String) -> Bool {
        let lowered = payload.lowercased()
        if lowered.hasPrefix("artstock://") { return true }
        return lowered.contains("\"generator\":\"artstock\"")
            || lowered.contains("\"generator\": \"artstock\"")
    }
}

/// 解析后的材料草稿。
///
/// 所有字段都是可选的：二维码里没有的信息留空，由建档表单补齐默认值。
struct ScannedMaterialDraft: Hashable, Sendable, Identifiable {

    /// 同一次扫码的唯一标识（同一载荷重复扫到时用于去重）。
    var id: String { "\(symbologyRaw)|\(rawPayload)" }

    /// 二维码原始内容（原样保留，作为溯源字段）。
    var rawPayload: String

    /// 符号类型原始值。
    var symbologyRaw: String

    /// 解析来源。
    var source: PayloadSource

    /// 解析出的业务编码。纯文本码时为整段内容。
    var code: String

    var name: String?
    var category: MaterialCategory?
    var brand: String?
    var specification: String?
    var unit: MeasurementUnit?
    var quantity: Double?
    var capacity: Double?
    var lowStockThreshold: Double?
    var location: String?
    var supplier: String?
    var unitPrice: Double?
    var colorHex: String?
    var notes: String?
    var expiryDate: Date?
    var openedAt: Date?
    var batchNumber: String?

    /// 成功提取到的业务字段数量（不含 code 本身）。
    var fieldCount: Int

    /// 解析过程中的提示信息（如"数量字段无法识别为数字"）。
    var warnings: [String]

    /// 是否是本应用生成的标签。
    var isOwnLabel: Bool

    /// 符号类型展示名。
    var symbologyName: String {
        ScanSymbology.displayName(forRawValue: symbologyRaw)
    }

    /// 建档时建议填入的名称。
    var suggestedName: String {
        if let name, !name.isEmpty { return name }
        if let specification, !specification.isEmpty { return specification }
        return code.isEmpty ? "未命名材料" : code
    }

    /// JSON 载荷的展示高度依赖字段数：字段多时直接预填表单，字段少时提示补录。
    var isFieldRich: Bool {
        fieldCount >= 3
    }

    /// 解析质量描述，用于扫码结果卡片上的一句话说明。
    var qualitySummary: String {
        switch fieldCount {
        case 0: return "仅识别到编码，需手工补录"
        case 1...2: return "识别到 \(fieldCount) 个字段，建议补录"
        default: return "识别到 \(fieldCount) 个字段，可直接建档"
        }
    }
}
