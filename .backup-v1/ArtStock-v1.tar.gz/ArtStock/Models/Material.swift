//
//  Material.swift
//  ArtStock — 美术材料余量管理
//
//  核心实体：一条材料档案，对应一枚二维码标签（code 唯一）。
//

import Foundation
import SwiftData

@Model
final class Material {

    // MARK: - 标识

    /// 材料唯一编码。二维码解析出的业务主键，全库唯一。
    @Attribute(.unique) var code: String

    /// 材料名称，例如「温莎牛顿 歌文 群青」。
    var name: String

    // MARK: - 分类与规格

    var categoryRaw: String
    var brand: String
    var specification: String
    var unitRaw: String

    // MARK: - 余量

    /// 当前余量。
    var quantity: Double
    /// 满量 / 标准容量，用于计算余量百分比。为 0 表示未标注容量。
    var capacity: Double
    /// 低于该值即判定为「余量偏低」。
    var lowStockThreshold: Double

    // MARK: - 归属信息

    var location: String
    var supplier: String
    var unitPrice: Double
    /// 色卡颜色（美术材料常用），形如 "#2E5BFF"。
    var colorHex: String

    // MARK: - 时间

    var createdAt: Date
    var updatedAt: Date
    /// 有效期（颜料、胶、媒介常需要）。
    var expiryDate: Date?
    /// 开封日期，用于估算可用期。
    var openedAt: Date?

    // MARK: - 状态与备注

    var isArchived: Bool
    var notes: String

    // MARK: - 扫码溯源

    /// 建档时扫到的原始二维码内容。
    var qrPayload: String
    /// 二维码符号类型（AVMetadataObject.ObjectType.rawValue）。
    var symbologyRaw: String

    // MARK: - 附件

    @Attribute(.externalStorage) var photoData: Data?

    // MARK: - 关系

    @Relationship(deleteRule: .cascade, inverse: \StockEntry.material)
    var entries: [StockEntry] = []

    // MARK: - Init

    init(
        code: String,
        name: String,
        category: MaterialCategory = .other,
        brand: String = "",
        specification: String = "",
        unit: MeasurementUnit = .piece,
        quantity: Double = 0,
        capacity: Double = 0,
        lowStockThreshold: Double = 1,
        location: String = "",
        supplier: String = "",
        unitPrice: Double = 0,
        colorHex: String = "",
        createdAt: Date = .now,
        updatedAt: Date = .now,
        expiryDate: Date? = nil,
        openedAt: Date? = nil,
        isArchived: Bool = false,
        notes: String = "",
        qrPayload: String = "",
        symbologyRaw: String = "",
        photoData: Data? = nil
    ) {
        self.code = Material.normalize(code)
        self.name = name
        self.categoryRaw = category.rawValue
        self.brand = brand
        self.specification = specification
        self.unitRaw = unit.rawValue
        self.quantity = quantity
        self.capacity = capacity
        self.lowStockThreshold = lowStockThreshold
        self.location = location
        self.supplier = supplier
        self.unitPrice = unitPrice
        self.colorHex = colorHex
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.expiryDate = expiryDate
        self.openedAt = openedAt
        self.isArchived = isArchived
        self.notes = notes
        self.qrPayload = qrPayload
        self.symbologyRaw = symbologyRaw
        self.photoData = photoData
    }
}

// MARK: - 类型安全的枚举桥接

extension Material {

    var category: MaterialCategory {
        get { MaterialCategory(rawValue: categoryRaw) ?? .other }
        set { categoryRaw = newValue.rawValue }
    }

    var unit: MeasurementUnit {
        get { MeasurementUnit(rawValue: unitRaw) ?? .piece }
        set { unitRaw = newValue.rawValue }
    }
}

// MARK: - 余量派生状态

extension Material {

    /// 余量健康状态。
    var stockLevel: StockLevel {
        if quantity <= 0 { return .empty }
        if quantity <= lowStockThreshold { return .low }
        return .healthy
    }

    /// 余量占满量的比例（0...1）。未标注容量时为 nil。
    var fillRatio: Double? {
        guard capacity > 0 else { return nil }
        return min(max(quantity / capacity, 0), 1)
    }

    /// 相对阈值的安全倍数。用于排序：越小越紧急。
    var urgency: Double {
        let baseline = max(lowStockThreshold, 0.0001)
        return quantity / baseline
    }

    /// 推算的剩余可用量文案。
    var quantityText: String {
        Fmt.quantity(quantity, unit: unit)
    }

    /// 是否临近有效期（30 天内）。
    var isExpiringSoon: Bool {
        guard let expiryDate else { return false }
        let days = Calendar.current.dateComponents([.day], from: .now, to: expiryDate).day ?? 0
        return days <= 30
    }

    var isExpired: Bool {
        guard let expiryDate else { return false }
        return expiryDate < .now
    }
}

// MARK: - 展示辅助

extension Material {

    /// 副标题：品牌 / 规格 / 位置 中最有信息量的组合。
    var subtitle: String {
        [brand, specification, location]
            .filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
            .joined(separator: " · ")
    }

    /// 供搜索匹配的合并文本。
    var searchableText: String {
        [code, name, brand, specification, location, supplier, notes, category.displayName]
            .joined(separator: " ")
            .lowercased()
    }

    /// 二维码负载：优先用建档时扫到的原始内容，没有则回退到自描述 JSON。
    var effectiveQRPayload: String {
        let trimmed = qrPayload.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? QRCodeGenerator.payload(for: self) : trimmed
    }
}

// MARK: - 规范化

extension Material {

    /// 编码规范化：去空白、全角转半角不受影响，统一大写以便跨设备一致匹配。
    static func normalize(_ raw: String) -> String {
        raw.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    }
}

// MARK: - 演示数据

extension Material {

    /// 预览 / 演示用样机数据。仅在 DEBUG 下被调用。
    static func samples() -> [Material] {
        let calendar = Calendar.current
        let now = Date.now

        return [
            Material(
                code: "ART-PIG-0001",
                name: "艺术家级 群青",
                category: .pigment,
                brand: "Winsor & Newton",
                specification: "37mL 管装",
                unit: .milliliter,
                quantity: 12,
                capacity: 37,
                lowStockThreshold: 10,
                location: "颜料柜 A-1",
                supplier: "美术用品城",
                unitPrice: 68,
                colorHex: "#2E5BFF",
                expiryDate: calendar.date(byAdding: .month, value: 14, to: now),
                notes: "油画用，开封后注意结皮。"
            ),
            Material(
                code: "ART-PIG-0002",
                name: "镉红 中号",
                category: .pigment,
                brand: "Old Holland",
                specification: "40mL 管装",
                unit: .milliliter,
                quantity: 3,
                capacity: 40,
                lowStockThreshold: 10,
                location: "颜料柜 A-1",
                unitPrice: 156,
                colorHex: "#D6303A",
                notes: "含镉，注意通风与手套。"
            ),
            Material(
                code: "ART-PAP-0101",
                name: "阿诗 粗纹水彩纸",
                category: .paper,
                brand: "Arches",
                specification: "300g 全开",
                unit: .sheet,
                quantity: 18,
                capacity: 30,
                lowStockThreshold: 5,
                location: "纸架 B-2",
                supplier: "进口纸专营",
                unitPrice: 92
            ),
            Material(
                code: "ART-BRU-0201",
                name: "红胖子 松鼠毛水彩笔 12 号",
                category: .brush,
                brand: "Escoda",
                specification: "12 号",
                unit: .piece,
                quantity: 1,
                capacity: 1,
                lowStockThreshold: 2,
                location: "笔筒 C-1",
                unitPrice: 210
            ),
            Material(
                code: "ART-MED-0301",
                name: "哑光媒介",
                category: .medium,
                brand: "Liquitex",
                specification: "237mL 瓶装",
                unit: .milliliter,
                quantity: 0,
                capacity: 237,
                lowStockThreshold: 60,
                location: "媒介柜 A-3",
                unitPrice: 118,
                openedAt: calendar.date(byAdding: .month, value: -8, to: now)
            ),
            Material(
                code: "ART-SOL-0401",
                name: "无味洗笔液",
                category: .solvent,
                brand: "Gamsol",
                specification: "1L",
                unit: .milliliter,
                quantity: 640,
                capacity: 1000,
                lowStockThreshold: 200,
                location: "危化品柜 D-1",
                unitPrice: 96,
                notes: "易燃，远离明火，密闭存放。"
            ),
            Material(
                code: "ART-CLY-0501",
                name: "雕塑陶泥",
                category: .clay,
                specification: "5kg 真空装",
                unit: .kilogram,
                quantity: 7.5,
                capacity: 10,
                lowStockThreshold: 2,
                location: "泥塑间",
                unitPrice: 45
            ),
            Material(
                code: "ART-ADH-0601",
                name: "无酸装裱胶带",
                category: .adhesive,
                brand: "Lineco",
                specification: "13mm × 33m",
                unit: .roll,
                quantity: 4,
                capacity: 6,
                lowStockThreshold: 1,
                location: "装裱台抽屉",
                unitPrice: 58,
                expiryDate: calendar.date(byAdding: .day, value: 20, to: now)
            ),
            Material(
                code: "6901234567892",
                name: "康颂 素描本 A4",
                category: .paper,
                brand: "Canson",
                specification: "A4 / 100 页",
                unit: .piece,
                quantity: 9,
                capacity: 12,
                lowStockThreshold: 3,
                location: "储物柜 B-1",
                unitPrice: 32,
                qrPayload: "6901234567892"
            ),
            Material(
                code: "ART-TOL-0701",
                name: "调色刀 5 件套",
                category: .tool,
                specification: "不锈钢 5 件",
                unit: .set,
                quantity: 2,
                lowStockThreshold: 1,
                location: "工具车",
                unitPrice: 88
            )
        ]
    }
}
