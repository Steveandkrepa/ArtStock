//
//  ScanRecord.swift
//  ArtStock — 美术材料余量管理
//
//  扫码收件箱。每一次扫码都留痕，未建档的码停留在 pending 状态，
//  用户可以稍后从「扫码记录」里继续建档，不会丢码。
//

import Foundation
import SwiftData

/// 扫码记录的处理状态。
enum ScanRecordStatus: String, CaseIterable, Codable, Identifiable, Sendable {
    /// 已扫到但尚未处理。
    case pending
    /// 已关联到一条已存在的材料档案。
    case linked
    /// 本次扫码直接创建了新档案。
    case created
    /// 已忽略（误扫、无关码）。
    case ignored

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .pending: return "待处理"
        case .linked: return "已关联"
        case .created: return "已建档"
        case .ignored: return "已忽略"
        }
    }

    var symbolName: String {
        switch self {
        case .pending: return "tray.full.fill"
        case .linked: return "link"
        case .created: return "plus.circle.fill"
        case .ignored: return "eye.slash.fill"
        }
    }
}

@Model
final class ScanRecord {

    /// 二维码原始内容。
    var payload: String

    /// 符号类型（AVMetadataObject.ObjectType.rawValue）。
    var symbologyRaw: String

    /// 解析来源（PayloadSource.rawValue）。
    var sourceRaw: String

    var scannedAt: Date

    var statusRaw: String

    /// 关联到的材料编码（处理完成后写入）。
    var materialCode: String

    /// 用户备注。
    var note: String

    init(
        payload: String,
        symbologyRaw: String = "",
        source: PayloadSource = .plain,
        scannedAt: Date = .now,
        status: ScanRecordStatus = .pending,
        materialCode: String = "",
        note: String = ""
    ) {
        self.payload = payload
        self.symbologyRaw = symbologyRaw
        self.sourceRaw = source.rawValue
        self.scannedAt = scannedAt
        self.statusRaw = status.rawValue
        self.materialCode = materialCode
        self.note = note
    }
}

// MARK: - 枚举桥接

extension ScanRecord {

    var status: ScanRecordStatus {
        get { ScanRecordStatus(rawValue: statusRaw) ?? .pending }
        set { statusRaw = newValue.rawValue }
    }

    var source: PayloadSource {
        get { PayloadSource(rawValue: sourceRaw) ?? .plain }
        set { sourceRaw = newValue.rawValue }
    }

    /// 符号类型的中文名。
    var symbologyName: String {
        ScanSymbology.displayName(forRawValue: symbologyRaw)
    }

    /// 单行摘要，用于列表主标题。
    var summary: String {
        let trimmed = payload.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.count <= 64 { return trimmed }
        return String(trimmed.prefix(61)) + "…"
    }
}
