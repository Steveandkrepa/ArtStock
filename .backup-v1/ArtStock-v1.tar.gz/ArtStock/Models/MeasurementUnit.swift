//
//  MeasurementUnit.swift
//  ArtStock — 美术材料余量管理
//

import Foundation

/// 计量单位。美术材料既可能是连续量（毫升、克），也可能是离散量（支、张、卷）。
enum MeasurementUnit: String, CaseIterable, Codable, Identifiable, Sendable {
    case milliliter
    case liter
    case gram
    case kilogram
    case piece
    case sheet
    case roll
    case set
    case bottle
    case bag
    case meter
    case pair
    case box

    var id: String { rawValue }

    /// 中文单位名。
    var displayName: String {
        switch self {
        case .milliliter: return "毫升"
        case .liter: return "升"
        case .gram: return "克"
        case .kilogram: return "千克"
        case .piece: return "支"
        case .sheet: return "张"
        case .roll: return "卷"
        case .set: return "套"
        case .bottle: return "瓶"
        case .bag: return "袋"
        case .meter: return "米"
        case .pair: return "副"
        case .box: return "盒"
        }
    }

    /// 紧凑符号（用在数字后面）。
    var abbreviation: String {
        switch self {
        case .milliliter: return "mL"
        case .liter: return "L"
        case .gram: return "g"
        case .kilogram: return "kg"
        case .piece: return "支"
        case .sheet: return "张"
        case .roll: return "卷"
        case .set: return "套"
        case .bottle: return "瓶"
        case .bag: return "袋"
        case .meter: return "m"
        case .pair: return "副"
        case .box: return "盒"
        }
    }

    /// 是否允许出现小数。离散单位默认按整数管理。
    var allowsFraction: Bool {
        switch self {
        case .milliliter, .liter, .gram, .kilogram, .meter: return true
        case .piece, .sheet, .roll, .set, .bottle, .bag, .pair, .box: return false
        }
    }

    /// 步进值（+/- 按钮一次调整的幅度）。
    var step: Double {
        switch self {
        case .liter, .kilogram: return 0.1
        case .milliliter, .gram: return 10
        case .meter: return 1
        default: return 1
        }
    }

    /// 该单位下的典型数量级，用于默认阈值推断。
    var defaultLowStockThreshold: Double {
        switch self {
        case .milliliter: return 50
        case .liter: return 0.2
        case .gram: return 50
        case .kilogram: return 0.5
        case .meter: return 1
        default: return 1
        }
    }

    /// 同一量纲内的换算。只支持公制里最常见、语义无歧义的两组。
    ///
    /// 美术材料的标签上经常混用（余量写 "500ml"、满量写 "1L"），
    /// 不做换算的话两者会落进同一条档案却量纲不同，余量百分比就全错了。
    /// - Returns: 换算结果；两者不可互换时为 nil。
    func convert(_ value: Double, to target: MeasurementUnit) -> Double? {
        if self == target { return value }
        switch (self, target) {
        case (.milliliter, .liter): return value / 1000
        case (.liter, .milliliter): return value * 1000
        case (.gram, .kilogram): return value / 1000
        case (.kilogram, .gram): return value * 1000
        default: return nil
        }
    }

    /// 是否为同一量纲（可以互相换算）。
    func isCompatible(with other: MeasurementUnit) -> Bool {
        convert(1, to: other) != nil
    }
}

// MARK: - 中文别名解析

extension MeasurementUnit {
    /// 用宽松匹配把任意文本映射到单位；无法识别时返回 nil。
    static func match(_ text: String) -> MeasurementUnit? {
        let needle = text.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !needle.isEmpty else { return nil }

        if let exact = MeasurementUnit(rawValue: needle) { return exact }

        let table: [String: MeasurementUnit] = [
            "毫升": .milliliter, "ml": .milliliter, "cc": .milliliter,
            "升": .liter, "l": .liter,
            "克": .gram, "g": .gram, "gr": .gram,
            "千克": .kilogram, "公斤": .kilogram, "kg": .kilogram,
            "支": .piece, "只": .piece, "个": .piece, "件": .piece, "把": .piece, "pcs": .piece, "pc": .piece,
            "张": .sheet, "枚": .sheet,
            "卷": .roll, "筒": .roll,
            "套": .set, "组": .set,
            "瓶": .bottle, "罐": .bottle,
            "袋": .bag, "包": .bag,
            "米": .meter, "m": .meter,
            "副": .pair, "对": .pair,
            "盒": .box, "箱": .box
        ]

        if let direct = table[needle] { return direct }
        for (key, unit) in table where needle.contains(key) {
            return unit
        }
        return nil
    }
}
