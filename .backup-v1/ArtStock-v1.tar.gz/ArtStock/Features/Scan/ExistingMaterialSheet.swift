//
//  ExistingMaterialSheet.swift
//  ArtStock — 美术材料余量管理
//
//  扫到「老码」时的结果面板：直接做领用 / 入库 / 盘点 / 报损。
//  这是日常使用最高频的界面——扫一下就要能立刻扣数，所以数量默认为
//  单位步进值，一按确认就完成，不需要键盘。
//

import SwiftData
import SwiftUI

struct ExistingMaterialSheet: View {

    let material: Material
    let record: ScanRecord?

    /// 完成一次变动后的回调，参数是一句给用户看的说明。
    var onDone: (String) -> Void

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var kind: StockEntryKind = .consume
    @State private var amount: Double = 1
    @State private var note: String = ""
    @State private var isShowingFullEditor = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    materialHeader
                        .cardStyle()

                    if material.stockLevel.needsAttention {
                        NoticeBanner(
                            level: material.stockLevel == .empty ? .error : .warning,
                            title: material.stockLevel == .empty ? "该材料已用完" : "余量偏低",
                            message: "预警阈值为 \(Fmt.quantity(material.lowStockThreshold, unit: material.unit))"
                        )
                    }

                    actionSection

                    if !material.notes.isBlank {
                        VStack(alignment: .leading, spacing: 6) {
                            SectionHeader(title: "备注")
                            Text(material.notes)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .cardStyle()
                    }
                }
                .padding(20)
                .frame(maxWidth: 640)
                .frame(maxWidth: .infinity)
            }
            .artScrollEdgeEffect()
            .navigationTitle("已有档案")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        isShowingFullEditor = true
                    } label: {
                        Image(systemName: "square.and.pencil")
                    }
                    .accessibilityLabel("编辑完整档案")
                }
            }
            .safeAreaInset(edge: .bottom) {
                confirmBar
            }
        }
        .presentationDetents([.medium, .large])
        .sheet(isPresented: $isShowingFullEditor) {
            MaterialEditorView(form: MaterialFormModel(material: material)) { _ in }
        }
        .onAppear {
            // 默认扣一个步进值：日常最高频的操作是"领用一支/一张"。
            amount = material.unit.step
        }
    }

    // MARK: - 档案头部

    private var materialHeader: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 14) {
                CategoryIcon(category: material.category, size: 46)

                VStack(alignment: .leading, spacing: 4) {
                    Text(material.name)
                        .font(.title3.weight(.semibold))
                    Text(material.code)
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }

                Spacer(minLength: 0)

                StockLevelBadge(level: material.stockLevel, compact: true)
            }

            if !material.subtitle.isBlank {
                Text(material.subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Divider()

            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline) {
                    Text("当前余量")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text(material.quantityText)
                        .font(.system(.title2, design: .rounded).weight(.bold))
                        .contentTransition(.numericText())
                }

                FillGauge(ratio: material.fillRatio, level: material.stockLevel)

                if let ratio = material.fillRatio {
                    Text("占满量 \(Fmt.percent(ratio))")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }

    // MARK: - 操作区

    private var actionSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "本次操作", subtitle: kindHint)

            Picker("操作类型", selection: $kind) {
                ForEach(StockEntryKind.selectableKinds) { kind in
                    Label(kind.displayName, systemImage: kind.symbolName)
                        .tag(kind)
                }
            }
            .pickerStyle(.segmented)
            .onChange(of: kind) { _, newValue in
                Haptics.selection()
                // 盘点时数量语义是"目标绝对值"，默认填当前余量更符合直觉。
                amount = newValue == .adjust ? material.quantity : material.unit.step
            }

            HStack {
                Text(kind == .adjust ? "盘点后余量" : "数量")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Spacer()
                QuantityStepper(value: $amount, unit: material.unit)
            }

            if kind == .adjust {
                HStack(spacing: 10) {
                    Button("清空归零") { amount = 0 }
                        .font(.caption)
                        .artGlassButton()
                    Button("填满至 \(Fmt.quantity(material.capacity, unit: material.unit))") {
                        amount = material.capacity
                    }
                    .font(.caption)
                    .artGlassButton()
                    .disabled(material.capacity <= 0)
                }
            }

            LabeledContent("备注") {
                TextField("选填，如「用于毕业创作」", text: $note)
                    .multilineTextAlignment(.trailing)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    private var kindHint: String {
        switch kind {
        case .restock: return "入库会把数量加到当前余量上"
        case .consume: return "领用会从当前余量里扣除"
        case .adjust: return "盘点直接把余量设为你填写的数值"
        case .discard: return "报损会从当前余量里扣除，并标记为损耗"
        case .initial: return "建档初始余量"
        }
    }

    // MARK: - 确认

    private var confirmBar: some View {
        VStack(spacing: 8) {
            if let preview = deltaPreview {
                Text(preview)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            Button {
                confirm()
            } label: {
                Label("确认\(kind.displayName)", systemImage: kind.symbolName)
                    .frame(maxWidth: .infinity)
            }
            .artProminentButton()
            .controlSize(.large)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(.bar)
    }

    /// 变动预览：让用户在点下去之前就知道余量会变成多少。
    private var deltaPreview: String? {
        let before = material.quantity

        let after: Double
        if kind.amountSemantic == .absolute {
            after = max(0, amount).rounded(for: material.unit)
        } else {
            let raw = kind.isIncrease ? before + abs(amount) : before - abs(amount)
            after = max(0, raw).rounded(for: material.unit)
        }

        guard abs(after - before) > 0.0001 else {
            return "余量不变（\(Fmt.quantity(before, unit: material.unit))）"
        }
        return "余量 \(Fmt.quantity(before, unit: material.unit)) → \(Fmt.quantity(after, unit: material.unit))"
    }

    private func confirm() {
        let result = InventoryService.apply(
            kind: kind,
            amount: amount,
            to: material,
            note: note.isBlank ? "扫码\(kind.displayName)" : note,
            scanPayload: record?.payload ?? "",
            in: context
        )

        if result.wasClamped {
            Haptics.alert()
        } else {
            Haptics.saved()
        }

        if let record {
            ScanInboxService.markLinked(record, materialCode: material.code, in: context)
        }

        onDone(result.summary)
        dismiss()
    }
}
