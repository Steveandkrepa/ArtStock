//
//  ScanReviewSheet.swift
//  ArtStock — 美术材料余量管理
//
//  扫到「新码」时的结果面板：展示解析质量，一键带预填内容进建档表单。
//

import SwiftData
import SwiftUI

struct ScanReviewSheet: View {

    let draft: ScannedMaterialDraft
    let record: ScanRecord?

    /// 建档成功。
    var onCreated: (Material) -> Void
    /// 用户选择忽略。
    var onIgnore: () -> Void

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var editorForm: MaterialFormModel?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    qualityHeader
                        .cardStyle()
                    parsedFields
                    if !draft.warnings.isEmpty { warningsCard }
                    rawPayloadCard
                }
                .padding(20)
                .frame(maxWidth: 640)
                .frame(maxWidth: .infinity)
            }
            .artScrollEdgeEffect()
            .navigationTitle("识别结果")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") {
                        onIgnore()
                        dismiss()
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                actionBar
            }
        }
        .presentationDetents([.medium, .large])
        // 建档表单作为嵌套 Sheet：避免先关面板再开表单造成的转场抖动。
        .sheet(item: $editorForm) { form in
            MaterialEditorView(form: form) { material in
                if let material {
                    if let record {
                        ScanInboxService.markCreated(record, materialCode: material.code, in: context)
                    }
                    onCreated(material)
                }
                dismiss()
            }
        }
    }

    // MARK: - 质量概览

    private var qualityHeader: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 14) {
                Image(systemName: draft.isFieldRich ? "checkmark.seal.fill" : "questionmark.circle.fill")
                    .font(.system(size: 34))
                    .foregroundStyle(draft.isFieldRich ? .green : .orange)

                VStack(alignment: .leading, spacing: 4) {
                    Text(draft.code.isBlank ? "未识别到编码" : draft.code)
                        .font(.system(.title3, design: .monospaced).weight(.semibold))
                        .textSelection(.enabled)

                    Text(draft.qualitySummary)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Spacer(minLength: 0)
            }

            Divider()

            HStack(spacing: 18) {
                Label(draft.symbologyName, systemImage: "barcode.viewfinder")
                Label(draft.source.displayName, systemImage: draft.source.symbolName)
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            Text(draft.source.automationHint)
                .font(.caption)
                .foregroundStyle(.tertiary)
        }
    }

    // MARK: - 解析出的字段

    private var parsedFields: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "解析出的字段", subtitle: "这些内容会自动填进建档表单")

            let fields = draftFieldRows

            if fields.isEmpty {
                NoticeBanner(
                    level: .warning,
                    title: "没有解析到额外字段",
                    message: "这个二维码只包含编码。建档表单会留空，需要手工补录名称、分类与单位。"
                )
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(fields.enumerated()), id: \.offset) { index, row in
                        InfoRow(label: row.0, value: row.1, symbolName: row.2, tint: .accentColor)
                        if index < fields.count - 1 {
                            Divider().padding(.leading, 116)
                        }
                    }
                }
                .cardStyle()
            }
        }
    }

    /// 把草稿里非空字段整理成展示行。
    private var draftFieldRows: [(String, String, String)] {
        var rows: [(String, String, String)] = []

        if let name = draft.name { rows.append(("名称", name, "textformat")) }
        if let category = draft.category { rows.append(("分类", category.displayName, category.symbolName)) }
        if let brand = draft.brand { rows.append(("品牌", brand, "building.2")) }
        if let specification = draft.specification { rows.append(("规格", specification, "ruler")) }
        if let unit = draft.unit { rows.append(("单位", "\(unit.displayName)（\(unit.abbreviation)）", "scale.3d")) }
        if let quantity = draft.quantity {
            rows.append(("余量", Fmt.quantity(quantity, unit: draft.unit ?? .piece), "cube"))
        }
        if let capacity = draft.capacity {
            rows.append(("满量", Fmt.quantity(capacity, unit: draft.unit ?? .piece), "cube.transparent"))
        }
        if let threshold = draft.lowStockThreshold {
            rows.append(("预警阈值", Fmt.quantity(threshold, unit: draft.unit ?? .piece), "bell"))
        }
        if let location = draft.location { rows.append(("位置", location, "mappin.and.ellipse")) }
        if let supplier = draft.supplier { rows.append(("供应商", supplier, "truck.box")) }
        if let price = draft.unitPrice { rows.append(("单价", Fmt.currency(price), "yensign.circle")) }
        if let colorHex = draft.colorHex { rows.append(("色号", colorHex, "paintpalette")) }
        if let batch = draft.batchNumber { rows.append(("批次", batch, "number")) }
        if let expiry = draft.expiryDate { rows.append(("有效期", Fmt.date(expiry), "calendar")) }
        if let opened = draft.openedAt { rows.append(("开封日期", Fmt.date(opened), "shippingbox")) }
        if let notes = draft.notes { rows.append(("备注", notes, "note.text")) }

        return rows
    }

    // MARK: - 警告

    private var warningsCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(draft.warnings, id: \.self) { warning in
                Label(warning, systemImage: "exclamationmark.triangle.fill")
                    .font(.footnote)
                    .foregroundStyle(.orange)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    // MARK: - 原始内容

    private var rawPayloadCard: some View {
        DisclosureGroup {
            Text(draft.rawPayload)
                .font(.system(.caption, design: .monospaced))
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 6)
        } label: {
            Label("查看二维码原始内容", systemImage: "doc.text.magnifyingglass")
                .font(.subheadline)
        }
        .cardStyle()
    }

    // MARK: - 操作栏

    private var actionBar: some View {
        HStack(spacing: 12) {
            Button {
                onIgnore()
                dismiss()
            } label: {
                Text("忽略此码")
                    .frame(maxWidth: .infinity)
            }
            .artGlassButton()
            .controlSize(.large)

            Button {
                editorForm = MaterialFormModel(draft: draft)
            } label: {
                Label("建档", systemImage: "plus.circle.fill")
                    .frame(maxWidth: .infinity)
            }
            .artProminentButton()
            .controlSize(.large)
            .disabled(draft.code.isBlank)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(.bar)
    }
}
