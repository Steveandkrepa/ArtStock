//
//  ScanFlowView.swift
//  ArtStock — 美术材料余量管理
//
//  扫码主界面。相机常驻，识别结果按"新码 → 建档 / 老码 → 出入库"分流。
//  这是整个 App 的入口动作，所以做了三重兜底：
//    · 没相机（模拟器）→ 手输编码
//    · 拒绝权限       → 引导去设置 + 手输编码
//    · 码看不清       → 手电筒
//

import SwiftData
import SwiftUI

struct ScanFlowView: View {

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass

    @State private var model = ScanFlowModel()
    @State private var editorForm: MaterialFormModel?
    @State private var isShowingManualEntry = false
    @State private var isShowingQueue = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            cameraLayer

            VStack(spacing: 0) {
                topBar
                Spacer(minLength: 0)
                hintArea
                Spacer(minLength: 0)
                bottomBar
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)

            feedbackOverlay
        }
        .statusBarHidden(false)
        .persistentSystemOverlays(.hidden)
        .onAppear { model.reset() }
        .sheet(item: $model.reviewDraft) { draft in
            ScanReviewSheet(draft: draft, record: model.activeRecord) { material in
                model.showFeedback(ScanFeedback(
                    kind: .created,
                    title: "已建档",
                    detail: "\(material.name) · \(material.code)"
                ))
                model.resumeScanning()
            } onIgnore: {
                if let record = model.activeRecord {
                    ScanInboxService.markIgnored(record, note: "用户在建档面板中忽略", in: context)
                }
                model.showFeedback(ScanFeedback(kind: .rejected, title: "已忽略", detail: "该码已标记为忽略"))
                model.resumeScanning()
            }
        }
        .sheet(item: $model.matchedMaterial) { material in
            ExistingMaterialSheet(material: material, record: model.activeRecord) { message in
                model.showFeedback(ScanFeedback(kind: .existing, title: "已更新", detail: message))
                model.resumeScanning()
            }
        }
        .sheet(isPresented: $isShowingManualEntry) {
            ManualCodeEntryView { payload in
                handle(payload: payload, symbologyRaw: "", isManual: true)
            }
        }
        .sheet(isPresented: $isShowingQueue) {
            ScanQueueView(model: model)
        }
    }

    // MARK: - 相机层

    @ViewBuilder
    private var cameraLayer: some View {
        if model.controller.authorization == .authorized {
            QRScannerView(controller: model.controller) { payload, symbology in
                handle(payload: payload, symbologyRaw: symbology, isManual: false)
            }
            .ignoresSafeArea()
        } else {
            cameraFallback
                .ignoresSafeArea()
        }
    }

    /// 相机不可用时的替代界面。模拟器上必然走到这里。
    private var cameraFallback: some View {
        VStack(spacing: 20) {
            Image(systemName: model.controller.authorization.symbolName)
                .font(.system(size: 56, weight: .light))
                .foregroundStyle(.white.opacity(0.75))

            Text(model.controller.captureError ?? model.controller.authorization.guidance)
                .font(.callout)
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.8))
                .frame(maxWidth: 420)

            if model.controller.authorization == .denied {
                Button("打开系统设置") {
                    guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                    UIApplication.shared.open(url)
                }
                .buttonStyle(.borderedProminent)
                .tint(Theme.scannerAccent)
            }

            Button {
                isShowingManualEntry = true
            } label: {
                Label("手工输入编码", systemImage: "keyboard")
                    .frame(minWidth: 200)
            }
            .buttonStyle(.bordered)
            .tint(.white)
            .controlSize(.large)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(white: 0.08))
    }

    // MARK: - 顶栏

    private var topBar: some View {
        ArtGlassContainer {
            HStack(spacing: 14) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark")
                        .font(.headline)
                        .frame(width: 44, height: 44)
                        .artGlassCircle()
                }
                .tint(.white)
                .accessibilityLabel("关闭扫码")

                VStack(alignment: .leading, spacing: 2) {
                    Text("扫码建库")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text(model.isContinuousMode ? "连续扫描：识别即入队" : "识别新码建档，老码出入库")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.65))
                }

                Spacer()

                if model.acceptedCount > 0 {
                    Text("已识别 \(model.acceptedCount)")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .contentTransition(.numericText())
                        .artGlassSurface(cornerRadius: 999)
                }

                Button {
                    model.isContinuousMode.toggle()
                    Haptics.selection()
                } label: {
                    Image(systemName: model.isContinuousMode ? "square.stack.3d.down.right.fill" : "square.stack.3d.down.right")
                        .font(.headline)
                        .frame(width: 44, height: 44)
                        .artGlassCircle()
                }
                .tint(model.isContinuousMode ? Theme.scannerAccent : .white)
                .accessibilityLabel(model.isContinuousMode ? "关闭连续扫描" : "开启连续扫描")

                Button {
                    isShowingQueue = true
                } label: {
                    ZStack(alignment: .topTrailing) {
                        Image(systemName: "tray.full")
                            .font(.headline)
                            .frame(width: 44, height: 44)
                            .artGlassCircle()

                        if !model.batchDrafts.isEmpty {
                            Text("\(model.batchDrafts.count)")
                                .font(.caption2.weight(.bold))
                                .foregroundStyle(.black)
                                .padding(.horizontal, 5)
                                .padding(.vertical, 2)
                                .background(Theme.scannerAccent, in: Capsule())
                                .offset(x: 4, y: -2)
                        }
                    }
                }
                .tint(.white)
                .accessibilityLabel("待建档队列，\(model.batchDrafts.count) 项")
            }
        }
    }

    // MARK: - 提示区

    private var hintArea: some View {
        VStack(spacing: 8) {
            if model.controller.isTorchOn {
                Label("手电筒已开启", systemImage: "flashlight.on.fill")
                    .font(.caption)
                    .foregroundStyle(Theme.scannerAccent)
            }

            Text("将二维码完整放入取景框内，保持 10–30 cm 距离")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.75))
                .padding(.horizontal, 16)
                .padding(.vertical, 9)
                .artGlassSurface(cornerRadius: 999)
        }
        .padding(.bottom, 40)
    }

    // MARK: - 底栏

    private var bottomBar: some View {
        ArtGlassContainer {
            HStack(spacing: 26) {
                Button {
                    model.controller.toggleTorch()
                    Haptics.selection()
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: model.controller.isTorchOn ? "flashlight.on.fill" : "flashlight.off.fill")
                            .font(.title3)
                            .frame(width: 56, height: 56)
                            .artGlassCircle()
                        Text("手电筒")
                            .font(.caption2)
                    }
                }
                .tint(model.controller.isTorchOn ? Theme.scannerAccent : .white)
                .disabled(!model.controller.isTorchAvailable)
                .opacity(model.controller.isTorchAvailable ? 1 : 0.4)

                Button {
                    isShowingManualEntry = true
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: "keyboard")
                            .font(.title3)
                            .frame(width: 56, height: 56)
                            .artGlassCircle()
                        Text("手输编码")
                            .font(.caption2)
                    }
                }
                .tint(.white)

                if !model.batchDrafts.isEmpty {
                    Button {
                        isShowingQueue = true
                    } label: {
                        VStack(spacing: 6) {
                            Image(systemName: "square.and.arrow.down.on.square")
                                .font(.title3)
                                .frame(width: 56, height: 56)
                                .background(Theme.scannerAccent, in: Circle())
                                .foregroundStyle(.black)
                            Text("建档队列")
                                .font(.caption2)
                        }
                    }
                    .tint(.white)
                }
            }
        }
        .padding(.bottom, 8)
    }

    // MARK: - 即时反馈

    @ViewBuilder
    private var feedbackOverlay: some View {
        if let feedback = model.feedback {
            VStack {
                HStack(spacing: 10) {
                    Image(systemName: feedback.symbolName)
                        .font(.title3)
                        .foregroundStyle(feedback.tint)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(feedback.title)
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.primary)
                        Text(feedback.detail)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                    Spacer(minLength: 0)
                }
                .padding(12)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .frame(maxWidth: horizontalSizeClass == .regular ? 460 : .infinity)
                .transition(.move(edge: .top).combined(with: .opacity))

                Spacer()
            }
            .padding(.top, 74)
            .padding(.horizontal, 20)
            .allowsHitTesting(false)
        }
    }

    // MARK: - 识别处理

    /// 所有识别结果的统一入口（相机与手输共用）。
    private func handle(payload: String, symbologyRaw: String, isManual: Bool) {
        guard model.isAcceptingDetections else { return }

        let trimmed = payload.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        // 手输时用户是主动行为，不做去重窗口限制（可能确实要连扫两次同一个码）。
        if !isManual, !model.shouldAccept(payload: trimmed) { return }

        let draft = QRPayloadParser.parse(payload: trimmed, symbologyRaw: symbologyRaw)

        // 每一次识别都先落收件箱，保证不丢码。
        let record = ScanInboxService.record(
            payload: trimmed,
            symbologyRaw: symbologyRaw,
            source: draft.source,
            in: context
        )
        model.activeRecord = record

        let existing = InventoryService.material(code: draft.code, in: context)

        switch model.route(draft: draft, existing: existing) {
        case .existing(let material):
            ScanInboxService.markLinked(record, materialCode: material.code, in: context)
            Haptics.scanSuccess()

        case .newDraft(let draft):
            model.registerAcceptance()
            Haptics.scanSuccess()
            _ = draft

        case .queued(let draft, let total):
            model.registerAcceptance()
            model.attachRecord(record, to: draft)
            Haptics.scanSuccess()
            model.showFeedback(ScanFeedback(
                kind: .queued,
                title: "已加入待建档队列",
                detail: "\(draft.code) · 队列共 \(total) 项"
            ))

        case .rejected(let reason):
            ScanInboxService.markIgnored(record, note: reason, in: context)
            Haptics.scanFailure()
            model.showFeedback(ScanFeedback(kind: .rejected, title: "未能处理", detail: reason))
            model.resumeScanning()
        }
    }
}
