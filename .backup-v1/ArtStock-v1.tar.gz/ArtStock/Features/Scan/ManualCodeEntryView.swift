//
//  ManualCodeEntryView.swift
//  ArtStock — 美术材料余量管理
//
//  手工输入编码。三条场景都靠它兜底：
//    · 模拟器没有摄像头
//    · 相机被占用或权限被拒
//    · 标签磨损、反光严重扫不出来，但编码还能看清
//
//  输入的内容走的是与相机**完全相同**的解析管线，所以粘贴一段
//  JSON 或 URL 也能直接结构化建档。
//

import SwiftUI

struct ManualCodeEntryView: View {

    /// 提交回调，参数是原始文本。
    var onSubmit: (String) -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var text: String = ""
    @FocusState private var isFocused: Bool

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("例如 ART-PIG-0001", text: $text, axis: .vertical)
                        .lineLimit(1...6)
                        .font(.system(.body, design: .monospaced))
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .focused($isFocused)
                        .submitLabel(.done)
                        .onSubmit { submit() }
                } header: {
                    Text("编码或二维码内容")
                } footer: {
                    Text("可以直接粘贴二维码里的整段内容。支持 JSON、URL 参数、GS1 条码、键值文本，解析规则与扫码完全一致。")
                }

                if !text.isBlank {
                    previewSection
                }

                Section {
                    Button {
                        text = samplePayload
                    } label: {
                        Label("填入一段示例 JSON", systemImage: "wand.and.stars")
                    }
                    .font(.subheadline)
                }
            }
            .formStyle(.grouped)
            .navigationTitle("手工输入")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("识别") { submit() }
                        .disabled(text.isBlank)
                        .fontWeight(.semibold)
                }
            }
        }
        .presentationDetents([.medium, .large])
        .onAppear { isFocused = true }
    }

    // MARK: - 实时解析预览

    private var previewSection: some View {
        let draft = QRPayloadParser.parse(payload: text, symbologyRaw: "")

        return Section {
            InfoRow(label: "识别来源", value: draft.source.displayName,
                    symbolName: draft.source.symbolName, tint: .blue)
            InfoRow(label: "编码", value: draft.code.isBlank ? "（空）" : draft.code,
                    symbolName: "number", tint: .accentColor)

            if let name = draft.name {
                InfoRow(label: "名称", value: name, symbolName: "textformat")
            }
            if let category = draft.category {
                InfoRow(label: "分类", value: category.displayName, symbolName: category.symbolName)
            }
            if let quantity = draft.quantity {
                InfoRow(label: "余量", value: Fmt.quantity(quantity, unit: draft.unit ?? .piece),
                        symbolName: "cube")
            }

            ForEach(draft.warnings, id: \.self) { warning in
                Label(warning, systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        } header: {
            Text("解析预览")
        } footer: {
            Text(draft.code.isBlank
                 ? "没有解析出可用编码，请检查内容。"
                 : "确认无误后点右上角「识别」进入建档流程。")
        }
    }

    private var samplePayload: String {
        """
        {"code":"ART-NEW-9001","name":"生赭","category":"颜料","brand":"Old Holland",\
        "spec":"40mL 管装","unit":"毫升","quantity":"45","capacity":"60",\
        "location":"颜料柜 A-2","expiry":"2027-06-30"}
        """
    }

    private func submit() {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        onSubmit(trimmed)
        dismiss()
    }
}
