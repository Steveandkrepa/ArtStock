//
//  ScanFlowModel.swift
//  ArtStock — 美术材料余量管理
//
//  扫码流程的状态机。把"识别 → 去重 → 查库 → 分流到建档 / 领用 / 批量队列"
//  这段逻辑从视图里抽出来，视图只负责画。
//

import Foundation
import Observation
import SwiftUI

/// 一次识别后的即时反馈。用于屏幕上短暂闪现的提示条。
struct ScanFeedback: Identifiable, Equatable {
    enum Kind: Equatable {
        case created
        case existing
        case queued
        case rejected
    }

    let id = UUID()
    let kind: Kind
    let title: String
    let detail: String

    var symbolName: String {
        switch kind {
        case .created: return "plus.circle.fill"
        case .existing: return "checkmark.circle.fill"
        case .queued: return "tray.and.arrow.down.fill"
        case .rejected: return "exclamationmark.triangle.fill"
        }
    }

    var tint: Color {
        switch kind {
        case .created: return .green
        case .existing: return .blue
        case .queued: return .orange
        case .rejected: return .red
        }
    }
}

@MainActor
@Observable
final class ScanFlowModel {

    // MARK: - 相机

    let controller = ScannerController()

    // MARK: - 扫描行为

    /// 连续扫描模式：识别到的码不弹窗，直接进待建档队列。
    var isContinuousMode: Bool = false

    /// 是否接受识别结果。弹出结果面板时置为 false，避免相机连帧把人淹没。
    var isAcceptingDetections: Bool = true

    /// 本次会话已接受的识别次数。
    private(set) var acceptedCount: Int = 0

    /// 待建档队列（连续扫描模式下累积）。
    private(set) var batchDrafts: [ScannedMaterialDraft] = []

    /// 队列里每个草稿对应的收件箱记录。批量建档成功后要把它们标记为已建档，
    /// 否则「扫码记录」里会一直挂着一堆已经处理过的待办。
    private(set) var pendingRecords: [String: ScanRecord] = [:]

    // MARK: - 弹窗分流

    /// 待审阅的扫码草稿（新码 → 建档流程）。
    var reviewDraft: ScannedMaterialDraft?
    /// 命中的已有档案（老码 → 出入库流程）。
    var matchedMaterial: Material?
    /// 刚落到收件箱的那条记录，建档/关联成功后要回写状态。
    var activeRecord: ScanRecord?

    /// 最新的即时反馈。
    var feedback: ScanFeedback?

    /// 用户手动输入编码时用于提示。
    var manualEntryError: String?

    // MARK: - 去重

    /// 同一载荷在窗口期内只接受一次。相机每帧都会回调，不去重会疯狂触发。
    private var recentPayloads: [String: Date] = [:]
    private let dedupeWindow: TimeInterval = 2.5

    /// 判断这次识别是否应该被接受。
    func shouldAccept(payload: String) -> Bool {
        let now = Date.now

        // 顺手清理过期条目，避免字典无限增长。
        if recentPayloads.count > 64 {
            recentPayloads = recentPayloads.filter { now.timeIntervalSince($0.value) < dedupeWindow * 4 }
        }

        if let last = recentPayloads[payload], now.timeIntervalSince(last) < dedupeWindow {
            return false
        }
        recentPayloads[payload] = now
        return true
    }

    /// 识别被接受后登记。
    func registerAcceptance() {
        acceptedCount += 1
    }

    // MARK: - 分流

    /// 把一次识别结果分流到对应去向。
    /// - Returns: 本次处理结果的即时反馈。
    enum Routing {
        /// 命中已有档案，走出入库流程。
        case existing(Material)
        /// 新码，走建档流程。
        case newDraft(ScannedMaterialDraft)
        /// 新码且处于连续模式，已并入队列。
        case queued(ScannedMaterialDraft, total: Int)
        /// 无法处理（内容为空等）。
        case rejected(reason: String)
    }

    func route(draft: ScannedMaterialDraft, existing: Material?) -> Routing {
        if let existing {
            matchedMaterial = existing
            isAcceptingDetections = false
            return .existing(existing)
        }

        guard !draft.code.isBlank else {
            return .rejected(reason: "识别到的内容没有可用编码（空白或全是分隔符）")
        }

        // 连续模式下同一个码只入队一次，避免反复对准就重复建档。
        if isContinuousMode {
            if batchDrafts.contains(where: { $0.code == draft.code }) {
                return .rejected(reason: "编码 \(draft.code) 已在待建档队列中")
            }
            batchDrafts.append(draft)
            return .queued(draft, total: batchDrafts.count)
        }

        reviewDraft = draft
        isAcceptingDetections = false
        return .newDraft(draft)
    }

    // MARK: - 反馈

    func showFeedback(_ feedback: ScanFeedback) {
        withAnimation(.snappy(duration: 0.25)) {
            self.feedback = feedback
        }
        // 自动消隐。用 Task 而不是 Timer，随视图生命周期自然取消。
        let token = feedback.id
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(2.4))
            guard let self, self.feedback?.id == token else { return }
            withAnimation(.snappy(duration: 0.25)) {
                self.feedback = nil
            }
        }
    }

    // MARK: - 队列管理

    /// 把收件箱记录挂到队列草稿上。
    func attachRecord(_ record: ScanRecord, to draft: ScannedMaterialDraft) {
        pendingRecords[draft.id] = record
    }

    /// 取队列草稿对应的收件箱记录。
    func record(for draft: ScannedMaterialDraft) -> ScanRecord? {
        pendingRecords[draft.id]
    }

    func removeFromQueue(_ draft: ScannedMaterialDraft) {
        batchDrafts.removeAll { $0.code == draft.code }
        pendingRecords[draft.id] = nil
    }

    func clearQueue() {
        batchDrafts.removeAll()
        pendingRecords.removeAll()
    }

    // MARK: - 面板关闭

    /// 关闭结果面板后恢复扫描。
    func resumeScanning() {
        reviewDraft = nil
        matchedMaterial = nil
        activeRecord = nil
        isAcceptingDetections = true
    }

    /// 重置整个会话（关闭扫码页时调用）。
    func reset() {
        reviewDraft = nil
        matchedMaterial = nil
        activeRecord = nil
        feedback = nil
        acceptedCount = 0
        recentPayloads.removeAll()
        isAcceptingDetections = true
        // 刻意保留 batchDrafts：用户可能只是想临时退出扫码页，
        // 队列内容由用户显式清空。
    }
}
