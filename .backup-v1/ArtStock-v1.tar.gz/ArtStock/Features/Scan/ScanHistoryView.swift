//
//  ScanHistoryView.swift
//  ArtStock — 美术材料余量管理
//
//  扫码收件箱。每一次扫码都留痕，未处理的码停在这里可以继续建档——
//  这是"手滑关掉弹窗就丢码"这个问题的答案。
//

import SwiftData
import SwiftUI

struct ScanHistoryView: View {

    @Environment(\.modelContext) private var context

    @Query(sort: \ScanRecord.scannedAt, order: .reverse)
    private var records: [ScanRecord]

    @State private var editorDraft: ScannedMaterialDraft?
    @State private var pendingRecord: ScanRecord?
    @State private var isShowingClearConfirm = false

    var body: some View {
        Group {
            if records.isEmpty {
                EmptyState(
                    title: "还没有扫码记录",
                    message: "每次扫码都会在这里留一条记录，即使是误扫也能事后追溯。",
                    symbolName: "qrcode.viewfinder"
                )
            } else {
                listContent
            }
        }
        .navigationTitle("扫码记录")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { toolbarContent }
        .sheet(item: $editorDraft) { draft in
            MaterialEditorView(form: MaterialFormModel(draft: draft)) { material in
                if let material, let pendingRecord {
                    ScanInboxService.markCreated(pendingRecord, materialCode: material.code, in: context)
                }
                pendingRecord = nil
            }
        }
        .alert("清空已处理记录？", isPresented: $isShowingClearConfirm) {
            Button("清空", role: .destructive) {
                ScanInboxService.clearCompleted(in: context)
            }
            Button("取消", role: .cancel) {}
        } message: {
            Text("只删除已关联、已建档、已忽略的记录；待处理的记录会保留。")
        }
    }

    // MARK: - 列表

    private var listContent: some View {
        List {
            if !pendingRecords.isEmpty {
                Section {
                    ForEach(pendingRecords) { record in
                        pendingRow(record)
                    }
                } header: {
                    Label("待处理 \(pendingRecords.count) 条", systemImage: "tray.full.fill")
                        .foregroundStyle(.orange)
                } footer: {
                    Text("这些码还没有对应任何材料档案。点一下可以直接建档。")
                }
            }

            if !completedRecords.isEmpty {
                Section {
                    ForEach(completedRecords) { record in
                        completedRow(record)
                    }
                } header: {
                    Text("已处理 \(completedRecords.count) 条")
                }
            }
        }
        .listStyle(.insetGrouped)
        .artScrollEdgeEffect()
    }

    // MARK: - 待处理行

    private func pendingRow(_ record: ScanRecord) -> some View {
        let draft = QRPayloadParser.parse(payload: record.payload, symbologyRaw: record.symbologyRaw)

        return HStack(spacing: 12) {
            Image(systemName: draft.isFieldRich ? "checkmark.seal.fill" : "questionmark.circle.fill")
                .font(.title3)
                .foregroundStyle(draft.isFieldRich ? .green : .orange)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 3) {
                Text(draft.name ?? draft.code)
                    .font(.subheadline.weight(.medium))
                    .lineLimit(1)

                Text(record.summary)
                    .font(.system(.caption2, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)

                HStack(spacing: 8) {
                    Label(record.symbologyName, systemImage: "barcode.viewfinder")
                    Label(record.source.displayName, systemImage: record.source.symbolName)
                    Text(Fmt.relative(record.scannedAt))
                }
                .font(.caption2)
                .foregroundStyle(.tertiary)
            }

            Spacer(minLength: 8)

            Button {
                pendingRecord = record
                editorDraft = draft
            } label: {
                Label("建档", systemImage: "plus.circle.fill")
                    .labelStyle(.iconOnly)
                    .font(.title3)
            }
            .buttonStyle(.borderless)
            .disabled(draft.code.isBlank)
            .accessibilityLabel("为 \(draft.code) 建档")
        }
        .padding(.vertical, 3)
        .swipeActions(edge: .trailing) {
            Button(role: .destructive) {
                ScanInboxService.delete(record, in: context)
            } label: {
                Label("删除", systemImage: "trash")
            }

            Button {
                ScanInboxService.markIgnored(record, note: "手动标记忽略", in: context)
            } label: {
                Label("忽略", systemImage: "eye.slash")
            }
            .tint(.gray)
        }
    }

    // MARK: - 已处理行

    private func completedRow(_ record: ScanRecord) -> some View {
        HStack(spacing: 12) {
            Image(systemName: record.status.symbolName)
                .font(.callout)
                .foregroundStyle(statusTint(record.status))
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(record.status.displayName)
                        .font(.caption.weight(.medium))
                        .foregroundStyle(statusTint(record.status))

                    if !record.materialCode.isBlank {
                        Text(record.materialCode)
                            .font(.system(.caption2, design: .monospaced))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }

                Text(record.summary)
                    .font(.system(.caption2, design: .monospaced))
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)

                Text(Fmt.relative(record.scannedAt))
                    .font(.caption2)
                    .foregroundStyle(.quaternary)
            }

            Spacer(minLength: 0)
        }
        .padding(.vertical, 2)
        .swipeActions(edge: .trailing) {
            Button(role: .destructive) {
                ScanInboxService.delete(record, in: context)
            } label: {
                Label("删除", systemImage: "trash")
            }
        }
    }

    private func statusTint(_ status: ScanRecordStatus) -> Color {
        switch status {
        case .pending: return .orange
        case .linked: return .blue
        case .created: return .green
        case .ignored: return .gray
        }
    }

    // MARK: - 数据

    private var pendingRecords: [ScanRecord] {
        records.filter { $0.status == .pending }
    }

    private var completedRecords: [ScanRecord] {
        records.filter { $0.status != .pending }
    }

    // MARK: - 工具栏

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) {
            Menu {
                Button(role: .destructive) {
                    isShowingClearConfirm = true
                } label: {
                    Label("清空已处理记录", systemImage: "trash")
                }
                .disabled(completedRecords.isEmpty)
            } label: {
                Image(systemName: "ellipsis.circle")
            }
            .accessibilityLabel("更多操作")
        }
    }
}
