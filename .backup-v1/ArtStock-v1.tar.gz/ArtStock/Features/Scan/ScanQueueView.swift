//
//  ScanQueueView.swift
//  ArtStock — 美术材料余量管理
//
//  连续扫描攒下来的待建档队列。可以逐条核对，也可以一次性全部建档。
//  这是"批量盘点/集中入库"场景的落点。
//

import SwiftData
import SwiftUI

struct ScanQueueView: View {

    @Bindable var model: ScanFlowModel

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var editorDraft: ScannedMaterialDraft?
    @State private var summary: BatchSummary?

    var body: some View {
        NavigationStack {
            Group {
                if model.batchDrafts.isEmpty {
                    EmptyState(
                        title: "队列是空的",
                        message: "开启连续扫描后，每识别到一个新码就会自动加进这里，攒够了一起建档。",
                        symbolName: "tray"
                    )
                } else {
                    List {
                        Section {
                            ForEach(model.batchDrafts) { draft in
                                Button {
                                    editorDraft = draft
                                } label: {
                                    row(for: draft)
                                }
                                .buttonStyle(.plain)
                                .swipeActions(edge: .trailing) {
                                    Button(role: .destructive) {
                                        model.removeFromQueue(draft)
                                        Haptics.selection()
                                    } label: {
                                        Label("移除", systemImage: "trash")
                                    }
                                }
                            }
                        } footer: {
                            Text("点任意一条可以先核对内容再建档；左右滑动可以移除误扫的码。")
                        }
                    }
                    .listStyle(.insetGrouped)
                    .artScrollEdgeEffect()
                }
            }
            .navigationTitle("待建档队列")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button(role: .destructive) {
                            model.clearQueue()
                        } label: {
                            Label("清空队列", systemImage: "trash")
                        }
                        .disabled(model.batchDrafts.isEmpty)
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                if !model.batchDrafts.isEmpty {
                    buildBar
                }
            }
        }
        .presentationDetents([.medium, .large])
        .sheet(item: $editorDraft) { draft in
            MaterialEditorView(form: MaterialFormModel(draft: draft)) { material in
                guard let material else { return }
                if let record = model.record(for: draft) {
                    ScanInboxService.markCreated(record, materialCode: material.code, in: context)
                }
                model.removeFromQueue(draft)
            }
        }
        .alert("批量建档完成", isPresented: .presentWhen($summary)) {
            Button("知道了") { summary = nil }
        } message: {
            if let summary {
                Text(summary.message)
            }
        }
    }

    // MARK: - 行

    private func row(for draft: ScannedMaterialDraft) -> some View {
        HStack(spacing: 12) {
            Image(systemName: draft.isFieldRich ? "checkmark.seal.fill" : "questionmark.circle")
                .font(.title3)
                .foregroundStyle(draft.isFieldRich ? .green : .orange)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 3) {
                Text(draft.name ?? "（未命名）")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.primary)

                Text(draft.code)
                    .font(.system(.caption, design: .monospaced))
                    .foregroundStyle(.secondary)

                HStack(spacing: 8) {
                    if let category = draft.category {
                        Label(category.displayName, systemImage: category.symbolName)
                    }
                    if let quantity = draft.quantity {
                        Label(Fmt.quantity(quantity, unit: draft.unit ?? .piece), systemImage: "cube")
                    }
                }
                .font(.caption2)
                .foregroundStyle(.tertiary)
            }

            Spacer(minLength: 0)

            Image(systemName: "chevron.right")
                .font(.caption)
                .foregroundStyle(.tertiary)
        }
        .padding(.vertical, 2)
        .contentShape(Rectangle())
    }

    // MARK: - 批量建档

    private var buildBar: some View {
        VStack(spacing: 8) {
            Text("共 \(model.batchDrafts.count) 项待建档")
                .font(.caption)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)

            Button {
                buildAll()
            } label: {
                Label("全部建档", systemImage: "square.and.arrow.down.on.square")
                    .frame(maxWidth: .infinity)
            }
            .artProminentButton()
            .controlSize(.large)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(.bar)
    }

    /// 逐条建档。
    ///
    /// 刻意用逐条 `try/catch` 而不是整体事务：编码重复、字段非法这些是**单条**问题，
    /// 不应该让整批都失败，用户最怕"扫了 30 个只进去 1 个还得重扫"。
    private func buildAll() {
        var created = 0
        var failures: [String] = []

        for draft in model.batchDrafts {
            let form = MaterialFormModel(draft: draft)
            do {
                let material = try InventoryService.create(form: form, in: context)
                if let record = model.record(for: draft) {
                    ScanInboxService.markCreated(record, materialCode: material.code, in: context)
                }
                created += 1
            } catch {
                failures.append("\(draft.code)：\(error.localizedDescription)")
            }
        }

        Haptics.saved()
        model.clearQueue()

        summary = BatchSummary(created: created, failures: failures)
    }
}

/// 批量建档结果。
struct BatchSummary {
    let created: Int
    let failures: [String]

    var message: String {
        if failures.isEmpty {
            return "成功建档 \(created) 条。"
        }
        let head = "成功建档 \(created) 条，\(failures.count) 条失败："
        return ([head] + failures.prefix(5)).joined(separator: "\n")
    }
}
