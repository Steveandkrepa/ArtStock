//
//  SidebarView.swift
//  ArtStock — 美术材料余量管理
//
//  iPad 三栏布局的**侧边栏**。
//  角标只显示"需要行动"的数字（待补货、临期、待处理扫码），
//  其余用灰色计数——否则侧边栏会变成一片红色噪声，反而不看。
//

import SwiftData
import SwiftUI

struct SidebarView: View {

    @Bindable var nav: NavigationModel

    @Query private var allMaterials: [Material]

    @Query(filter: #Predicate<ScanRecord> { $0.statusRaw == "pending" })
    private var pendingScans: [ScanRecord]

    var body: some View {
        List(selection: $nav.destination) {
            Section("库存") {
                row(.dashboard)
                row(.allMaterials, count: counts.all)
                row(.lowStock, count: counts.attention, isAlert: counts.attention > 0)
                row(.expiring, count: counts.expiring, isAlert: counts.expiring > 0)
                row(.archived, count: archivedCount)
            }

            if !categoriesInUse.isEmpty {
                Section("分类") {
                    ForEach(categoriesInUse) { category in
                        row(.category(category), count: categoryCounts[category] ?? 0)
                    }
                }
            }

            Section("记录与工具") {
                row(.scanHistory,
                    count: pendingScans.count,
                    caption: pendingScans.isEmpty ? nil : "待处理",
                    isAlert: !pendingScans.isEmpty)
                row(.transactions, count: transactionCount)
                row(.labels)
                row(.settings)
            }
        }
        .listStyle(.sidebar)
        .navigationTitle("ArtStock")
        .safeAreaInset(edge: .top) {
            brandHeader
        }
    }

    // MARK: - 品牌头

    private var brandHeader: some View {
        HStack(spacing: 10) {
            Image(systemName: "paintpalette.fill")
                .font(.title3)
                .foregroundStyle(Theme.color(for: .pigment))
                .frame(width: 34, height: 34)
                .background(Theme.iconBackground(for: .pigment),
                            in: RoundedRectangle(cornerRadius: 9, style: .continuous))

            VStack(alignment: .leading, spacing: 1) {
                Text("材料余量")
                    .font(.headline)
                Text("ArtStock")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
    }

    // MARK: - 行

    private func row(
        _ destination: AppDestination,
        count: Int? = nil,
        caption: String? = nil,
        isAlert: Bool = false
    ) -> some View {
        Label {
            HStack(spacing: 6) {
                Text(destination.title)

                Spacer(minLength: 0)

                if let count, count > 0 || caption != nil {
                    if isAlert {
                        Text("\(count)")
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(.red, in: Capsule())
                    } else {
                        Text("\(count)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .monospacedDigit()
                    }
                }

                if let caption {
                    Text(caption)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        } icon: {
            Image(systemName: destination.symbolName)
                .foregroundStyle(isAlert ? Color.red : Theme.color(for: destination))
        }
        .tag(destination)
    }

    // MARK: - 数据

    private var counts: (all: Int, attention: Int, empty: Int, expiring: Int) {
        InventoryFilter.counts(for: allMaterials)
    }

    private var archivedCount: Int {
        allMaterials.filter(\.isArchived).count
    }

    private var transactionCount: Int {
        allMaterials.reduce(0) { $0 + $1.entries.count }
    }

    private var categoryCounts: [MaterialCategory: Int] {
        Dictionary(grouping: allMaterials.filter { !$0.isArchived }, by: { $0.category })
            .mapValues(\.count)
    }

    /// 只列出实际有材料的分类，避免侧边栏被 12 个空分类撑满。
    private var categoriesInUse: [MaterialCategory] {
        categoryCounts
            .filter { $0.value > 0 }
            .keys
            .sorted { $0.sortIndex < $1.sortIndex }
    }
}

// MARK: - 图标着色

private extension Theme {
    /// 给侧边栏图标一个稳定的颜色。没有专属色的目的地退回到灰蓝。
    static func color(for destination: AppDestination) -> Color {
        if let category = destination.category {
            return color(for: category)
        }
        switch destination {
        case .dashboard: return .indigo
        case .allMaterials: return .blue
        case .lowStock: return .orange
        case .expiring: return .pink
        case .archived: return .gray
        case .scanHistory: return .teal
        case .transactions: return .purple
        case .labels: return .brown
        case .settings: return .gray
        case .category: return .gray
        }
    }
}
