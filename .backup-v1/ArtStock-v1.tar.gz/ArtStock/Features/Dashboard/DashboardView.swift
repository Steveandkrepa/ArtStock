//
//  DashboardView.swift
//  ArtStock — 美术材料余量管理
//
//  iPad 三栏布局中间栏的**总览**页面。
//  目标是让用户一打开就知道"今天该补什么、什么快过期了"。
//

import SwiftData
import SwiftUI

struct DashboardView: View {

    @Bindable var nav: NavigationModel

    @Query private var allMaterials: [Material]

    @Environment(\.horizontalSizeClass) private var horizontalSizeClass

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                hero
                statGrid

                if !restockList.isEmpty {
                    restockSection
                }

                categorySection

                if !expiringList.isEmpty {
                    expiringSection
                }

                if allMaterials.isEmpty {
                    emptyCard
                }
            }
            .padding(20)
        }
        .artScrollEdgeEffect()
        .navigationTitle("总览")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - 数据

    private var statistics: InventoryStatistics {
        InventoryService.statistics(for: allMaterials)
    }

    private var activeMaterials: [Material] {
        allMaterials.filter { !$0.isArchived }
    }

    private var restockList: [Material] {
        Array(InventoryService.materialsNeedingRestock(from: allMaterials).prefix(6))
    }

    private var expiringList: [Material] {
        Array(InventoryService.expiringMaterials(from: allMaterials).prefix(5))
    }

    private var categorySummary: [(category: MaterialCategory, count: Int)] {
        statistics.categoryCounts
            .filter { $0.value > 0 }
            .map { (category: $0.key, count: $0.value) }
            .sorted { $0.count > $1.count }
    }

    // MARK: - 头部

    private var hero: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(greeting)
                .font(.title2.weight(.semibold))

            Text("当前在库 \(statistics.totalCount) 种材料"
                 + (statistics.attentionCount > 0
                    ? "，其中 \(statistics.attentionCount) 种需要补货"
                    : "，余量都还充足"))
                .font(.subheadline)
                .foregroundStyle(.secondary)

            if statistics.attentionCount > 0 {
                Button {
                    nav.select(.lowStock)
                } label: {
                    Label("查看待补货清单", systemImage: "exclamationmark.triangle.fill")
                }
                .artProminentButton()
                .controlSize(.regular)
                .padding(.top, 4)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(20)
        .background(
            LinearGradient(
                colors: [Theme.color(for: .pigment).opacity(0.18),
                         Theme.color(for: .medium).opacity(0.10)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 18, style: .continuous)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(Theme.color(for: .pigment).opacity(0.22), lineWidth: 0.5)
        }
        // 官方文档中的 BannerView 用法：让背景延伸到相邻区域。
        // 在已留白的容器里是安全的空操作，视觉上只在有可用安全区时才生效。
        .artBackgroundExtension()
    }

    private var greeting: String {
        let hour = Calendar.current.component(.hour, from: .now)
        switch hour {
        case 5..<11: return "早上好"
        case 11..<14: return "中午好"
        case 14..<18: return "下午好"
        case 18..<23: return "晚上好"
        default: return "夜深了"
        }
    }

    // MARK: - 指标卡

    private var statGrid: some View {
        LazyVGrid(
            columns: [GridItem(.adaptive(minimum: 150, maximum: 260), spacing: 12)],
            spacing: 12
        ) {
            StatCard(
                title: "在库材料",
                value: "\(statistics.totalCount)",
                symbolName: "shippingbox.fill",
                tint: .blue,
                caption: statistics.archivedCount > 0 ? "另有 \(statistics.archivedCount) 条已归档" : nil
            )

            StatCard(
                title: "待补货",
                value: "\(statistics.attentionCount)",
                symbolName: "exclamationmark.triangle.fill",
                tint: statistics.attentionCount > 0 ? .orange : .green,
                caption: statistics.emptyCount > 0 ? "含 \(statistics.emptyCount) 种已用完" : "余量低于预警阈值"
            )

            StatCard(
                title: "临期",
                value: "\(statistics.expiringCount)",
                symbolName: "calendar.badge.exclamationmark",
                tint: statistics.expiringCount > 0 ? .pink : .green,
                caption: "30 天内到期"
            )

            StatCard(
                title: "库存价值",
                value: Fmt.currencyCompact(statistics.totalValue),
                symbolName: "yensign.circle.fill",
                tint: .purple,
                caption: "按单价 × 余量估算"
            )
        }
    }

    // MARK: - 待补货

    private var restockSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                SectionHeader(title: "最需要补货", subtitle: "按紧急程度排序")
                Spacer()
                Button("全部") { nav.select(.lowStock) }
                    .font(.subheadline)
            }

            VStack(spacing: 0) {
                ForEach(Array(restockList.enumerated()), id: \.element.persistentModelID) { index, material in
                    Button {
                        nav.focus(on: material)
                    } label: {
                        MaterialRow(material: material, showsChevron: true)
                    }
                    .buttonStyle(.plain)

                    if index < restockList.count - 1 {
                        Divider().padding(.leading, 50)
                    }
                }
            }
            .cardStyle(padding: 12)
        }
    }

    // MARK: - 分类分布

    private var categorySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "分类分布")

            VStack(spacing: 10) {
                ForEach(categorySummary, id: \.category) { entry in
                    Button {
                        nav.select(.category(entry.category))
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: entry.category.symbolName)
                                .font(.caption)
                                .foregroundStyle(Theme.color(for: entry.category))
                                .frame(width: 22)

                            Text(entry.category.displayName)
                                .font(.subheadline)
                                .foregroundStyle(.primary)

                            Spacer(minLength: 8)

                            // 用一条比例条表达占比，比纯数字更快看懂结构。
                            GeometryReader { geometry in
                                let ratio = statistics.totalCount > 0
                                    ? CGFloat(entry.count) / CGFloat(statistics.totalCount)
                                    : 0
                                Capsule()
                                    .fill(Theme.color(for: entry.category).opacity(0.75))
                                    .frame(width: max(4, geometry.size.width * ratio))
                            }
                            .frame(width: 80, height: 6)

                            Text("\(entry.count)")
                                .font(.subheadline.weight(.medium))
                                .monospacedDigit()
                                .foregroundStyle(.secondary)
                                .frame(width: 30, alignment: .trailing)
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
            .cardStyle()
        }
    }

    // MARK: - 临期

    private var expiringSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                SectionHeader(title: "临期提醒", subtitle: "30 天内到期或已过期")
                Spacer()
                Button("全部") { nav.select(.expiring) }
                    .font(.subheadline)
            }

            VStack(spacing: 0) {
                ForEach(Array(expiringList.enumerated()), id: \.element.persistentModelID) { index, material in
                    Button {
                        nav.focus(on: material)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: material.isExpired
                                  ? "xmark.octagon.fill" : "clock.badge.exclamationmark.fill")
                                .foregroundStyle(material.isExpired ? .red : .orange)
                                .frame(width: 26)

                            VStack(alignment: .leading, spacing: 2) {
                                Text(material.name)
                                    .font(.subheadline.weight(.medium))
                                    .foregroundStyle(.primary)
                                Text(material.code)
                                    .font(.system(.caption2, design: .monospaced))
                                    .foregroundStyle(.tertiary)
                            }

                            Spacer(minLength: 8)

                            if let expiry = material.expiryDate {
                                Text(Fmt.expiryDescription(expiry))
                                    .font(.caption)
                                    .foregroundStyle(material.isExpired ? .red : .orange)
                            }
                        }
                        .padding(.vertical, 8)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)

                    if index < expiringList.count - 1 {
                        Divider().padding(.leading, 38)
                    }
                }
            }
            .cardStyle(padding: 12)
        }
    }

    // MARK: - 空库引导

    private var emptyCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("还没有任何材料档案", systemImage: "sparkles")
                .font(.headline)

            Text("点右下角的扫码按钮，对着材料上的二维码扫一下就能建档；没有二维码的材料可以在建档表单里手工填编码。")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }
}
