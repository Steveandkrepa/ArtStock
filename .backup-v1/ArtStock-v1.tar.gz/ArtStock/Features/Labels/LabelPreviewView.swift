//
//  LabelPreviewView.swift
//  ArtStock — 美术材料余量管理
//
//  二维码标签排版、预览、导出 PDF 与 AirPrint。
//
//  为什么用 PDF 而不是直接打印图片：PDF 是矢量容器，二维码在里面是
//  嵌入位图但排版尺寸精确可控，A4 上按毫米对齐，打不干胶不会错位。
//

import SwiftData
import SwiftUI
import UIKit

struct LabelPreviewView: View {

    /// 要打印的材料。传空数组表示"全部在库材料"。
    var selectedMaterials: [Material] = []

    @Query private var allMaterials: [Material]

    @State private var layoutName: String = LabelLayout.presetNames.first ?? "小标签 40×30"
    @State private var options = LabelOptions(showPrice: false)
    @State private var pdfURL: URL?
    @State private var exportError: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                summaryCard
                layoutCard
                optionsCard
                previewCard
                actionCard
            }
            .padding(20)
            .frame(maxWidth: 760)
            .frame(maxWidth: .infinity)
        }
        .artScrollEdgeEffect()
        .navigationTitle("标签打印")
        .navigationBarTitleDisplayMode(.inline)
        .alert("导出失败", isPresented: .presentWhen($exportError)) {
            Button("知道了") { exportError = nil }
        } message: {
            Text(exportError ?? "")
        }
    }

    // MARK: - 数据

    private var layout: LabelLayout {
        LabelLayout.preset(named: layoutName)
    }

    private var materials: [Material] {
        let source = selectedMaterials.isEmpty ? allMaterials : selectedMaterials
        return source
            .filter { !$0.isArchived }
            .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    private var pageCount: Int {
        guard !materials.isEmpty else { return 0 }
        return Int(ceil(Double(materials.count) / Double(layout.perPage)))
    }

    // MARK: - 概览

    private var summaryCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(
                title: selectedMaterials.count == 1 ? "单张标签" : "批量标签",
                subtitle: "共 \(materials.count) 条材料，预计 \(pageCount) 页 A4"
            )

            HStack(spacing: 16) {
                metric(title: "每页", value: "\(layout.perPage) 张")
                metric(title: "单张尺寸", value: labelSizeText)
                metric(title: "行列", value: "\(layout.columns) × \(layout.rows)")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    private var labelSizeText: String {
        // 点 → 毫米：1 pt = 1/72 inch，1 inch = 25.4 mm
        let widthMM = layout.labelSize.width / 72 * 25.4
        let heightMM = layout.labelSize.height / 72 * 25.4
        return String(format: "%.0f × %.0f mm", widthMM, heightMM)
    }

    private func metric(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title)
                .font(.caption2)
                .foregroundStyle(.tertiary)
            Text(value)
                .font(.subheadline.weight(.medium))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - 版面

    private var layoutCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "版面规格", subtitle: "按你的不干胶尺寸选择")

            Picker("版面", selection: $layoutName) {
                ForEach(LabelLayout.presetNames, id: \.self) { name in
                    Text(name).tag(name)
                }
            }
            .pickerStyle(.segmented)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    // MARK: - 内容选项

    private var optionsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "标签内容", subtitle: "二维码始终包含，其余按需勾选")

            VStack(spacing: 2) {
                Toggle("材料名称", isOn: $options.showName)
                Toggle("编码", isOn: $options.showCode)
                Toggle("规格", isOn: $options.showSpecification)
                Toggle("存放位置", isOn: $options.showLocation)
                Toggle("分类", isOn: $options.showCategory)
                Toggle("单价", isOn: $options.showPrice)
            }
            .font(.subheadline)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    // MARK: - 预览

    private var previewCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "预览", subtitle: "前 \(min(materials.count, 6)) 张")

            if materials.isEmpty {
                Text("没有可打印的材料。")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 14) {
                        ForEach(materials.prefix(6)) { material in
                            VStack(spacing: 6) {
                                if let image = LabelRenderer.image(
                                    for: material,
                                    size: CGSize(width: 300, height: 200),
                                    options: options,
                                    scale: 2
                                ) {
                                    Image(uiImage: image)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 220)
                                        .background(.white, in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                                        .overlay {
                                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                                .strokeBorder(Color(uiColor: .separator), lineWidth: 0.5)
                                        }
                                }

                                Text(material.name)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                                    .frame(width: 220)
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    // MARK: - 操作

    private var actionCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "输出", subtitle: "PDF 可以直接 AirPrint，也可以存到「文件」再拿去打印店")

            HStack(spacing: 12) {
                Button {
                    printLabels()
                } label: {
                    Label("打印", systemImage: "printer.fill")
                        .frame(maxWidth: .infinity)
                }
                .artProminentButton()
                .controlSize(.large)
                .disabled(materials.isEmpty)

                if let pdfURL {
                    ShareLink(item: pdfURL) {
                        Label("分享 PDF", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity)
                    }
                    .artGlassButton()
                    .controlSize(.large)
                } else {
                    Button {
                        exportPDF()
                    } label: {
                        Label("生成 PDF", systemImage: "doc.richtext")
                            .frame(maxWidth: .infinity)
                    }
                    .artGlassButton()
                    .controlSize(.large)
                    .disabled(materials.isEmpty)
                }
            }

            if pdfURL != nil {
                Button("重新生成（内容有改动时）") {
                    pdfURL = nil
                }
                .font(.caption)
                .buttonStyle(.borderless)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    // MARK: - 动作

    private func makePDFData() -> Data {
        LabelRenderer.pdfData(for: materials, layout: layout, options: options)
    }

    private func exportPDF() {
        do {
            let data = makePDFData()
            let filename = InventoryCSVExporter.defaultFilename(prefix: "ArtStock-标签", fileExtension: "pdf")
            let directory = FileManager.default.temporaryDirectory
                .appendingPathComponent("ArtStockExport", isDirectory: true)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let url = directory.appendingPathComponent(filename)
            try data.write(to: url, options: .atomic)
            pdfURL = url
            Haptics.saved()
        } catch {
            exportError = error.localizedDescription
        }
    }

    private func printLabels() {
        let controller = UIPrintInteractionController.shared

        let info = UIPrintInfo.printInfo()
        info.outputType = .general
        info.jobName = "ArtStock 材料标签"
        controller.printInfo = info
        controller.printingItem = makePDFData()

        controller.present(animated: true) { _, _, error in
            if let error {
                exportError = error.localizedDescription
            }
        }
    }
}
