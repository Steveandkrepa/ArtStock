//
//  TransactionHistoryView.swift
//  ArtStock — 美术材料余量管理
//
//  全库出入库流水。支持按类型筛选与 CSV 导出。
//

import SwiftData
import SwiftUI

struct TransactionHistoryView: View {

    @Environment(\.modelContext) private var context

    @Query(sort: \StockEntry.createdAt, order: .reverse)
    private var allEntries: [StockEntry]

    @State private var kindFilter: StockEntryKind?
    @State private var exportURL: URL?
    @State private var exportError: String?

    var body: some View {
        Group {
            if filteredEntries.isEmpty {
                EmptyState(
                    title: "暂无出入库记录",
                    message: allEntries.isEmpty
                        ? "建档或调整余量后，这里会按时间记录每一次变动。"
                        : "当前筛选条件下没有记录。",
                    symbolName: "arrow.left.arrow.right",
                    actionTitle: kindFilter == nil ? nil : "清除筛选"
                ) {
                    kindFilter = nil
                }
            } else {
                listContent
            }
        }
        .navigationTitle("出入库流水")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { toolbarContent }
        .alert("导出失败", isPresented: .presentWhen($exportError)) {
            Button("知道了") { exportError = nil }
        } message: {
            Text(exportError ?? "")
        }
    }

    // MARK: - 列表

    private var listContent: some View {
        List {
            ForEach(groupedByDay, id: \.day) { group in
                Section {
                    ForEach(group.entries) { entry in
                        StockEntryRow(entry: entry)
                    }
                } header: {
                    HStack {
                        Text(Fmt.date(group.day))
                        Spacer()
                        Text("\(group.entries.count) 条")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .artScrollEdgeEffect()
    }

    // MARK: - 数据

    private var filteredEntries: [StockEntry] {
        guard let kindFilter else { return allEntries }
        return allEntries.filter { $0.kind == kindFilter }
    }

    private var groupedByDay: [(day: Date, entries: [StockEntry])] {
        let calendar = Calendar.current
        let groups = Dictionary(grouping: filteredEntries) { entry in
            calendar.startOfDay(for: entry.createdAt)
        }
        return groups
            .map { (day: $0.key, entries: $0.value.sorted { $0.createdAt > $1.createdAt }) }
            .sorted { $0.day > $1.day }
    }

    // MARK: - 工具栏

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) {
            Menu {
                Button {
                    kindFilter = nil
                } label: {
                    Label("全部类型", systemImage: kindFilter == nil ? "checkmark" : "circle.dashed")
                }

                Divider()

                ForEach(StockEntryKind.allCases) { kind in
                    Button {
                        kindFilter = kind
                    } label: {
                        Label(kind.displayName,
                              systemImage: kindFilter == kind ? "checkmark" : kind.symbolName)
                    }
                }
            } label: {
                Label("筛选", systemImage: kindFilter == nil
                      ? "line.3.horizontal.decrease.circle"
                      : "line.3.horizontal.decrease.circle.fill")
            }
            .accessibilityLabel("按类型筛选")
        }

        ToolbarItem(placement: .topBarTrailing) {
            Menu {
                if let exportURL {
                    ShareLink(item: exportURL) {
                        Label("分享 CSV 文件", systemImage: "square.and.arrow.up")
                    }
                } else {
                    Button {
                        exportCSV()
                    } label: {
                        Label("生成 CSV 文件", systemImage: "tablecells")
                    }
                }
            } label: {
                Image(systemName: "square.and.arrow.up")
            }
            .disabled(filteredEntries.isEmpty)
            .accessibilityLabel("导出")
        }
    }

    // MARK: - 导出

    private func exportCSV() {
        do {
            let csv = InventoryCSVExporter.csv(from: filteredEntries)
            exportURL = try InventoryCSVExporter.writeTemporaryFile(
                contents: csv,
                filename: InventoryCSVExporter.defaultFilename(prefix: "ArtStock-流水")
            )
        } catch {
            exportError = error.localizedDescription
        }
    }
}
