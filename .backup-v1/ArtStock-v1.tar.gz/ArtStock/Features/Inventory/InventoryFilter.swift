//
//  InventoryFilter.swift
//  ArtStock — 美术材料余量管理
//
//  材料清单的筛选与排序。
//
//  刻意全部在内存里做，不用 #Predicate：本地库规模是"几百到几千条"，
//  内存过滤的耗时可忽略，但换来的是可以任意组合条件、按计算属性排序
//  （余量状态、紧急度都是计算出来的，SQL 层表达不了）。
//

import Foundation

// MARK: - 排序

enum MaterialSortOrder: String, CaseIterable, Identifiable, Sendable {
    /// 最紧急的排前面（余量 / 阈值的比值升序）。
    case urgency
    case name
    case recentlyUpdated
    case leastQuantity
    case category
    case location

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .urgency: return "缺料优先"
        case .name: return "按名称"
        case .recentlyUpdated: return "最近更新"
        case .leastQuantity: return "余量最少"
        case .category: return "按分类"
        case .location: return "按位置"
        }
    }

    var symbolName: String {
        switch self {
        case .urgency: return "exclamationmark.triangle"
        case .name: return "textformat.abc"
        case .recentlyUpdated: return "clock.arrow.circlepath"
        case .leastQuantity: return "arrow.down.to.line"
        case .category: return "square.grid.2x2"
        case .location: return "mappin.and.ellipse"
        }
    }
}

// MARK: - 余量状态筛选

enum StockLevelFilter: String, CaseIterable, Identifiable, Sendable {
    case all
    case needsAttention
    case empty
    case low
    case healthy
    case expiring

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .all: return "全部"
        case .needsAttention: return "需补货"
        case .empty: return "已用完"
        case .low: return "余量偏低"
        case .healthy: return "充足"
        case .expiring: return "临期"
        }
    }

    func matches(_ material: Material) -> Bool {
        switch self {
        case .all: return true
        case .needsAttention: return material.stockLevel.needsAttention
        case .empty: return material.stockLevel == .empty
        case .low: return material.stockLevel == .low
        case .healthy: return material.stockLevel == .healthy
        case .expiring: return material.isExpiringSoon || material.isExpired
        }
    }
}

// MARK: - 组合器

enum InventoryFilter {

    /// 按目的地、搜索词、状态筛选并排序。
    /// - Parameters:
    ///   - materials: 全量档案。
    ///   - destination: 当前侧边栏目的地。
    ///   - searchText: 搜索词。
    ///   - levelFilter: 额外状态筛选。
    ///   - sortOrder: 排序方式。
    static func apply(
        to materials: [Material],
        destination: AppDestination,
        searchText: String,
        levelFilter: StockLevelFilter,
        sortOrder: MaterialSortOrder
    ) -> [Material] {

        var result = materials

        // 1) 目的地决定的域
        switch destination {
        case .archived:
            result = result.filter(\.isArchived)

        case .category(let category):
            result = result.filter { !$0.isArchived && $0.category == category }

        case .lowStock:
            result = result.filter { !$0.isArchived && $0.stockLevel.needsAttention }

        case .expiring:
            result = result.filter { !$0.isArchived && ($0.isExpiringSoon || $0.isExpired) }

        default:
            // 总览、全部材料等默认只看未归档。
            result = result.filter { !$0.isArchived }
        }

        // 2) 状态筛选
        if levelFilter != .all {
            result = result.filter { levelFilter.matches($0) }
        }

        // 3) 搜索
        let needle = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if !needle.isEmpty {
            // 支持空格分隔的多关键词，全部命中才算匹配。
            let terms = needle.split(separator: " ").map(String.init)
            result = result.filter { material in
                let haystack = material.searchableText
                return terms.allSatisfy { haystack.contains($0) }
            }
        }

        // 4) 排序
        return sort(result, by: sortOrder)
    }

    static func sort(_ materials: [Material], by order: MaterialSortOrder) -> [Material] {
        switch order {
        case .urgency:
            return materials.sorted {
                if abs($0.urgency - $1.urgency) > 0.0001 { return $0.urgency < $1.urgency }
                return $0.name.localizedStandardCompare($1.name) == .orderedAscending
            }

        case .name:
            return materials.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }

        case .recentlyUpdated:
            return materials.sorted { $0.updatedAt > $1.updatedAt }

        case .leastQuantity:
            return materials.sorted {
                if $0.quantity != $1.quantity { return $0.quantity < $1.quantity }
                return $0.name.localizedStandardCompare($1.name) == .orderedAscending
            }

        case .category:
            return materials.sorted {
                if $0.category.sortIndex != $1.category.sortIndex {
                    return $0.category.sortIndex < $1.category.sortIndex
                }
                return $0.name.localizedStandardCompare($1.name) == .orderedAscending
            }

        case .location:
            return materials.sorted { left, right in
                // 没填位置的排最后，而不是被当成空字符串排最前。
                let leftBlank = left.location.isBlank
                let rightBlank = right.location.isBlank
                if leftBlank != rightBlank { return rightBlank }
                if !leftBlank, left.location != right.location {
                    return left.location.localizedStandardCompare(right.location) == .orderedAscending
                }
                return left.name.localizedStandardCompare(right.name) == .orderedAscending
            }
        }
    }

    /// 统计各状态的条数，用于侧边栏角标与筛选条。
    static func counts(for materials: [Material]) -> (all: Int, attention: Int, empty: Int, expiring: Int) {
        let active = materials.filter { !$0.isArchived }
        return (
            all: active.count,
            attention: active.filter { $0.stockLevel.needsAttention }.count,
            empty: active.filter { $0.stockLevel == .empty }.count,
            expiring: active.filter { $0.isExpiringSoon || $0.isExpired }.count
        )
    }
}
