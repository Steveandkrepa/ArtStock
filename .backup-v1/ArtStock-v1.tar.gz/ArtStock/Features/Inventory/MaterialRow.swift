//
//  MaterialRow.swift
//  ArtStock — 美术材料余量管理
//
//  材料行的统一外观。列表视图、搜索建议、看板列表都用它，
//  保证同一条材料在任何地方看起来是一致的。
//

import SwiftUI

struct MaterialRow: View {

    let material: Material

    /// 是否显示右侧箭头（在 NavigationLink 里不需要）。
    var showsChevron: Bool = false

    /// 紧凑模式：用于横向空间受限的场景，去掉进度条与副标题。
    var isCompact: Bool = false

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            CategoryIcon(category: material.category, size: isCompact ? 30 : 38)

            VStack(alignment: .leading, spacing: 5) {
                titleLine
                if !isCompact { codeLine }
                if !isCompact, let ratio = material.fillRatio {
                    FillGauge(ratio: ratio, level: material.stockLevel, height: 6)
                        .frame(maxWidth: 160)
                }
            }

            Spacer(minLength: 8)

            trailingColumn

            if showsChevron {
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.tertiary)
                    .padding(.top, 6)
            }
        }
        .padding(.vertical, Theme.rowVerticalPadding)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
        .accessibilityLabel(accessibilityText)
    }

    // MARK: - 行内片段

    private var titleLine: some View {
        HStack(spacing: 6) {
            Text(material.name)
                .font(isCompact ? .subheadline.weight(.medium) : .body.weight(.medium))
                .lineLimit(1)

            if material.isExpired {
                Image(systemName: "calendar.badge.exclamationmark")
                    .font(.caption2)
                    .foregroundStyle(.red)
                    .accessibilityLabel("已过期")
            } else if material.isExpiringSoon {
                Image(systemName: "calendar.badge.clock")
                    .font(.caption2)
                    .foregroundStyle(.orange)
                    .accessibilityLabel("临近有效期")
            }
        }
    }

    private var codeLine: some View {
        HStack(spacing: 6) {
            Text(material.code)
                .font(.system(.caption2, design: .monospaced))
                .foregroundStyle(.tertiary)
                .lineLimit(1)

            if !material.subtitle.isBlank {
                Text("·")
                    .font(.caption2)
                    .foregroundStyle(.quaternary)
                Text(material.subtitle)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        }
    }

    private var trailingColumn: some View {
        VStack(alignment: .trailing, spacing: 5) {
            Text(material.quantityText)
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .monospacedDigit()
                .contentTransition(.numericText())

            StockLevelBadge(level: material.stockLevel, compact: true)
        }
    }

    private var accessibilityText: String {
        var parts = [material.name, material.code, "余量 \(material.quantityText)", material.stockLevel.displayName]
        if !material.location.isBlank { parts.append("位置 \(material.location)") }
        return parts.joined(separator: "，")
    }
}

// MARK: - 选择态包装

/// 让 MaterialRow 在 List 选中时有一致的背景表现。
/// SwiftUI 的 List 选中样式会作用在整行，这里只需要保证行本身可点。
extension MaterialRow {

    /// 用于看板 / 搜索结果等不需要选中的场景。
    static func plain(_ material: Material, compact: Bool = false) -> some View {
        MaterialRow(material: material, isCompact: compact)
    }
}
