//
//  StockAdjustSheet.swift
//  ArtStock — 美术材料余量管理
//
//  出入库操作面板。扫码流程用的是 ExistingMaterialSheet（信息更全），
//  这个是从详情页发起的聚焦版本：只做一件事——改余量。
//

import SwiftData
import SwiftUI

struct StockAdjustSheet: View {

    let material: Material

    /// 完成回调。
    var onDone: (StockAdjustmentResult) -> Void

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var kind: StockEntryKind
    @State private var amount: Double
    @State private var note: String = ""
    @FocusState private var isAmountFocused: Bool

    init(
        material: Material,
        initialKind: StockEntryKind = .consume,
        onDone: @escaping (StockAdjustmentResult) -> Void
    ) {
        self.material = material
        self.onDone = onDone
        // 盘点语义是"目标绝对值"，默认填当前余量最符合直觉。
        _kind = State(initialValue: initialKind)
        _amount = State(initialValue: initialKind == .adjust ? material.quantity : material.unit.step)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Text("当前余量")
                        Spacer()
                        Text(material.quantityText)
                            .font(.system(.body, design: .rounded).weight(.semibold))
                            .monospacedDigit()
                    }
                    StockLevelBadge(level: material.stockLevel)
                } header: {
                    Text(material.name)
                }

                Section {
                    Picker("操作类型", selection: $kind) {
                        ForEach(StockEntryKind.selectableKinds) { kind in
                            Label(kind.displayName, systemImage: kind.symbolName).tag(kind)
                        }
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: kind) { _, newValue in
                        Haptics.selection()
                        amount = newValue == .adjust ? material.quantity : material.unit.step
                    }

                    HStack {
                        Text(kind == .adjust ? "盘点后余量" : "数量")
                        Spacer()
                        QuantityStepper(value: $amount, unit: material.unit)
                            .focused($isAmountFocused)
                    }

                    if kind == .adjust {
                        Button {
                            amount = material.capacity
                        } label: {
                            Label("填满至 \(Fmt.quantity(material.capacity, unit: material.unit))",
                                  systemImage: "arrow.up.to.line")
                        }
                        .disabled(material.capacity <= 0)

                        Button {
                            amount = 0
                        } label: {
                            Label("清空归零", systemImage: "arrow.down.to.line")
                        }
                    }

                    LabeledContent("备注") {
                        TextField("选填", text: $note)
                            .multilineTextAlignment(.trailing)
                    }
                } footer: {
                    if let preview = deltaPreview {
                        Text(preview)
                    }
                }
            }
            .formStyle(.grouped)
            .navigationTitle("调整余量")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("确认") { confirm() }
                        .fontWeight(.semibold)
                }
            }
        }
        .presentationDetents([.medium])
    }

    // MARK: - 预览

    private var deltaPreview: String? {
        let before = material.quantity

        let after: Double
        if kind.amountSemantic == .absolute {
            after = max(0, amount).rounded(for: material.unit)
        } else {
            let raw = kind.isIncrease ? before + abs(amount) : before - abs(amount)
            after = max(0, raw).rounded(for: material.unit)
        }

        guard abs(after - before) > 0.0001 else {
            return "余量不变（\(Fmt.quantity(before, unit: material.unit))）"
        }
        return "调整后：\(Fmt.quantity(after, unit: material.unit))"
    }

    private func confirm() {
        let result = InventoryService.apply(
            kind: kind,
            amount: amount,
            to: material,
            note: note,
            in: context
        )

        if result.wasClamped {
            Haptics.alert()
        } else {
            Haptics.saved()
        }

        onDone(result)
        dismiss()
    }
}
