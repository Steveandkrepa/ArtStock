//
//  MaterialDetailView.swift
//  ArtStock — 美术材料余量管理
//
//  iPad 三栏布局的**详情栏**。信息密度刻意做高——用户站在材料柜前，
//  需要一眼看到"还剩多少、放哪、什么时候到期、最近谁动过"。
//

import SwiftData
import SwiftUI

struct MaterialDetailView: View {

    let material: Material

    @Environment(\.modelContext) private var context
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass

    @State private var adjustKind: StockEntryKind?
    @State private var isShowingEditor = false
    @State private var isShowingLabels = false
    @State private var isShowingDeleteConfirm = false
    @State private var lastResult: StockAdjustmentResult?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                headerCard
                if material.stockLevel.needsAttention { attentionBanner }
                actionRow
                quantityCard
                infoCard
                labelCard
                historyCard
            }
            .padding(20)
            .frame(maxWidth: 720)
            .frame(maxWidth: .infinity)
        }
        .artScrollEdgeEffect()
        .navigationTitle(material.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { toolbarContent }
        .sheet(item: $adjustKind) { kind in
            StockAdjustSheet(material: material, initialKind: kind) { result in
                lastResult = result
            }
        }
        .sheet(isPresented: $isShowingEditor) {
            MaterialEditorView(form: MaterialFormModel(material: material)) { _ in }
        }
        .sheet(isPresented: $isShowingLabels) {
            LabelPreviewView(selectedMaterials: [material])
        }
        .alert("确认删除？", isPresented: $isShowingDeleteConfirm) {
            Button("删除", role: .destructive) { deleteMaterial() }
            Button("取消", role: .cancel) {}
        } message: {
            Text("将同时删除该材料的 \(material.entries.count) 条出入库流水，操作不可撤销。如果只是想停用，建议改为归档。")
        }
        .alert("操作完成", isPresented: .presentWhen($lastResult)) {
            Button("好") { lastResult = nil }
        } message: {
            Text(lastResult?.summary ?? "")
        }
    }

    // MARK: - 头部

    private var headerCard: some View {
        HStack(alignment: .top, spacing: 16) {
            photoOrIcon

            VStack(alignment: .leading, spacing: 8) {
                Text(material.name)
                    .font(.title2.weight(.semibold))
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 8) {
                    Label(material.category.displayName, systemImage: material.category.symbolName)
                        .font(.caption)
                        .foregroundStyle(Theme.color(for: material.category))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Theme.iconBackground(for: material.category), in: Capsule())

                    StockLevelBadge(level: material.stockLevel)

                    if material.isArchived {
                        Text("已归档")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color(uiColor: .tertiarySystemFill), in: Capsule())
                    }
                }

                Text(material.code)
                    .font(.system(.subheadline, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)

                if !material.subtitle.isBlank {
                    Text(material.subtitle)
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                }
            }

            Spacer(minLength: 0)
        }
        .cardStyle()
    }

    @ViewBuilder
    private var photoOrIcon: some View {
        if let data = material.photoData, let image = UIImage(data: data) {
            Image(uiImage: image)
                .resizable()
                .scaledToFill()
                .frame(width: 92, height: 92)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        } else {
            Group {
                if let hex = Color(hex: material.colorHex) {
                    // 有标色号的材料优先显示颜色，这对颜料类最直观。
                    hex
                } else {
                    Color(uiColor: .tertiarySystemFill)
                }
            }
            .frame(width: 92, height: 92)
            .overlay {
                Image(systemName: material.category.symbolName)
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(Color(hex: material.colorHex) == nil
                                     ? Theme.color(for: material.category)
                                     : .white.opacity(0.92))
            }
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
    }

    // MARK: - 预警

    private var attentionBanner: some View {
        NoticeBanner(
            level: material.stockLevel == .empty ? .error : .warning,
            title: material.stockLevel == .empty ? "该材料已用完" : "余量低于预警阈值",
            message: "当前 \(material.quantityText)，预警阈值 \(Fmt.quantity(material.lowStockThreshold, unit: material.unit))"
        )
    }

    // MARK: - 操作

    private var actionRow: some View {
        HStack(spacing: 10) {
            Button {
                adjustKind = .consume
            } label: {
                Label("领用", systemImage: "arrow.up.circle.fill")
                    .frame(maxWidth: .infinity)
            }
            .artProminentButton()
            .controlSize(.large)

            Button {
                adjustKind = .restock
            } label: {
                Label("入库", systemImage: "arrow.down.circle.fill")
                    .frame(maxWidth: .infinity)
            }
            .artGlassButton()
            .controlSize(.large)

            Button {
                adjustKind = .adjust
            } label: {
                Label("盘点", systemImage: "slider.horizontal.3")
                    .frame(maxWidth: .infinity)
            }
            .artGlassButton()
            .controlSize(.large)
        }
    }

    // MARK: - 余量

    private var quantityCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                Text("余量")
                    .font(.headline)
                Spacer()
                Text(material.quantityText)
                    .font(.system(.largeTitle, design: .rounded).weight(.bold))
                    .monospacedDigit()
                    .contentTransition(.numericText())
            }

            FillGauge(ratio: material.fillRatio, level: material.stockLevel, height: 12)

            HStack(spacing: 20) {
                metric(title: "满量",
                       value: material.capacity > 0
                       ? Fmt.quantity(material.capacity, unit: material.unit) : "未标注")
                metric(title: "占比",
                       value: material.fillRatio.map { Fmt.percent($0) } ?? "—")
                metric(title: "预警阈值",
                       value: Fmt.quantity(material.lowStockThreshold, unit: material.unit))
                metric(title: "库存价值",
                       value: material.unitPrice > 0
                       ? Fmt.currencyCompact(material.unitPrice * material.quantity) : "—")
            }
        }
        .cardStyle()
    }

    private func metric(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title)
                .font(.caption2)
                .foregroundStyle(.tertiary)
            Text(value)
                .font(.subheadline.weight(.medium))
                .monospacedDigit()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - 详细信息

    private var infoCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "档案信息")

            VStack(spacing: 9) {
                InfoRow(label: "品牌", value: material.brand, symbolName: "building.2")
                InfoRow(label: "规格", value: material.specification, symbolName: "ruler")
                InfoRow(label: "单位", value: "\(material.unit.displayName)（\(material.unit.abbreviation)）",
                        symbolName: "scale.3d")
                InfoRow(label: "存放位置", value: material.location, symbolName: "mappin.and.ellipse")
                InfoRow(label: "供应商", value: material.supplier, symbolName: "truck.box")
                InfoRow(label: "单价", value: material.unitPrice > 0 ? Fmt.currency(material.unitPrice) : "",
                        symbolName: "yensign.circle")
                InfoRow(label: "色号", value: material.colorHex, symbolName: "paintpalette")
                InfoRow(label: "建档时间", value: Fmt.dateTime(material.createdAt), symbolName: "calendar.badge.plus")
                InfoRow(label: "最近更新", value: Fmt.relative(material.updatedAt), symbolName: "clock")
                if let opened = material.openedAt {
                    InfoRow(label: "开封日期", value: Fmt.date(opened), symbolName: "shippingbox")
                }
                if let expiry = material.expiryDate {
                    InfoRow(label: "有效期", value: Fmt.expiryDescription(expiry),
                            symbolName: "calendar.badge.exclamationmark",
                            tint: material.isExpired ? .red : (material.isExpiringSoon ? .orange : .secondary))
                }
            }

            if !material.notes.isBlank {
                Divider()
                VStack(alignment: .leading, spacing: 4) {
                    Text("备注")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(material.notes)
                        .font(.subheadline)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    // MARK: - 二维码

    private var labelCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "二维码标签", subtitle: material.qrPayload.isBlank
                          ? "自描述标签（含名称、分类、单位等字段）"
                          : "沿用建档时扫到的原始编码")

            HStack(alignment: .top, spacing: 16) {
                if let image = QRCodeGenerator.image(for: material.effectiveQRPayload,
                                                     scale: 6, quietZoneModules: 2) {
                    Image(uiImage: image)
                        .interpolation(.none)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 132, height: 132)
                        .padding(8)
                        .background(.white, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("把这个码贴在材料上，下次扫一下就能直接领用或入库。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)

                    Button {
                        isShowingLabels = true
                    } label: {
                        Label("生成打印标签", systemImage: "printer")
                    }
                    .artGlassButton()

                    ShareLink(
                        item: material.effectiveQRPayload,
                        subject: Text(material.name),
                        message: Text("ArtStock 材料编码")
                    ) {
                        Label("分享编码内容", systemImage: "square.and.arrow.up")
                    }
                    .font(.subheadline)
                }

                Spacer(minLength: 0)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    // MARK: - 流水

    private var historyCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                SectionHeader(title: "出入库流水",
                              subtitle: material.entries.isEmpty ? "暂无记录" : "共 \(material.entries.count) 条")
                Spacer()
            }

            if sortedEntries.isEmpty {
                Text("还没有任何余量变动记录。")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(sortedEntries.prefix(8).enumerated()), id: \.element.id) { index, entry in
                        StockEntryRow(entry: entry, showsMaterialName: false)
                        if index < min(sortedEntries.count, 8) - 1 {
                            Divider().padding(.leading, 34)
                        }
                    }
                }

                if sortedEntries.count > 8 {
                    Text("仅显示最近 8 条，完整记录见「出入库流水」。")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }

    private var sortedEntries: [StockEntry] {
        material.entries.sorted { $0.createdAt > $1.createdAt }
    }

    // MARK: - 工具栏

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) {
            Button {
                isShowingEditor = true
            } label: {
                Image(systemName: "square.and.pencil")
            }
            .keyboardShortcut("e", modifiers: .command)
            .accessibilityLabel("编辑档案")
        }

        ToolbarItem(placement: .topBarTrailing) {
            Menu {
                Button {
                    isShowingLabels = true
                } label: {
                    Label("打印标签", systemImage: "printer")
                }

                Button {
                    InventoryService.setArchived(!material.isArchived, for: material, in: context)
                } label: {
                    Label(material.isArchived ? "取消归档" : "归档",
                          systemImage: material.isArchived ? "tray.and.arrow.up" : "archivebox")
                }

                Divider()

                Button(role: .destructive) {
                    isShowingDeleteConfirm = true
                } label: {
                    Label("删除档案", systemImage: "trash")
                }
            } label: {
                Image(systemName: "ellipsis.circle")
            }
            .accessibilityLabel("更多操作")
        }
    }

    // MARK: - 删除

    private func deleteMaterial() {
        InventoryService.delete(material, in: context)
    }
}

// MARK: - 流水行

struct StockEntryRow: View {
    let entry: StockEntry
    var showsMaterialName: Bool = true

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: entry.kind.symbolName)
                .font(.callout)
                .foregroundStyle(tint)
                .frame(width: 24)

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(entry.kind.displayName)
                        .font(.subheadline.weight(.medium))
                    if showsMaterialName, let material = entry.material {
                        Text(material.name)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }

                HStack(spacing: 6) {
                    Text(Fmt.dateTime(entry.createdAt))
                    if !entry.operatorName.isBlank {
                        Text("·")
                        Text(entry.operatorName)
                    }
                    if !entry.note.isBlank {
                        Text("·")
                        Text(entry.note).lineLimit(1)
                    }
                }
                .font(.caption2)
                .foregroundStyle(.tertiary)
            }

            Spacer(minLength: 8)

            VStack(alignment: .trailing, spacing: 3) {
                Text(entry.deltaText)
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                    .monospacedDigit()
                    .foregroundStyle(tint)
                Text("余 \(Fmt.number(entry.balanceAfter))")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .monospacedDigit()
            }
        }
        .padding(.vertical, 8)
    }

    private var tint: Color {
        let delta = entry.signedDelta
        if delta > 0 { return .green }
        if delta < 0 { return .red }
        return .secondary
    }
}
