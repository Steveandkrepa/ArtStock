//
//  InventoryBrowserView.swift
//  ArtStock — 美术材料余量管理
//
//  iPad 三栏布局的**中间栏**：材料清单。
//
//  两种形态自动切换：
//    · 常规宽度（iPad 横屏、分屏较宽）→ Table，可排序的多列表格，最像 iPad 原生
//    · 紧凑宽度（分屏窄、iPhone）→ List，一行一条，信息密度更高
//

import SwiftData
import SwiftUI

struct InventoryBrowserView: View {

    @Bindable var nav: NavigationModel

    @Environment(\.modelContext) private var context
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass

    /// 用于 ⌘F 聚焦搜索框。
    @FocusState private var isSearchFocused: Bool

    /// 全量数据。本地库规模有限，筛选排序全部放内存。
    @Query private var allMaterials: [Material]

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularTable
            } else {
                compactList
            }
        }
        .navigationTitle(nav.currentTitle)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(
            text: $nav.searchText,
            placement: .navigationBarDrawer(displayMode: .always),
            prompt: "搜索名称、编码、位置、供应商"
        )
        .modifier(SearchFocusBridge(isFocused: $isSearchFocused))
        .toolbar { toolbarContent }
        .overlay {
            if filteredMaterials.isEmpty {
                emptyState
            }
        }
    }

    // MARK: - 数据

    private var currentDestination: AppDestination {
        nav.destination ?? .dashboard
    }

    /// 筛选 + 排序后的结果。
    private var filteredMaterials: [Material] {
        var result = InventoryFilter.apply(
            to: allMaterials,
            destination: currentDestination,
            searchText: nav.searchText,
            levelFilter: nav.levelFilter,
            sortOrder: nav.sortOrder
        )

        // 总览只展示最需要关注的若干条，避免和「全部材料」完全重复。
        if currentDestination == .dashboard, nav.searchText.isBlank, nav.levelFilter == .all {
            result = Array(result.prefix(12))
        }
        return result
    }

    private var counts: (all: Int, attention: Int, empty: Int, expiring: Int) {
        InventoryFilter.counts(for: allMaterials)
    }

    // MARK: - 常规宽度：表格

    private var regularTable: some View {
        Table(filteredMaterials, selection: $nav.selectedMaterialID) {
            TableColumn("名称") { material in
                HStack(spacing: 10) {
                    CategoryIcon(category: material.category, size: 28)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(material.name)
                            .font(.subheadline.weight(.medium))
                            .lineLimit(1)
                        if !material.subtitle.isBlank {
                            Text(material.subtitle)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                        }
                    }
                }
                .padding(.vertical, 3)
            }
            .width(min: 180, ideal: 240)

            TableColumn("余量") { material in
                VStack(alignment: .leading, spacing: 4) {
                    Text(material.quantityText)
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .monospacedDigit()
                    if let ratio = material.fillRatio {
                        FillGauge(ratio: ratio, level: material.stockLevel, height: 4)
                            .frame(width: 72)
                    }
                }
            }
            .width(min: 92, ideal: 110)

            TableColumn("状态") { material in
                StockLevelBadge(level: material.stockLevel, compact: true)
            }
            .width(min: 80, ideal: 96)

            TableColumn("位置") { material in
                Text(material.location.isBlank ? "—" : material.location)
                    .font(.caption)
                    .foregroundStyle(material.location.isBlank ? .tertiary : .secondary)
                    .lineLimit(1)
            }
            .width(min: 90, ideal: 140)

            TableColumn("更新") { material in
                Text(Fmt.relative(material.updatedAt))
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
            }
            .width(min: 70, ideal: 90)
        }
        .tableStyle(.inset)
        .artScrollEdgeEffect()
    }

    // MARK: - 紧凑宽度：列表

    private var compactList: some View {
        List(selection: $nav.selectedMaterialID) {
            if !nav.searchText.isBlank {
                Section {
                    ForEach(filteredMaterials) { material in
                        MaterialRow(material: material)
                            .tag(material.persistentModelID)
                    }
                } header: {
                    Text("\(filteredMaterials.count) 条结果")
                }
            } else {
                Section {
                    ForEach(filteredMaterials) { material in
                        MaterialRow(material: material)
                            .tag(material.persistentModelID)
                    }
                } header: {
                    Text(currentDestination.browserSubtitle)
                }
            }
        }
        .listStyle(.insetGrouped)
        .artScrollEdgeEffect()
    }

    // MARK: - 空状态

    @ViewBuilder
    private var emptyState: some View {
        if !nav.searchText.isBlank {
            EmptyState(
                title: "没有匹配的材料",
                message: "换个关键词试试，或者扫一下材料的二维码直接建档。",
                symbolName: "magnifyingglass",
                actionTitle: "清空搜索"
            ) {
                nav.searchText = ""
            }
        } else {
            switch currentDestination {
            case .lowStock:
                EmptyState(
                    title: "没有需要补货的材料",
                    message: "所有在库材料的余量都在预警阈值之上。",
                    symbolName: "checkmark.seal.fill"
                )
            case .expiring:
                EmptyState(
                    title: "没有临期材料",
                    message: "30 天内没有材料到期。",
                    symbolName: "calendar.badge.checkmark"
                )
            case .archived:
                EmptyState(
                    title: "没有归档的材料",
                    message: "归档用于隐藏停用材料，同时保留历史流水。",
                    symbolName: "archivebox"
                )
            default:
                EmptyState(
                    title: "还没有材料档案",
                    message: "扫一下材料上的二维码就能建立档案；没有标签的材料可以手工录入编码。",
                    symbolName: "qrcode.viewfinder"
                )
            }
        }
    }

    // MARK: - 工具栏

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) {
            Button {
                isSearchFocused = true
            } label: {
                Image(systemName: "magnifyingglass")
            }
            .keyboardShortcut("f", modifiers: .command)
            .accessibilityLabel("搜索")
        }

        ToolbarItem(placement: .topBarTrailing) {
            Menu {
                Picker("排序", selection: $nav.sortOrder) {
                    ForEach(MaterialSortOrder.allCases) { order in
                        Label(order.displayName, systemImage: order.symbolName).tag(order)
                    }
                }
                .pickerStyle(.inline)
            } label: {
                Label("排序", systemImage: "arrow.up.arrow.down")
            }
            .accessibilityLabel("排序方式：\(nav.sortOrder.displayName)")
        }

        ToolbarItem(placement: .topBarTrailing) {
            Menu {
                Picker("筛选", selection: $nav.levelFilter) {
                    ForEach(StockLevelFilter.allCases) { filter in
                        Text(filter.displayName).tag(filter)
                    }
                }
                .pickerStyle(.inline)

                Divider()

                Button {
                    nav.levelFilter = .all
                } label: {
                    Label("重置筛选", systemImage: "arrow.counterclockwise")
                }
            } label: {
                Label("筛选", systemImage: nav.levelFilter == .all
                      ? "line.3.horizontal.decrease.circle"
                      : "line.3.horizontal.decrease.circle.fill")
            }
            .accessibilityLabel("筛选：\(nav.levelFilter.displayName)")
        }
    }
}

// MARK: - 搜索聚焦桥接

/// `searchFocused(_:)` 是 **iOS 18.0+** 才引入的 API。
/// 本工程部署目标是 iOS 17.0，因此必须做可用性桥接，否则直接编译失败。
/// iOS 17 上该修饰符为空实现：搜索框仍可正常使用，只是 ⌘F 不会自动聚焦。
private struct SearchFocusBridge: ViewModifier {

    let isFocused: FocusState<Bool>.Binding

    func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content.searchFocused(isFocused)
        } else {
            content
        }
    }
}
