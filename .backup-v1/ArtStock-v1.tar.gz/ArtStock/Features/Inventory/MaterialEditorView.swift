//
//  MaterialEditorView.swift
//  ArtStock — 美术材料余量管理
//
//  建档 / 编辑表单。扫码草稿进来时字段已经预填好，用户只需要确认与补录。
//

import PhotosUI
import SwiftData
import SwiftUI

struct MaterialEditorView: View {

    @Bindable var form: MaterialFormModel

    /// 保存 / 取消后的回调。参数为保存成功的档案（取消时为 nil）。
    var onFinish: (Material?) -> Void

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var photoItem: PhotosPickerItem?
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                if form.source != nil || !form.qrPayload.isBlank {
                    scanOriginSection
                }

                basicSection
                quantitySection
                storageSection
                scheduleSection
                photoSection
                qrSection
                notesSection

                if !form.validationIssues.isEmpty {
                    issuesSection
                }
            }
            .formStyle(.grouped)
            .artScrollEdgeEffect()
            .navigationTitle(form.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") {
                        onFinish(nil)
                        dismiss()
                    }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { save() }
                        .disabled(!form.canSave)
                        .fontWeight(.semibold)
                }
            }
        }
        .alert("无法保存", isPresented: .presentWhen($errorMessage)) {
            Button("知道了") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
        .onChange(of: photoItem) { _, newValue in
            guard let newValue else { return }
            Task {
                if let data = try? await newValue.loadTransferable(type: Data.self) {
                    // 统一压缩，避免几百条档案把磁盘吃满。
                    form.photoData = ImageProcessing.downscaledJPEGData(from: data) ?? data
                }
            }
        }
    }

    // MARK: - 扫码来源

    private var scanOriginSection: some View {
        Section {
            if let source = form.source {
                InfoRow(label: "解析来源", value: source.displayName,
                        symbolName: source.symbolName, tint: .blue)
                InfoRow(label: "符号类型", value: ScanSymbology.displayName(forRawValue: form.symbologyRaw),
                        symbolName: "barcode.viewfinder")
            }

            if !form.qrPayload.isBlank {
                DisclosureGroup("查看二维码原始内容") {
                    Text(form.qrPayload)
                        .font(.system(.caption, design: .monospaced))
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 4)
                }
            }

            ForEach(form.parseWarnings, id: \.self) { warning in
                Label(warning, systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        } header: {
            Text("扫码信息")
        } footer: {
            Text("原始内容会随档案一起保存，之后重新生成标签时优先沿用同一个码。")
        }
    }

    // MARK: - 基本信息

    private var basicSection: some View {
        Section("基本信息") {
            LabeledContent("编码") {
                TextField("如 ART-PIG-0001", text: $form.code)
                    .multilineTextAlignment(.trailing)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .font(.system(.body, design: .monospaced))
            }

            LabeledContent("名称") {
                TextField("材料名称", text: $form.name)
                    .multilineTextAlignment(.trailing)
            }

            Picker("分类", selection: $form.category) {
                ForEach(MaterialCategory.allCases) { category in
                    Label(category.displayName, systemImage: category.symbolName)
                        .tag(category)
                }
            }

            LabeledContent("品牌") {
                TextField("选填", text: $form.brand)
                    .multilineTextAlignment(.trailing)
            }

            LabeledContent("规格") {
                TextField("如 37mL 管装", text: $form.specification)
                    .multilineTextAlignment(.trailing)
            }

            Picker("单位", selection: $form.unit) {
                ForEach(MeasurementUnit.allCases) { unit in
                    Text("\(unit.displayName)（\(unit.abbreviation)）").tag(unit)
                }
            }
        }
    }

    // MARK: - 余量

    private var quantitySection: some View {
        Section {
            LabeledContent("余量") {
                HStack(spacing: 6) {
                    TextField("0", value: $form.quantity, format: .number.precision(.fractionLength(0...2)))
                        .keyboardType(form.unit.allowsFraction ? .decimalPad : .numberPad)
                        .multilineTextAlignment(.trailing)
                    Text(form.unit.abbreviation)
                        .foregroundStyle(.secondary)
                }
            }

            LabeledContent("满量") {
                HStack(spacing: 6) {
                    TextField("0", value: $form.capacity, format: .number.precision(.fractionLength(0...2)))
                        .keyboardType(form.unit.allowsFraction ? .decimalPad : .numberPad)
                        .multilineTextAlignment(.trailing)
                    Text(form.unit.abbreviation)
                        .foregroundStyle(.secondary)
                }
            }

            LabeledContent("预警阈值") {
                HStack(spacing: 6) {
                    TextField("0", value: $form.lowStockThreshold, format: .number.precision(.fractionLength(0...2)))
                        .keyboardType(form.unit.allowsFraction ? .decimalPad : .numberPad)
                        .multilineTextAlignment(.trailing)
                    Text(form.unit.abbreviation)
                        .foregroundStyle(.secondary)
                }
            }
        } header: {
            Text("余量")
        } footer: {
            if form.isEditing {
                Text("修改余量会作为一次「盘点」记入流水，可在历史记录中追溯。")
            } else {
                Text("满量用于计算余量百分比；填 0 表示不标注容量。低于预警阈值时会出现在待补货清单里。")
            }
        }
    }

    // MARK: - 存放与采购

    private var storageSection: some View {
        Section("存放与采购") {
            LabeledContent("位置") {
                TextField("如 颜料柜 A-1", text: $form.location)
                    .multilineTextAlignment(.trailing)
            }

            LabeledContent("供应商") {
                TextField("选填", text: $form.supplier)
                    .multilineTextAlignment(.trailing)
            }

            LabeledContent("单价") {
                HStack(spacing: 4) {
                    Text("¥").foregroundStyle(.secondary)
                    TextField("0", text: $form.unitPriceText)
                        .keyboardType(.decimalPad)
                        .multilineTextAlignment(.trailing)
                }
            }

            // 美术材料的色号是核心属性，做一个色板 + 十六进制输入。
            LabeledContent("色号") {
                HStack(spacing: 10) {
                    ColorPicker("", selection: colorBinding, supportsOpacity: false)
                        .labelsHidden()

                    TextField("#RRGGBB", text: $form.colorHex)
                        .multilineTextAlignment(.trailing)
                        .font(.system(.body, design: .monospaced))
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.characters)
                }
            }

            if !form.colorHex.isBlank, let swatch = Color(hex: form.colorHex) {
                HStack(spacing: 10) {
                    ForEach(suggestedHexes, id: \.self) { hex in
                        Button {
                            form.colorHex = hex
                        } label: {
                            Circle()
                                .fill(Color(hex: hex) ?? .gray)
                                .frame(width: 26, height: 26)
                                .overlay {
                                    Circle().strokeBorder(.separator, lineWidth: 0.5)
                                }
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("使用颜色 \(hex)")
                    }
                    Spacer()
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(swatch)
                        .frame(width: 44, height: 26)
                }
            }
        }
    }

    /// 常用色板。美术材料高频颜色，省得每次开取色器。
    private let suggestedHexes = [
        "#D6303A", "#F08030", "#F2C200", "#3E9B4F",
        "#2E5BFF", "#7B4FA8", "#8B5A2B", "#1C1C1E"
    ]

    private var colorBinding: Binding<Color> {
        Binding(
            get: { Color(hex: form.colorHex) ?? .gray },
            set: { newValue in
                if let hex = newValue.toHex() { form.colorHex = hex }
            }
        )
    }

    // MARK: - 时间

    private var scheduleSection: some View {
        Section("时间") {
            Toggle("标注有效期", isOn: $form.hasExpiry.animation())
            if form.hasExpiry {
                DatePicker("有效期至", selection: $form.expiryDate, displayedComponents: .date)
            }

            Toggle("记录开封日期", isOn: $form.hasOpenedAt.animation())
            if form.hasOpenedAt {
                DatePicker("开封日期", selection: $form.openedAt, displayedComponents: .date)
            }
        }
    }

    // MARK: - 照片

    private var photoSection: some View {
        Section("参考照片") {
            if let data = form.photoData, let image = UIImage(data: data) {
                HStack(spacing: 14) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 76, height: 76)
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

                    VStack(alignment: .leading, spacing: 6) {
                        Text("已附加照片")
                            .font(.subheadline)
                        Text(ByteCountFormatter.string(fromByteCount: Int64(data.count), countStyle: .file))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    Button(role: .destructive) {
                        form.photoData = nil
                        photoItem = nil
                    } label: {
                        Image(systemName: "trash")
                    }
                    .buttonStyle(.borderless)
                }
            }

            PhotosPicker(selection: $photoItem, matching: .images) {
                Label(form.photoData == nil ? "从相册选择" : "更换照片", systemImage: "photo.on.rectangle.angled")
            }
        }
    }

    // MARK: - 二维码

    private var qrSection: some View {
        Section {
            HStack(alignment: .top, spacing: 16) {
                if let image = QRCodeGenerator.image(for: qrPreviewPayload, scale: 6, quietZoneModules: 2) {
                    Image(uiImage: image)
                        .interpolation(.none)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 116, height: 116)
                        .padding(6)
                        .background(.white, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                } else {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(Color(uiColor: .tertiarySystemFill))
                        .frame(width: 128, height: 128)
                        .overlay {
                            Text("编码为空")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text(form.qrPayload.isBlank ? "将写入自描述标签" : "沿用扫到的原始编码")
                        .font(.subheadline.weight(.medium))

                    Text(form.qrPayload.isBlank
                         ? "标签内容包含编码、名称、分类、单位等字段，其他设备扫到也能直接读懂。"
                         : "该档案由扫码创建，重新打印时仍使用同一个二维码内容，不影响已有标签。")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    if !form.qrPayload.isBlank {
                        Button("改用自描述标签") {
                            form.qrPayload = ""
                        }
                        .font(.caption)
                        .buttonStyle(.borderless)
                    }
                }
            }
            .padding(.vertical, 4)
        } header: {
            Text("二维码标签")
        }
    }

    /// 预览用的载荷。
    private var qrPreviewPayload: String {
        if !form.qrPayload.isBlank { return form.qrPayload }
        guard !form.code.isBlank else { return "" }
        return QRCodeGenerator.payload(for: form.makeMaterial())
    }

    // MARK: - 备注

    private var notesSection: some View {
        Section("备注") {
            TextEditor(text: $form.notes)
                .frame(minHeight: 88)
                .font(.body)
        }
    }

    // MARK: - 校验提示

    private var issuesSection: some View {
        Section {
            ForEach(form.validationIssues, id: \.self) { issue in
                Label(issue, systemImage: "exclamationmark.circle.fill")
                    .font(.footnote)
                    .foregroundStyle(form.blockingIssues.contains(issue) ? .red : .orange)
            }
        } header: {
            Text("请检查")
        }
    }

    // MARK: - 保存

    private func save() {
        do {
            if form.isEditing {
                try InventoryService.update(form: form, in: context)
                Haptics.saved()
                onFinish(form.editingMaterial)
            } else {
                let material = try InventoryService.create(form: form, in: context)
                Haptics.saved()
                onFinish(material)
            }
            dismiss()
        } catch {
            Haptics.scanFailure()
            errorMessage = error.localizedDescription
        }
    }
}
