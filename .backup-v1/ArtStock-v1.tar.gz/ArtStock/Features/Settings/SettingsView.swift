//
//  SettingsView.swift
//  ArtStock — 美术材料余量管理
//
//  设置与数据维护。刻意保持朴素：这里不需要炫技，用户来这里是
//  导出数据、清库、看版本。
//

import AVFoundation
import SwiftData
import SwiftUI

struct SettingsView: View {

    let bootstrap: ArtStockBootstrap

    @Environment(\.modelContext) private var context

    @AppStorage("operatorName") private var operatorName: String = ""

    @Query private var materials: [Material]
    @Query private var entries: [StockEntry]
    @Query private var scans: [ScanRecord]

    @State private var exportURL: URL?
    @State private var exportError: String?
    @State private var isShowingResetConfirm = false
    @State private var resetDone = false

    var body: some View {
        Form {
            if bootstrap.isDegraded {
                Section {
                    NoticeBanner(
                        level: .error,
                        title: "当前运行在临时内存库上",
                        message: bootstrap.degradedReason ?? ""
                    )
                } footer: {
                    Text("数据不会被保存，退出 App 后即丢失。请到下方「重置数据库」后再重新录入。")
                }
            }

            operatorSection
            appearanceSection
            statisticsSection
            exportSection
            maintenanceSection
            cameraSection
            aboutSection
        }
        .formStyle(.grouped)
        .artScrollEdgeEffect()
        .navigationTitle("设置")
        .navigationBarTitleDisplayMode(.inline)
        .alert("导出失败", isPresented: .presentWhen($exportError)) {
            Button("知道了") { exportError = nil }
        } message: {
            Text(exportError ?? "")
        }
        .alert("确认重置数据库？", isPresented: $isShowingResetConfirm) {
            Button("删除全部数据", role: .destructive) { resetStore() }
            Button("取消", role: .cancel) {}
        } message: {
            Text("将删除磁盘上的 \(materials.count) 条材料档案、\(entries.count) 条流水与 \(scans.count) 条扫码记录。建议先导出 CSV 备份。此操作不可撤销。")
        }
        .alert("已清除数据库文件", isPresented: $resetDone) {
            Button("好") {}
        } message: {
            Text("请完全退出 App（从多任务界面划掉）后重新打开，新的空数据库会被自动建立。")
        }
    }

    // MARK: - 操作人

    private var operatorSection: some View {
        Section {
            LabeledContent("操作人") {
                TextField("留空则不记录", text: $operatorName)
                    .multilineTextAlignment(.trailing)
            }
        } header: {
            Text("操作人")
        } footer: {
            Text("iPad 多人共用时建议填写。会写入每一条出入库流水，便于追溯是谁领用的。")
        }
    }

    // MARK: - 外观

    private var appearanceSection: some View {
        Section("外观") {
            HStack {
                Label("液态玻璃", systemImage: "sparkles")
                Spacer()
                Text(LiquidGlassSupport.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.trailing)
            }

            if !LiquidGlassSupport.isAvailable {
                Text("系统的液态玻璃外观需要 iOS 26 及以上。当前版本会使用与之一致的材质降级外观，功能完全不受影响。")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
        }
    }

    // MARK: - 统计

    private var statisticsSection: some View {
        Section("数据") {
            LabeledContent("材料档案", value: "\(materials.count) 条")
            LabeledContent("在库（未归档）", value: "\(materials.filter { !$0.isArchived }.count) 条")
            LabeledContent("出入库流水", value: "\(entries.count) 条")
            LabeledContent("扫码记录", value: "\(scans.count) 条")
            LabeledContent("数据库占用", value: storeSizeText)
        }
    }

    private var storeSizeText: String {
        let fileManager = FileManager.default
        guard let support = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return "—"
        }
        let names = ["ArtStock.store", "ArtStock.store-shm", "ArtStock.store-wal",
                     "default.store", "default.store-shm", "default.store-wal"]
        var total: Int64 = 0
        for name in names {
            let url = support.appendingPathComponent(name)
            if let attributes = try? fileManager.attributesOfItem(atPath: url.path),
               let size = attributes[.size] as? Int64 {
                total += size
            }
        }
        guard total > 0 else { return "—" }
        return ByteCountFormatter.string(fromByteCount: total, countStyle: .file)
    }

    // MARK: - 导出

    private var exportSection: some View {
        Section {
            if let exportURL {
                ShareLink(item: exportURL) {
                    Label("分享已生成的文件", systemImage: "square.and.arrow.up")
                }
            }

            Button {
                exportMaterials()
            } label: {
                Label("导出材料台账（CSV）", systemImage: "tablecells")
            }
            .disabled(materials.isEmpty)

            Button {
                exportTransactions()
            } label: {
                Label("导出出入库流水（CSV）", systemImage: "list.bullet.rectangle")
            }
            .disabled(entries.isEmpty)
        } header: {
            Text("导出")
        } footer: {
            Text("CSV 带 UTF-8 BOM，用 Excel 或 Numbers 直接打开不会乱码。文件生成在临时目录，分享出去后可自行保存。")
        }
    }

    private func exportMaterials() {
        do {
            let csv = InventoryCSVExporter.csv(from: materials)
            exportURL = try InventoryCSVExporter.writeTemporaryFile(
                contents: csv,
                filename: InventoryCSVExporter.defaultFilename(prefix: "ArtStock-材料台账")
            )
        } catch {
            exportError = error.localizedDescription
        }
    }

    private func exportTransactions() {
        do {
            let sorted = entries.sorted { $0.createdAt > $1.createdAt }
            let csv = InventoryCSVExporter.csv(from: sorted)
            exportURL = try InventoryCSVExporter.writeTemporaryFile(
                contents: csv,
                filename: InventoryCSVExporter.defaultFilename(prefix: "ArtStock-流水")
            )
        } catch {
            exportError = error.localizedDescription
        }
    }

    // MARK: - 维护

    private var maintenanceSection: some View {
        Section {
            Button {
                ScanInboxService.clearCompleted(in: context)
            } label: {
                Label("清空已处理的扫码记录", systemImage: "eraser")
            }
            .disabled(scans.allSatisfy { $0.status == .pending })

            Button(role: .destructive) {
                isShowingResetConfirm = true
            } label: {
                Label("重置数据库", systemImage: "trash")
            }
        } header: {
            Text("维护")
        } footer: {
            Text("重置会删除磁盘上的数据文件。因为运行中的容器无法原地重建，删除后需要完全退出并重新打开 App。")
        }
    }

    private func resetStore() {
        _ = ArtStockStore.destroyLocalStore()
        Haptics.alert()
        resetDone = true
    }

    // MARK: - 相机

    private var cameraSection: some View {
        Section("相机权限") {
            HStack {
                Label("扫码相机", systemImage: "camera.fill")
                Spacer()
                Text(cameraStatusText)
                    .font(.caption)
                    .foregroundStyle(cameraStatusColor)
            }

            if AVCaptureDevice.authorizationStatus(for: .video) != .authorized {
                Button {
                    guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                    UIApplication.shared.open(url)
                } label: {
                    Label("打开系统设置", systemImage: "gear")
                }
            }
        }
    }

    private var cameraStatusText: String {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: return "已授权"
        case .notDetermined: return "尚未询问"
        case .denied: return "已拒绝"
        case .restricted: return "受系统限制"
        @unknown default: return "未知"
        }
    }

    private var cameraStatusColor: Color {
        AVCaptureDevice.authorizationStatus(for: .video) == .authorized ? .green : .orange
    }

    // MARK: - 关于

    private var aboutSection: some View {
        Section {
            LabeledContent("应用", value: "ArtStock 材料余量")
            LabeledContent("版本", value: appVersion)
            LabeledContent("最低系统", value: "iOS / iPadOS 17.0")
            LabeledContent("数据存储", value: "仅本机，不联网")
        } header: {
            Text("关于")
        } footer: {
            Text("扫码识别与二维码生成全部在本机完成，App 不发送任何网络请求，也不使用 iCloud、推送或后台服务。卸载 App 会一并删除全部数据。")
        }
    }

    private var appVersion: String {
        let info = Bundle.main.infoDictionary
        let version = info?["CFBundleShortVersionString"] as? String ?? "1.0"
        let build = info?["CFBundleVersion"] as? String ?? "1"
        return "\(version) (\(build))"
    }
}
