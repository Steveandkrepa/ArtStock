//
//  Formatters.swift
//  ArtStock — 美术材料余量管理
//

import Foundation

/// 全应用统一的格式化入口。集中管理避免各处 Locale 不一致。
enum Fmt {

    // MARK: - 数字

    /// 去掉无意义的小数尾零：12.0 → "12"，12.50 → "12.5"。
    static func number(_ value: Double, maximumFractionDigits: Int = 2) -> String {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "zh_Hans_CN")
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = maximumFractionDigits
        formatter.minimumFractionDigits = 0
        formatter.usesGroupingSeparator = false
        return formatter.string(from: NSNumber(value: value)) ?? String(value)
    }

    /// 带单位的数量：`120 mL` / `3 支`。
    static func quantity(_ value: Double, unit: MeasurementUnit) -> String {
        let digits = unit.allowsFraction ? 2 : 0
        return "\(number(value, maximumFractionDigits: digits)) \(unit.abbreviation)"
    }

    /// 带符号的数量：`+120 mL` / `−30 mL`。
    static func signedQuantity(_ delta: Double, unit: MeasurementUnit) -> String {
        if delta == 0 { return "±0 \(unit.abbreviation)" }
        let digits = unit.allowsFraction ? 2 : 0
        let magnitude = number(abs(delta), maximumFractionDigits: digits)
        // 用真正的减号 U+2212 而不是连字符，视觉上更整齐。
        return delta > 0 ? "+\(magnitude) \(unit.abbreviation)" : "−\(magnitude) \(unit.abbreviation)"
    }

    /// 百分比：`42%`。
    static func percent(_ ratio: Double) -> String {
        "\(Int((ratio * 100).rounded()))%"
    }

    /// 单价。
    static func currency(_ value: Double) -> String {
        guard value > 0 else { return "—" }
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "zh_Hans_CN")
        formatter.numberStyle = .currency
        formatter.currencySymbol = "¥"
        formatter.maximumFractionDigits = 2
        return formatter.string(from: NSNumber(value: value)) ?? "¥\(number(value))"
    }

    /// 库存总价值。
    static func currencyCompact(_ value: Double) -> String {
        if value >= 10_000 {
            return "¥\(number(value / 10_000, maximumFractionDigits: 1))万"
        }
        return currency(value)
    }

    // MARK: - 日期

    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_Hans_CN")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()

    private static let dateTimeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_Hans_CN")
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        return formatter
    }()

    private static let monthDayFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_Hans_CN")
        formatter.dateFormat = "MM-dd"
        return formatter
    }()

    static func date(_ date: Date) -> String {
        dateFormatter.string(from: date)
    }

    static func dateTime(_ date: Date) -> String {
        dateTimeFormatter.string(from: date)
    }

    static func monthDay(_ date: Date) -> String {
        monthDayFormatter.string(from: date)
    }

    /// 相对时间：`刚刚` / `12 分钟前` / `3 天前`。
    static func relative(_ date: Date) -> String {
        let interval = Date.now.timeIntervalSince(date)
        if interval < 60 { return "刚刚" }
        if interval < 3600 { return "\(Int(interval / 60)) 分钟前" }
        if interval < 86_400 { return "\(Int(interval / 3600)) 小时前" }
        if interval < 86_400 * 30 { return "\(Int(interval / 86_400)) 天前" }
        return Fmt.date(date)
    }

    /// 距离到期还有多久。
    static func expiryDescription(_ date: Date) -> String {
        let days = Calendar.current.dateComponents([.day], from: Calendar.current.startOfDay(for: .now),
                                                   to: Calendar.current.startOfDay(for: date)).day ?? 0
        if days < 0 { return "已过期 \(abs(days)) 天" }
        if days == 0 { return "今天到期" }
        if days <= 30 { return "\(days) 天后到期" }
        return "有效至 \(Fmt.date(date))"
    }

    /// 时长。用于湿润计时器的倒计时与剩余时间显示。
    ///
    /// 刻意做成两段式而不是一律给到分钟：
    /// 十几小时的等待里精确到分没有意义，反而让人以为模型很准。
    /// 越接近补水时刻才越精确 —— 短时长精确到分，长时长只到小时。
    static func duration(_ interval: TimeInterval) -> String {
        let seconds = abs(interval)
        let positive = interval >= 0

        if seconds < 45 { return positive ? "不到 1 分钟" : "刚刚到" }

        if seconds < 3600 {
            return "\(Int((seconds / 60).rounded())) 分钟"
        }

        if seconds < 86_400 {
            let hours = Int(seconds / 3600)
            let minutes = Int((seconds.truncatingRemainder(dividingBy: 3600)) / 60)
            // 超过 6 小时就不报分钟了，精度是假的。
            if hours >= 6 || minutes == 0 { return "\(hours) 小时" }
            return "\(hours) 小时 \(minutes) 分"
        }

        let days = Int(seconds / 86_400)
        let hours = Int((seconds.truncatingRemainder(dividingBy: 86_400)) / 3600)
        if hours == 0 { return "\(days) 天" }
        return "\(days) 天 \(hours) 小时"
    }
}
