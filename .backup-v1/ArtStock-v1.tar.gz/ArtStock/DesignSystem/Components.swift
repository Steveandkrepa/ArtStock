//
//  Components.swift
//  ArtStock — 美术材料余量管理
//
//  跨页面复用的展示组件。只放"至少两处用到"的东西，
//  一次性组件留在各自页面里，避免这里变成垃圾桶。
//

import SwiftUI

// MARK: - 余量状态徽标

struct StockLevelBadge: View {
    let level: StockLevel
    var compact: Bool = false

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: level.symbolName)
                .font(.caption2)
            if !compact {
                Text(level.displayName)
                    .font(.caption.weight(.medium))
            }
        }
        .foregroundStyle(Theme.color(for: level))
        .padding(.horizontal, compact ? 6 : 8)
        .padding(.vertical, 4)
        .background(Theme.color(for: level).opacity(0.14), in: Capsule())
        .accessibilityLabel("余量状态：\(level.displayName)")
    }
}

// MARK: - 余量进度条

/// 余量占满量的比例条。未标注容量的材料退化成一条中性底线。
struct FillGauge: View {
    /// 0...1 的比例。nil 表示未标注满量。
    let ratio: Double?
    let level: StockLevel
    var height: CGFloat = 8

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color(uiColor: .tertiarySystemFill))

                if let ratio {
                    Capsule()
                        .fill(Theme.gradient(for: level))
                        .frame(width: max(geometry.size.width * ratio, ratio > 0 ? height : 0))
                }
            }
        }
        .frame(height: height)
        .accessibilityHidden(true)
    }
}

// MARK: - 分类图标

struct CategoryIcon: View {
    let category: MaterialCategory
    var size: CGFloat = 34

    var body: some View {
        Image(systemName: category.symbolName)
            .font(.system(size: size * 0.46, weight: .semibold))
            .foregroundStyle(Theme.color(for: category))
            .frame(width: size, height: size)
            .background(Theme.iconBackground(for: category), in: RoundedRectangle(cornerRadius: size * 0.3, style: .continuous))
    }
}

// MARK: - 指标卡

struct StatCard: View {
    let title: String
    let value: String
    let symbolName: String
    let tint: Color
    var caption: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: symbolName)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(tint)
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Text(value)
                .font(.system(.title2, design: .rounded).weight(.semibold))
                .foregroundStyle(.primary)
                .contentTransition(.numericText())

            if let caption {
                Text(caption)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .lineLimit(2)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }
}

// MARK: - 数量步进器

/// 带 +/- 按钮的数量输入。扫码领用场景下，绝大多数操作是 ±1，
/// 所以按钮做大、键盘只作为补充。
struct QuantityStepper: View {
    @Binding var value: Double
    let unit: MeasurementUnit
    /// 是否允许减到 0 以下（一般不允许）。
    var minimum: Double = 0

    private var step: Double { unit.step }

    var body: some View {
        HStack(spacing: 10) {
            stepButton(symbol: "minus", delta: -step)

            TextField("数量", value: $value, format: .number.precision(.fractionLength(0...2)))
                .keyboardType(unit.allowsFraction ? .decimalPad : .numberPad)
                .multilineTextAlignment(.center)
                .font(.system(.title3, design: .rounded).weight(.semibold))
                .frame(minWidth: 84)
                .padding(.vertical, 8)
                .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                .onChange(of: value) { _, newValue in
                    if newValue < minimum { value = minimum }
                }

            Text(unit.abbreviation)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .frame(minWidth: 24, alignment: .leading)

            stepButton(symbol: "plus", delta: step)
        }
    }

    private func stepButton(symbol: String, delta: Double) -> some View {
        Button {
            let next = (value + delta).rounded(for: unit)
            value = max(minimum, next)
            Haptics.selection()
        } label: {
            Image(systemName: symbol)
                .font(.title3.weight(.semibold))
                .frame(width: 44, height: 44)
                .background(Color(uiColor: .secondarySystemFill), in: Circle())
        }
        .buttonStyle(.plain)
        .disabled(symbol == "minus" && value <= minimum)
        .opacity(symbol == "minus" && value <= minimum ? 0.35 : 1)
        .accessibilityLabel(symbol == "plus" ? "增加" : "减少")
    }
}

// MARK: - 键值信息行

struct InfoRow: View {
    let label: String
    let value: String
    var symbolName: String?
    var tint: Color = .secondary

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            HStack(spacing: 6) {
                if let symbolName {
                    Image(systemName: symbolName)
                        .font(.caption)
                        .foregroundStyle(tint)
                }
                Text(label)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .frame(width: 104, alignment: .leading)

            Text(value.isBlank ? "—" : value)
                .font(.subheadline)
                .foregroundStyle(value.isBlank ? .tertiary : .primary)
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

// MARK: - 分组标题

struct SectionHeader: View {
    let title: String
    var subtitle: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.headline)
            if let subtitle {
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// MARK: - 空状态

/// 统一空状态外观，避免每个页面各写一套。
struct EmptyState: View {
    let title: String
    let message: String
    let symbolName: String
    var actionTitle: String?
    var action: (() -> Void)?

    var body: some View {
        ContentUnavailableView {
            Label(title, systemImage: symbolName)
        } description: {
            Text(message)
        } actions: {
            if let actionTitle, let action {
                Button(actionTitle, action: action)
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}

// MARK: - 页面级提示条

struct NoticeBanner: View {
    enum Level {
        case info, warning, error, success

        var tint: Color {
            switch self {
            case .info: return .blue
            case .warning: return .orange
            case .error: return .red
            case .success: return .green
            }
        }

        var symbolName: String {
            switch self {
            case .info: return "info.circle.fill"
            case .warning: return "exclamationmark.triangle.fill"
            case .error: return "xmark.octagon.fill"
            case .success: return "checkmark.circle.fill"
            }
        }
    }

    let level: Level
    let title: String
    var message: String?
    var actionTitle: String?
    var action: (() -> Void)?

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: level.symbolName)
                .foregroundStyle(level.tint)
                .font(.callout)

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.subheadline.weight(.medium))
                if let message {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 8)

            if let actionTitle, let action {
                Button(actionTitle, action: action)
                    .font(.caption.weight(.semibold))
                    .buttonStyle(.borderless)
            }
        }
        .padding(12)
        .background(level.tint.opacity(0.1), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .strokeBorder(level.tint.opacity(0.25), lineWidth: 0.5)
        }
    }
}
