//
//  Theme.swift
//  ArtStock — 美术材料余量管理
//
//  颜色与视觉常量。深色模式与浅色模式各自给一组语义色，
//  因为余量状态色和分类色在深色背景上直接沿用浅色会变得刺眼。
//

import SwiftUI

enum Theme {

    // MARK: - 布局

    static let cornerRadius: CGFloat = 14
    static let cardPadding: CGFloat = 16
    static let cardSpacing: CGFloat = 12
    static let rowVerticalPadding: CGFloat = 6

    /// iPad 上侧边栏的默认宽度。
    static let sidebarWidth: CGFloat = 240
    /// 三栏布局中列表栏的最小宽度。
    static let contentMinWidth: CGFloat = 340
    /// 详情栏的最小宽度，低于这个数值排版会挤。
    static let detailMinWidth: CGFloat = 420

    // MARK: - 状态色

    static func color(for level: StockLevel) -> Color {
        switch level {
        case .empty: return .red
        case .low: return .orange
        case .healthy: return .green
        }
    }

    /// 余量条的渐变色。
    static func gradient(for level: StockLevel) -> LinearGradient {
        let base = color(for: level)
        return LinearGradient(
            colors: [base.opacity(0.75), base],
            startPoint: .leading,
            endPoint: .trailing
        )
    }

    // MARK: - 分类色

    static func color(for category: MaterialCategory) -> Color {
        switch category {
        case .pigment: return Color(red: 0.36, green: 0.30, blue: 0.92)
        case .ink: return Color(red: 0.20, green: 0.42, blue: 0.78)
        case .paper: return Color(red: 0.72, green: 0.55, blue: 0.30)
        case .canvas: return Color(red: 0.82, green: 0.66, blue: 0.44)
        case .brush: return Color(red: 0.85, green: 0.36, blue: 0.30)
        case .medium: return Color(red: 0.24, green: 0.66, blue: 0.60)
        case .solvent: return Color(red: 0.32, green: 0.60, blue: 0.86)
        case .adhesive: return Color(red: 0.90, green: 0.62, blue: 0.22)
        case .clay: return Color(red: 0.66, green: 0.40, blue: 0.26)
        case .tool: return Color(red: 0.45, green: 0.47, blue: 0.52)
        case .digital: return Color(red: 0.55, green: 0.36, blue: 0.86)
        case .other: return Color(red: 0.50, green: 0.52, blue: 0.56)
        }
    }

    /// 分类图标的底色（浅色模式淡、深色模式深）。
    static func iconBackground(for category: MaterialCategory) -> Color {
        color(for: category).opacity(0.16)
    }

    // MARK: - 扫码反馈色

    /// 扫码取景框的颜色。
    static let scannerAccent = Color(red: 0.30, green: 0.85, blue: 0.72)

    /// 扫码成功闪现色。
    static let scannerSuccess = Color.green

    /// 扫码失败 / 已存在提醒色。
    static let scannerWarning = Color.orange
}
