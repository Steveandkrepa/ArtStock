//
//  LabelRenderer.swift
//  ArtStock — 美术材料余量管理
//
//  二维码标签排版与 PDF 输出。用 UIGraphicsPDFRenderer 在本地绘制，
//  可以直接接 AirPrint，也可以存成 PDF 发到电脑上打不干胶。
//

import UIKit

/// 标签版面参数。
struct LabelLayout: Equatable {

    /// 纸张尺寸（点）。
    var pageSize: CGSize
    /// 单张标签尺寸（点）。
    var labelSize: CGSize
    /// 每页列数。
    var columns: Int
    /// 每页行数。
    var rows: Int
    /// 页边距。
    var margin: CGFloat

    /// 每页标签数。
    var perPage: Int { max(1, columns * rows) }

    /// A4 纵向（595 × 842 点）。
    static let a4 = CGSize(width: 595.2, height: 841.8)

    /// 常见的预置规格。
    static func preset(named name: String) -> LabelLayout {
        switch name {
        case "小标签 40×30":
            return LabelLayout(pageSize: a4, labelSize: CGSize(width: 113, height: 85),
                               columns: 4, rows: 9, margin: 24)
        case "中标签 60×40":
            return LabelLayout(pageSize: a4, labelSize: CGSize(width: 170, height: 113),
                               columns: 3, rows: 7, margin: 28)
        case "大标签 70×50":
            return LabelLayout(pageSize: a4, labelSize: CGSize(width: 198, height: 142),
                               columns: 2, rows: 5, margin: 36)
        default:
            return .small
        }
    }

    static let small = preset(named: "小标签 40×30")
    static let medium = preset(named: "中标签 60×40")
    static let large = preset(named: "大标签 70×50")

    static let presetNames = ["小标签 40×30", "中标签 60×40", "大标签 70×50"]
}

/// 标签上要印哪些信息。
struct LabelOptions {
    var showName: Bool = true
    var showCode: Bool = true
    var showSpecification: Bool = true
    var showLocation: Bool = true
    var showCategory: Bool = true
    var showPrice: Bool = false
}

enum LabelRenderer {

    /// 生成标签 PDF。所有材料按版面顺序铺排，满页自动翻页。
    static func pdfData(
        for materials: [Material],
        layout: LabelLayout = .small,
        options: LabelOptions = LabelOptions()
    ) -> Data {
        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = [
            kCGPDFContextTitle as String: "ArtStock 材料标签",
            kCGPDFContextCreator as String: "ArtStock"
        ]

        let bounds = CGRect(origin: .zero, size: layout.pageSize)
        let renderer = UIGraphicsPDFRenderer(bounds: bounds, format: format)

        return renderer.pdfData { pdfContext in
            guard !materials.isEmpty else {
                pdfContext.beginPage()
                return
            }

            var index = 0
            while index < materials.count {
                pdfContext.beginPage()

                let pageMaterials = materials[index..<min(index + layout.perPage, materials.count)]
                for (offset, material) in pageMaterials.enumerated() {
                    let column = offset % layout.columns
                    let row = offset / layout.columns

                    let origin = CGPoint(
                        x: layout.margin + CGFloat(column) * layout.labelSize.width,
                        y: layout.margin + CGFloat(row) * layout.labelSize.height
                    )
                    let rect = CGRect(origin: origin, size: layout.labelSize)
                    draw(material: material, in: rect, options: options, pdfContext: pdfContext)
                }

                index += layout.perPage
            }
        }
    }

    /// 生成单张标签图片，用于界面预览和"存到相册/分享单张"。
    static func image(
        for material: Material,
        size: CGSize = CGSize(width: 340, height: 227),
        options: LabelOptions = LabelOptions(),
        scale: CGFloat = 3
    ) -> UIImage? {
        let format = UIGraphicsImageRendererFormat()
        format.scale = scale
        format.opaque = true

        let renderer = UIGraphicsImageRenderer(size: size, format: format)
        return renderer.image { rendererContext in
            UIColor.white.setFill()
            rendererContext.fill(CGRect(origin: .zero, size: size))
            draw(material: material, in: CGRect(origin: .zero, size: size),
                 options: options, pdfContext: rendererContext)
        }
    }

    // MARK: - 绘制

    /// 统一绘制实现，图片与 PDF 共用（`UIGraphicsPDFRendererContext` 是
    /// `UIGraphicsRendererContext` 的子类，所以同一个函数能服务两者）。
    private static func draw(
        material: Material,
        in rect: CGRect,
        options: LabelOptions,
        pdfContext: UIGraphicsRendererContext
    ) {
        let context = pdfContext.cgContext
        context.saveGState()
        defer { context.restoreGState() }

        // 裁剪区域：标签外框（不画线，方便直接打在预切不干胶上）。
        context.clip(to: rect.insetBy(dx: 2, dy: 2))

        let padding: CGFloat = 6
        let contentRect = rect.insetBy(dx: padding, dy: padding)

        // ── 左侧二维码 ──
        let qrSide = min(contentRect.height, contentRect.width * 0.42)
        let qrRect = CGRect(x: contentRect.minX, y: contentRect.midY - qrSide / 2,
                            width: qrSide, height: qrSide)

        if let qrImage = QRCodeGenerator.image(for: material.effectiveQRPayload, scale: 8, quietZoneModules: 2) {
            qrImage.draw(in: qrRect)
        } else {
            // 编不出码时画个占位，避免标签上出现空白方块让人困惑。
            UIColor.systemGray5.setFill()
            UIBezierPath(roundedRect: qrRect, cornerRadius: 4).fill()
            let fallback = "无法生成" as NSString
            fallback.draw(at: CGPoint(x: qrRect.minX + 6, y: qrRect.midY - 6),
                          withAttributes: [
                            .font: UIFont.systemFont(ofSize: 8),
                            .foregroundColor: UIColor.systemGray
                          ])
        }

        // ── 右侧文字区 ──
        let textX = qrRect.maxX + padding
        let textWidth = contentRect.maxX - textX
        guard textWidth > 20 else { return }

        var cursorY = contentRect.minY + 1

        // 名称（最多两行）
        if options.showName {
            let nameStyle = NSMutableParagraphStyle()
            nameStyle.lineBreakMode = .byTruncatingTail
            let nameAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: max(9, qrSide * 0.13), weight: .semibold),
                .foregroundColor: UIColor.black,
                .paragraphStyle: nameStyle
            ]
            let nameRect = CGRect(x: textX, y: cursorY, width: textWidth, height: qrSide * 0.42)
            (material.name as NSString).draw(with: nameRect, options: [.usesLineFragmentOrigin],
                                             attributes: nameAttributes, context: nil)
            cursorY += qrSide * 0.34
        }

        // 编码（等宽，方便人眼核对）
        if options.showCode {
            let codeAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.monospacedSystemFont(ofSize: max(7, qrSide * 0.10), weight: .regular),
                .foregroundColor: UIColor.darkGray
            ]
            (material.code as NSString).draw(
                in: CGRect(x: textX, y: cursorY, width: textWidth, height: qrSide * 0.18),
                withAttributes: codeAttributes
            )
            cursorY += qrSide * 0.17
        }

        // 规格 / 位置 / 分类
        var detailParts: [String] = []
        if options.showSpecification, !material.specification.isBlank { detailParts.append(material.specification) }
        if options.showCategory { detailParts.append(material.category.displayName) }
        if options.showLocation, !material.location.isBlank { detailParts.append(material.location) }
        if options.showPrice, material.unitPrice > 0 { detailParts.append(Fmt.currency(material.unitPrice)) }

        if !detailParts.isEmpty {
            let detailAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: max(6.5, qrSide * 0.095)),
                .foregroundColor: UIColor.gray
            ]
            let detail = detailParts.joined(separator: " · ") as NSString
            let remaining = contentRect.maxY - cursorY
            if remaining > 6 {
                detail.draw(
                    in: CGRect(x: textX, y: cursorY, width: textWidth, height: remaining),
                    withAttributes: detailAttributes
                )
            }
        }
    }
}
