//
//  InventoryCSVExporter.swift
//  ArtStock — 美术材料余量管理
//
//  CSV 导出。带 UTF-8 BOM，否则 Excel 打开中文会乱码（这是最常见的投诉）。
//

import Foundation

enum InventoryCSVExporter {

    /// 导出材料台账。
    static func csv(from materials: [Material]) -> String {
        let header = [
            "编码", "名称", "分类", "品牌", "规格", "单位",
            "余量", "满量", "余量占比", "预警阈值", "状态",
            "存放位置", "供应商", "单价", "库存价值", "有效期", "开封日期",
            "是否归档", "备注"
        ]

        let rows = materials.map { material -> [String] in
            let ratio = material.fillRatio.map { Fmt.percent($0) } ?? ""
            return [
                material.code,
                material.name,
                material.category.displayName,
                material.brand,
                material.specification,
                material.unit.displayName,
                Fmt.number(material.quantity),
                material.capacity > 0 ? Fmt.number(material.capacity) : "",
                ratio,
                Fmt.number(material.lowStockThreshold),
                material.stockLevel.displayName,
                material.location,
                material.supplier,
                material.unitPrice > 0 ? Fmt.number(material.unitPrice) : "",
                material.unitPrice > 0 ? Fmt.number(material.unitPrice * material.quantity) : "",
                material.expiryDate.map { Fmt.date($0) } ?? "",
                material.openedAt.map { Fmt.date($0) } ?? "",
                material.isArchived ? "是" : "否",
                material.notes
            ]
        }

        return assemble(header: header, rows: rows)
    }

    /// 导出出入库流水。
    static func csv(from entries: [StockEntry]) -> String {
        let header = [
            "时间", "类型", "编码", "材料名称", "变动量", "变动前", "变动后",
            "单位", "操作人", "备注", "触发扫码"
        ]

        let rows = entries.map { entry -> [String] in
            let unit = entry.material?.unit
            return [
                Fmt.dateTime(entry.createdAt),
                entry.kind.displayName,
                entry.material?.code ?? "",
                entry.material?.name ?? "",
                unit.map { Fmt.signedQuantity(entry.signedDelta, unit: $0) } ?? Fmt.number(entry.signedDelta),
                Fmt.number(entry.balanceBefore),
                Fmt.number(entry.balanceAfter),
                unit?.displayName ?? "",
                entry.operatorName,
                entry.note,
                entry.scanPayload
            ]
        }

        return assemble(header: header, rows: rows)
    }

    // MARK: - 落盘

    /// 写入临时文件，供 ShareLink / 分享面板使用。
    static func writeTemporaryFile(contents: String, filename: String) throws -> URL {
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("ArtStockExport", isDirectory: true)

        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)

        let url = directory.appendingPathComponent(filename)
        // BOM 放这里而不是 content 里，便于内容本身也能被其它工具直接复用。
        var data = Data([0xEF, 0xBB, 0xBF])
        data.append(Data(contents.utf8))
        try data.write(to: url, options: .atomic)
        return url
    }

    /// 带时间戳的默认文件名。
    static func defaultFilename(prefix: String, fileExtension: String = "csv") -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyyMMdd-HHmm"
        return "\(prefix)-\(formatter.string(from: .now)).\(fileExtension)"
    }

    // MARK: - 内部

    private static func assemble(header: [String], rows: [[String]]) -> String {
        ([header] + rows)
            .map { $0.map(escape).joined(separator: ",") }
            .joined(separator: "\r\n")
    }

    /// RFC 4180 转义：含逗号、引号、换行的字段必须加引号，内部引号翻倍。
    private static func escape(_ field: String) -> String {
        let needsQuoting = field.contains(",") || field.contains("\"") || field.contains("\n") || field.contains("\r")
        guard needsQuoting else { return field }
        let escaped = field.replacingOccurrences(of: "\"", with: "\"\"")
        return "\"\(escaped)\""
    }
}
