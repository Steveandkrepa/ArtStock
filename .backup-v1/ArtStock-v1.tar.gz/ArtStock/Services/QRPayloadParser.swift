//
//  QRPayloadParser.swift
//  ArtStock — 美术材料余量管理
//
//  完全离线的二维码内容解析器：不联网、不查库、不做任何网络请求。
//  支持五种载荷形态，按优先级依次尝试：
//    1. JSON 对象（本应用生成的标签、第三方系统导出的物料卡）
//    2. URL（从 query 参数中提取字段）
//    3. GS1 应用标识（AI 01 / 10 / 17）
//    4. 键值文本（code=A;name=B 或 编码：A）
//    5. 纯文本（整段内容作为编码）
//

import Foundation

enum QRPayloadParser {

    // MARK: - 入口

    /// 解析二维码原始内容。
    /// - Parameters:
    ///   - payload: 扫码得到的原始字符串。
    ///   - symbologyRaw: `AVMetadataObject.ObjectType.rawValue`，用于展示与溯源。
    static func parse(payload: String, symbologyRaw: String = "") -> ScannedMaterialDraft {
        let raw = payload.trimmingCharacters(in: .whitespacesAndNewlines)
        let isOwn = ScanSymbology.isOwnLabel(payload: raw)

        guard !raw.isEmpty else {
            return ScannedMaterialDraft(
                rawPayload: payload,
                symbologyRaw: symbologyRaw,
                source: .plain,
                code: "",
                fieldCount: 0,
                warnings: ["二维码内容为空"],
                isOwnLabel: isOwn
            )
        }

        // 1) JSON
        if let object = decodeJSONObject(from: raw) {
            var draft = draftFromKeyValues(pairs: flatten(object), raw: raw, symbologyRaw: symbologyRaw, isOwn: isOwn)
            draft.source = .json
            return draft
        }

        // 2) URL
        if let url = URL(string: raw), let scheme = url.scheme?.lowercased(),
           ["http", "https", "artstock", "art-material", "material"].contains(scheme) {
            var pairs: [(String, String)] = []
            var pathSegments: [String] = []
            if let components = URLComponents(url: url, resolvingAgainstBaseURL: false) {
                for item in components.queryItems ?? [] {
                    if let value = item.value {
                        pairs.append((item.name, value))
                    }
                }
                pathSegments = components.path.split(separator: "/").map(String.init)
            }

            var draft = draftFromKeyValues(pairs: pairs, raw: raw, symbologyRaw: symbologyRaw, isOwn: isOwn)
            draft.source = .url

            // 没有显式 code 参数时，路径末段通常就是物料编码：
            //   https://art.example.com/m/ART-0001  →  ART-0001
            //   artstock://material/ART-0001        →  ART-0001
            if draft.code.isEmpty {
                if let last = pathSegments.last, !last.isEmpty {
                    draft.code = Material.normalize(last)
                } else if let host = url.host {
                    draft.code = Material.normalize(host)
                }
            }
            return draft
        }

        // 3) GS1
        if let gs1 = parseGS1(raw) {
            var draft = gs1
            draft.symbologyRaw = symbologyRaw
            draft.isOwnLabel = isOwn
            return draft
        }

        // 4) 键值文本
        let pairs = splitKeyValuePairs(raw)
        if !pairs.isEmpty {
            var draft = draftFromKeyValues(pairs: pairs, raw: raw, symbologyRaw: symbologyRaw, isOwn: isOwn)
            draft.source = .keyValue
            if draft.code.isEmpty {
                draft.code = Material.normalize(raw)
                draft.warnings.append("未找到编码字段，已使用整段内容作为编码")
            }
            return draft
        }

        // 5) 纯文本
        return ScannedMaterialDraft(
            rawPayload: raw,
            symbologyRaw: symbologyRaw,
            source: .plain,
            code: Material.normalize(raw),
            fieldCount: 0,
            warnings: [],
            isOwnLabel: isOwn
        )
    }

    // MARK: - JSON

    private static func decodeJSONObject(from raw: String) -> [String: Any]? {
        guard raw.hasPrefix("{") || raw.hasPrefix("[") else { return nil }
        guard let data = raw.data(using: .utf8) else { return nil }
        guard let object = try? JSONSerialization.jsonObject(with: data) else { return nil }

        if let dictionary = object as? [String: Any] { return dictionary }
        if let array = object as? [[String: Any]], let first = array.first { return first }
        return nil
    }

    /// 把嵌套一层的结果摊平成 key/value 列表（如 `{"material": {...}}`）。
    private static func flatten(_ object: [String: Any], depth: Int = 0) -> [(String, String)] {
        var result: [(String, String)] = []

        for (key, value) in object {
            switch value {
            case let string as String:
                result.append((key, string))
            case let number as NSNumber:
                result.append((key, number.stringValue))
            case let nested as [String: Any] where depth < 2:
                result.append(contentsOf: flatten(nested, depth: depth + 1))
            case let array as [Any]:
                if let first = array.first as? String {
                    result.append((key, first))
                }
            default:
                continue
            }
        }
        return result
    }

    // MARK: - 键值文本

    /// 把 `code=A;name=B` / `编码：A` / `a=1&b=2` 拆成键值对。
    private static func splitKeyValuePairs(_ raw: String) -> [(String, String)] {
        let separators = CharacterSet(charactersIn: "\n\r;；|｜&")
        let lines = raw.components(separatedBy: separators)

        var pairs: [(String, String)] = []
        for line in lines {
            let token = line.trimmingCharacters(in: .whitespaces)
            guard !token.isEmpty else { continue }

            if let range = token.range(of: "=") {
                let key = String(token[token.startIndex..<range.lowerBound])
                let value = String(token[range.upperBound...])
                if !key.trimmingCharacters(in: .whitespaces).isEmpty {
                    pairs.append((key, value))
                }
                continue
            }

            // 冒号分隔：中文全角冒号与半角冒号都支持。
            for separator in ["：", ":"] {
                if let range = token.range(of: separator) {
                    let key = String(token[token.startIndex..<range.lowerBound])
                    let value = String(token[range.upperBound...])
                    let trimmedKey = key.trimmingCharacters(in: .whitespaces)
                    // 避免把 "https://x" 这种整串当成键值对。
                    if !trimmedKey.isEmpty, !trimmedKey.contains("/") {
                        pairs.append((key, value))
                    }
                    break
                }
            }
        }
        return pairs
    }

    // MARK: - GS1

    /// GS1 的 ASCII GS 分隔符（U+001D），紧凑写法里用来分隔变长字段。
    private static var gs1Separator: Character {
        Character(UnicodeScalar(0x1D)!)
    }

    /// 固定长度的应用标识。变长的 AI 10（批次号）单独处理。
    private static let gs1FixedLengths: [String: Int] = [
        "01": 14,   // GTIN-14
        "17": 6,    // 有效期 YYMMDD
        "11": 6,    // 生产日期 YYMMDD
        "15": 6     // 最佳食用期 YYMMDD
    ]

    /// 判断一段内容是否**值得**按 GS1 解析。
    ///
    /// 这一步很关键：早期版本用"包含 01"作为判据，导致像 `ART-PIG-0001`
    /// 这种普通编码也会被拖进 GS1 分支。现在只认三种明确形态。
    private static func looksLikeGS1(_ raw: String) -> Bool {
        // 1. 括号写法：(01)06901234567892(17)270101
        if raw.contains("("), raw.contains(")") { return true }
        // 2. 紧凑写法带 GS 分隔符
        if raw.contains(gs1Separator) { return true }
        // 3. 纯数字的 (01) 紧凑写法：01 + 14 位 GTIN
        if raw.count == 16, raw.allSatisfy(\.isNumber), raw.hasPrefix("01") { return true }
        return false
    }

    /// 极简 GS1 解析：仅处理与库存相关的 AI。
    ///   (01) GTIN-14 → code
    ///   (10) 批次号   → batch
    ///   (17) 有效期   → expiry（YYMMDD）
    private static func parseGS1(_ raw: String) -> ScannedMaterialDraft? {
        guard looksLikeGS1(raw) else { return nil }

        var code = ""
        var batch: String?
        var expiry: Date?
        var parsedAnyAI = false

        if raw.contains("("), raw.contains(")") {
            // 括号写法：按 "(" 切开，每段形如 "AI)值"。
            //   切 "(" → ["", "01)06901234567892", "17)270101", "10)LOT77"]
            //   再按第一个 ")" 拆成 AI 与值。
            //
            // 注意不能按 ")" 切：那样 "01" 与它的值会被切到相邻的两个片段里，
            // 结果 AI 全部落空、整个载荷退化成纯文本。
            for chunk in raw.components(separatedBy: "(") {
                let token = chunk.trimmingCharacters(in: .whitespaces)
                guard let separatorIndex = token.firstIndex(of: ")") else { continue }

                let ai = String(token[token.startIndex..<separatorIndex])
                let body = String(token[token.index(after: separatorIndex)...])
                guard ai.count >= 2, !body.isEmpty else { continue }

                if applyGS1(ai: String(ai.prefix(2)), body: body,
                            code: &code, batch: &batch, expiry: &expiry) {
                    parsedAnyAI = true
                }
            }
        } else {
            // 紧凑写法：按已知长度逐个 AI 向前走。
            // 必须把整串消费干净才算识别成功，否则宁可交给后面的解析器。
            var work = Substring(raw)
            while work.count > 2 {
                let ai = String(work.prefix(2))
                let rest = work.dropFirst(2)

                let length: Int
                if ai == "10" {
                    // 批次号变长：吃到串尾，最多 20 位。
                    length = min(20, rest.count)
                } else if let fixed = gs1FixedLengths[ai] {
                    length = fixed
                } else {
                    break
                }

                guard rest.count >= length else { break }
                let body = String(rest.prefix(length))
                work = rest.dropFirst(length)

                if applyGS1(ai: ai, body: body, code: &code, batch: &batch, expiry: &expiry) {
                    parsedAnyAI = true
                }
                if work.first == gs1Separator {
                    work = work.dropFirst()
                }
            }

            guard work.isEmpty else { return nil }
        }

        guard parsedAnyAI, !code.isEmpty || expiry != nil || batch != nil else { return nil }

        var warnings: [String] = []
        if code.isEmpty {
            code = Material.normalize(raw)
            warnings.append("未识别到 GTIN，已使用整段内容作为编码")
        }

        var draft = ScannedMaterialDraft(
            rawPayload: raw,
            symbologyRaw: "",
            source: .gs1,
            code: Material.normalize(code),
            fieldCount: 0,
            warnings: warnings,
            isOwnLabel: false
        )
        draft.batchNumber = batch
        draft.expiryDate = expiry
        draft.fieldCount = [batch != nil, expiry != nil].filter { $0 }.count
        if let batch {
            draft.notes = "批次号：\(batch)"
        }
        return draft
    }

    /// 把单个 AI 的值写进对应字段。
    /// - Returns: 是否为本次解析关心的 AI。
    @discardableResult
    private static func applyGS1(
        ai: String,
        body: String,
        code: inout String,
        batch: inout String?,
        expiry: inout Date?
    ) -> Bool {
        switch ai {
        case "01":
            code = body
            return true
        case "17":
            expiry = dateFromGS1(body)
            return true
        case "10":
            batch = body
            return true
        default:
            return false
        }
    }

    /// GS1 的 YYMMDD 日期：00-49 视为 20xx，50-99 视为 19xx。
    private static func dateFromGS1(_ body: String) -> Date? {
        let digits = body.filter(\.isNumber)
        guard digits.count >= 6 else { return nil }
        let prefix = String(digits.prefix(6))

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyMMdd"
        guard let date = formatter.date(from: prefix) else { return nil }

        // 年份后两位无法区分世纪，粗略修正：明显早于当前时间时按下一个世纪处理。
        let calendar = Calendar.current
        if let oneYearAgo = calendar.date(byAdding: .year, value: -1, to: .now),
           date < oneYearAgo,
           let adjusted = calendar.date(byAdding: .year, value: 100, to: date) {
            return adjusted
        }
        return date
    }

    // MARK: - 字段归并

    /// 字段别名表。键为规范化后的字段名，值为可能出现的写法（中英文）。
    private static let aliases: [Field: [String]] = [
        .code: ["code", "id", "sku", "sn", "barcode", "gtin", "ean", "no", "number", "materialcode", "itemcode",
                "编号", "编码", "物料编码", "料号", "条码", "货号"],
        .name: ["name", "title", "product", "productname", "item", "material", "materialname", "displayname",
                "名称", "品名", "物料名称", "材料名称", "物料"],
        .category: ["category", "type", "class", "group", "kind", "分类", "类别", "类型", "品类"],
        .brand: ["brand", "maker", "manufacturer", "vendor", "品牌", "厂商", "厂家"],
        .specification: ["spec", "specification", "size", "model", "packing", "pack", "规格", "型号", "规格型号", "包装"],
        .unit: ["unit", "uom", "measure", "单位", "计量单位"],
        .quantity: ["quantity", "qty", "amount", "stock", "onhand", "balance", "count", "remain", "volume",
                    "数量", "余量", "库存", "存量", "剩余"],
        .capacity: ["capacity", "fullamount", "total", "container", "nominalvolume", "容量", "满量", "总容量", "标准容量"],
        .threshold: ["threshold", "min", "minimum", "minstock", "alert", "low", "lowstock", "safetystock", "reorder",
                     "阈值", "预警", "预警值", "最低库存", "补货线", "安全库存"],
        .location: ["location", "place", "shelf", "bin", "position", "store", "warehouse",
                    "位置", "存放", "库位", "存放位置", "仓位"],
        .supplier: ["supplier", "vendor", "purchaser", "来源", "供应商", "采购"],
        .unitPrice: ["price", "cost", "unitprice", "purchaseprice", "单价", "价格", "进价"],
        .colorHex: ["color", "colour", "hex", "colorhex", "swatch", "色号", "颜色", "色彩"],
        .notes: ["note", "notes", "remark", "remarks", "memo", "desc", "description", "comment", "批次",
                 "备注", "说明", "描述"],
        .expiry: ["expiry", "expire", "expiration", "exp", "expirydate", "bestbefore", "validuntil",
                  "有效期", "到期", "到期日", "保质期"],
        .opened: ["opened", "openedat", "opendate", "开封", "开封日期"],
        .batch: ["batch", "lot", "batchno", "lotno", "批次", "批号"]
    ]

    private enum Field: CaseIterable {
        case code, name, category, brand, specification, unit
        case quantity, capacity, threshold
        case location, supplier, unitPrice, colorHex, notes
        case expiry, opened, batch
    }

    private static func field(forKey key: String) -> Field? {
        let normalized = normalizeKey(key)
        guard !normalized.isEmpty else { return nil }
        for field in Field.allCases {
            guard let candidates = aliases[field] else { continue }
            if candidates.contains(normalized) { return field }
        }
        // 宽松匹配：键里包含别名（如 "materialCodeValue"）
        for field in Field.allCases {
            guard let candidates = aliases[field] else { continue }
            for candidate in candidates where candidate.count >= 3 && normalized.contains(candidate) {
                return field
            }
        }
        return nil
    }

    private static func normalizeKey(_ key: String) -> String {
        key.lowercased()
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "_", with: "")
            .replacingOccurrences(of: "-", with: "")
            .replacingOccurrences(of: ".", with: "")
    }

    private static func draftFromKeyValues(
        pairs: [(String, String)],
        raw: String,
        symbologyRaw: String,
        isOwn: Bool
    ) -> ScannedMaterialDraft {

        var draft = ScannedMaterialDraft(
            rawPayload: raw,
            symbologyRaw: symbologyRaw,
            source: .keyValue,
            code: "",
            fieldCount: 0,
            warnings: [],
            isOwnLabel: isOwn
        )

        var recognized = 0

        // 量纲需要**两趟**处理。
        //
        // 原因：JSON 载荷经 JSONSerialization 解出来是无序字典，"先遇到哪个单位"
        // 完全不确定。如果边遍历边定单位，同一个码在两次扫描里可能得到不同结果。
        // 所以先把带单位提示的量值原样收集起来，遍历结束后再统一确定基准单位并换算。
        var explicitUnit: MeasurementUnit?
        var explicitUnitText: String?
        var rawQuantity: Magnitude?
        var rawCapacity: Magnitude?
        var rawThreshold: Magnitude?

        for (key, value) in pairs {
            let cleaned = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleaned.isEmpty else { continue }
            guard let field = field(forKey: key) else { continue }

            switch field {
            case .code:
                draft.code = Material.normalize(cleaned)
            case .name:
                draft.name = cleaned
            case .category:
                draft.category = MaterialCategory.match(cleaned)
                if draft.category == nil { draft.warnings.append("分类「\(cleaned)」未识别，已留空") }
            case .brand:
                draft.brand = cleaned
            case .specification:
                draft.specification = cleaned
            case .unit:
                explicitUnit = MeasurementUnit.match(cleaned)
                explicitUnitText = cleaned
            case .quantity:
                if let parsed = parseMagnitude(cleaned) {
                    rawQuantity = parsed
                } else {
                    draft.warnings.append("数量「\(cleaned)」不是有效数字")
                }
            case .capacity:
                rawCapacity = parseMagnitude(cleaned)
            case .threshold:
                rawThreshold = parseMagnitude(cleaned)
            case .location:
                draft.location = cleaned
            case .supplier:
                draft.supplier = cleaned
            case .unitPrice:
                if let parsed = parseMagnitude(cleaned) { draft.unitPrice = parsed.value }
            case .colorHex:
                draft.colorHex = normalizeHex(cleaned)
            case .notes:
                draft.notes = draft.notes.map { $0 + " " + cleaned } ?? cleaned
            case .expiry:
                if let date = parseDate(cleaned) {
                    draft.expiryDate = date
                } else {
                    draft.warnings.append("有效期「\(cleaned)」无法解析")
                }
            case .opened:
                if let date = parseDate(cleaned) { draft.openedAt = date }
            case .batch:
                draft.batchNumber = cleaned
                draft.notes = draft.notes.map { $0 + " 批次：\(cleaned)" } ?? "批次：\(cleaned)"
            }
            recognized += 1
        }

        // ── 确定基准单位 ──
        // 优先级：显式单位字段 > 余量带的提示 > 满量带的提示 > 阈值带的提示
        let canonicalUnit = explicitUnit
            ?? rawQuantity?.hint
            ?? rawCapacity?.hint
            ?? rawThreshold?.hint

        if explicitUnitText != nil, explicitUnit == nil {
            draft.warnings.append("单位「\(explicitUnitText ?? "")」未识别，已改用数值自带的单位")
        }
        draft.unit = canonicalUnit

        // ── 把各量值换算到基准单位 ──
        draft.quantity = resolveMagnitude(rawQuantity, to: canonicalUnit,
                                          fieldName: "余量", warnings: &draft.warnings)
        draft.capacity = resolveMagnitude(rawCapacity, to: canonicalUnit,
                                          fieldName: "满量", warnings: &draft.warnings)
        draft.lowStockThreshold = resolveMagnitude(rawThreshold, to: canonicalUnit,
                                                   fieldName: "预警阈值", warnings: &draft.warnings)

        if draft.code.isEmpty {
            switch draft.source {
            case .json, .keyValue:
                draft.warnings.append("载荷中没有编码字段")
            default:
                break
            }
        }

        draft.fieldCount = recognized
        return draft
    }

    /// 把「数值 + 单位提示」换算到基准单位。
    /// - Returns: 换算后的数值（无需换算或无法换算时原样返回）。
    private static func resolveMagnitude(
        _ parsed: Magnitude?,
        to canonicalUnit: MeasurementUnit?,
        fieldName: String,
        warnings: inout [String]
    ) -> Double? {
        guard let parsed else { return nil }

        guard let hint = parsed.hint else {
            // 没写单位，按基准单位理解。
            return parsed.value
        }
        guard let canonicalUnit else {
            // 整条载荷里就只有这一个单位信息，直接采用。
            return parsed.value
        }
        if hint == canonicalUnit {
            return parsed.value
        }

        if let converted = hint.convert(parsed.value, to: canonicalUnit) {
            warnings.append("\(fieldName) \(Fmt.number(parsed.value)) \(hint.abbreviation)"
                            + " 已换算为 \(Fmt.number(converted)) \(canonicalUnit.abbreviation)")
            return converted
        }

        // 量纲不同（例如余量按毫升、满量按克），换算没有意义，保留原值并提示。
        warnings.append("\(fieldName)标的是 \(hint.displayName)，与基准单位 \(canonicalUnit.displayName) 不是同一量纲，已按原值保留")
        return parsed.value
    }

    // MARK: - 值解析

    /// 从文本里抽出来的量值：数值 + 顺带识别到的单位提示。
    private struct Magnitude {
        var value: Double
        var hint: MeasurementUnit?
    }

    /// 从 "500ml" / "0.5 L" / "12" 这类文本中抽数值，并顺带识别单位。
    private static func parseMagnitude(_ text: String) -> Magnitude? {
        let lowered = text.lowercased().replacingOccurrences(of: ",", with: "")

        // 只取最前面的那一段数字，其余字符当作可能的单位提示。
        var numberBuffer = ""
        var unitBuffer = ""
        var hasSeenDigit = false

        for character in lowered {
            let isNumericCharacter = character.isNumber
                || (character == "." && hasSeenDigit)
                || (character == "-" && numberBuffer.isEmpty && !hasSeenDigit)

            if isNumericCharacter && unitBuffer.isEmpty {
                numberBuffer.append(character)
                if character.isNumber { hasSeenDigit = true }
            } else {
                unitBuffer.append(character)
            }
        }

        // 去掉结尾孤立的小数点，例如 "500." → "500"
        while numberBuffer.hasSuffix(".") { numberBuffer.removeLast() }

        guard !numberBuffer.isEmpty, let value = Double(numberBuffer) else { return nil }

        let trimmedUnit = unitBuffer.trimmingCharacters(in: .whitespaces)
        let hint = trimmedUnit.isEmpty ? nil : MeasurementUnit.match(trimmedUnit)
        return Magnitude(value: value, hint: hint)
    }

    /// 颜色值规范化：支持 #RGB / #RRGGBB / rgb 写法 / 中文色名。
    private static func normalizeHex(_ text: String) -> String? {
        let cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return nil }

        let hex = cleaned.hasPrefix("#") ? String(cleaned.dropFirst()) : cleaned
        if hex.count == 3 || hex.count == 6, hex.allSatisfy({ $0.isHexDigit }) {
            return "#" + hex.uppercased()
        }

        let namedColors: [String: String] = [
            "红": "#D6303A", "朱红": "#E34234", "深红": "#8B1A1A",
            "橙": "#F08030", "黄": "#F2C200", "柠檬黄": "#FFF44F",
            "绿": "#3E9B4F", "草绿": "#7BB661", "橄榄绿": "#6B8E23",
            "蓝": "#2E5BFF", "群青": "#2E5BFF", "湖蓝": "#2C9BC4",
            "紫": "#7B4FA8", "粉": "#E48FB0", "棕": "#8B5A2B",
            "黑": "#1C1C1E", "白": "#F5F5F5", "灰": "#8E8E93"
        ]
        for (key, value) in namedColors where cleaned.contains(key) {
            return value
        }
        return nil
    }

    /// 多格式日期解析。
    private static func parseDate(_ text: String) -> Date? {
        let cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return nil }

        let formats = ["yyyy-MM-dd", "yyyy/MM/dd", "yyyy.MM.dd", "yyyyMMdd", "yyMMdd", "MM/dd/yyyy", "yyyy-MM"]
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone.current

        for format in formats {
            formatter.dateFormat = format
            if let date = formatter.date(from: cleaned) { return date }
        }

        if let date = ISO8601DateFormatter().date(from: cleaned) { return date }
        return nil
    }
}
