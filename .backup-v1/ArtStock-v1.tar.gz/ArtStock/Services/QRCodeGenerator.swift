//
//  QRCodeGenerator.swift
//  ArtStock — 美术材料余量管理
//
//  本地生成二维码图像与自描述载荷。全程用 CoreImage 在本机完成，不联网。
//

import CoreImage
import CoreImage.CIFilterBuiltins
import UIKit

enum QRCodeGenerator {

    /// 复用 CIContext：每次新建开销很大，二维码是高频操作。
    private static let context = CIContext(options: [.useSoftwareRenderer: false])

    // MARK: - 载荷

    /// 为一条档案生成自描述 JSON 载荷。
    ///
    /// 带 `generator: ArtStock` 标记，本应用扫到自己生成的标签时可以直接识别，
    /// 越过"解析猜测"环节。同时字段名刻意与解析器别名表对齐，别的工具也能读懂。
    static func payload(for material: Material) -> String {
        var dictionary: [String: String] = [
            "generator": "ArtStock",
            "version": "1",
            "code": material.code,
            "name": material.name,
            "category": material.category.displayName,
            "unit": material.unit.displayName
        ]

        if !material.brand.isBlank { dictionary["brand"] = material.brand }
        if !material.specification.isBlank { dictionary["spec"] = material.specification }
        if material.capacity > 0 { dictionary["capacity"] = Fmt.number(material.capacity) }
        if !material.location.isBlank { dictionary["location"] = material.location }
        if !material.supplier.isBlank { dictionary["supplier"] = material.supplier }
        if material.unitPrice > 0 { dictionary["price"] = Fmt.number(material.unitPrice) }
        if !material.colorHex.isBlank { dictionary["color"] = material.colorHex }
        if let expiry = material.expiryDate { dictionary["expiry"] = Fmt.date(expiry) }

        // 不写入余量：标签是贴上去就不动的，余量本身变化频繁，
        // 让扫到的余量永远是"标签印刷时的旧值"反而会误导盘点。

        guard let data = try? JSONSerialization.data(withJSONObject: dictionary, options: [.sortedKeys]),
              let json = String(data: data, encoding: .utf8) else {
            // 极端兜底：退回纯编码，扫码建库仍可用。
            return material.code
        }
        return json
    }

    // MARK: - 图像

    /// 生成原始尺寸的二维码位图（模块级别，1 像素 = 1 模块）。
    static func cgImage(for text: String, correctionLevel: String = "M") -> CGImage? {
        guard !text.isEmpty else { return nil }

        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(text.utf8)
        filter.correctionLevel = correctionLevel

        guard let output = filter.outputImage else { return nil }
        return context.createCGImage(output, from: output.extent)
    }

    /// 生成可直接显示 / 打印的二维码图片。
    ///
    /// - Parameters:
    ///   - text: 载荷内容。
    ///   - scale: 放大倍数，用最近邻插值保证模块边缘锐利。
    ///   - quietZoneModules: 静区宽度（以模块为单位）。二维码规范要求至少 4。
    static func image(
        for text: String,
        scale: CGFloat = 12,
        correctionLevel: String = "M",
        quietZoneModules: CGFloat = 4
    ) -> UIImage? {
        guard let base = cgImage(for: text, correctionLevel: correctionLevel) else { return nil }

        let moduleCount = CGFloat(max(base.width, base.height))
        let totalModules = moduleCount + quietZoneModules * 2
        let side = (totalModules * scale).rounded()

        let renderer = UIGraphicsImageRenderer(size: CGSize(width: side, height: side))
        return renderer.image { rendererContext in
            let cgContext = rendererContext.cgContext

            // 静区必须是白色，否则很多扫码器识别率会明显下降。
            cgContext.setFillColor(UIColor.white.cgColor)
            cgContext.fill(CGRect(x: 0, y: 0, width: side, height: side))

            cgContext.interpolationQuality = .none
            let inset = quietZoneModules * scale
            cgContext.draw(base, in: CGRect(x: inset, y: inset, width: moduleCount * scale, height: moduleCount * scale))
        }
    }

    /// 只判断内容能否生成二维码，用于表单实时校验。
    static func canEncode(_ text: String) -> Bool {
        cgImage(for: text) != nil
    }
}
