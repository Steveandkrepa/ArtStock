//
//  WetnessPreferences.swift
//  ArtStock — 美术材料余量管理
//
//  颜料湿润计时器的用户偏好。
//
//  用 UserDefaults 而不是 SwiftData：这些都是"设备级设置"（每个颜料体系
//  标定出来的常数、喷一下能维持多久），量极小、不需要查询、也不需要迁移。
//  用 @AppStorage 在界面里绑定同一个 key，两边自动同步。
//

import Foundation

enum WetnessPreferences {

    // MARK: - Key

    private enum Key {
        static let calibrationPrefix = "wetness.calibration."
        static let minutesPerSpray = "wetness.minutesPerSpray"
        static let notificationsEnabled = "wetness.notificationsEnabled"
        static let defaultPaintSystem = "wetness.defaultPaintSystem"
        static let defaultClosure = "wetness.defaultClosure"
        static let manualLatitude = "wetness.manualLatitude"
        static let manualLongitude = "wetness.manualLongitude"
        static let manualPlaceName = "wetness.manualPlaceName"
    }

    private static var store: UserDefaults { .standard }

    // MARK: - 实测校准常数

    /// 取某个颜料体系下用户实测校准的 K。返回 nil 表示还没校准过。
    static func calibration(for system: PaintSystem) -> Double? {
        let key = Key.calibrationPrefix + system.rawValue
        guard store.object(forKey: key) != nil else { return nil }
        let value = store.double(forKey: key)
        // 0 或负数视为"未校准"，避免脏数据把模型带偏。
        return value > 0 ? value : nil
    }

    /// 写入校准值。传 nil 表示清除（回到默认起点常数）。
    static func setCalibration(_ value: Double?, for system: PaintSystem) {
        let key = Key.calibrationPrefix + system.rawValue
        if let value, value > 0 {
            store.set(value, forKey: key)
        } else {
            store.removeObject(forKey: key)
        }
    }

    /// 已校准过常数的颜料体系列表。
    static var calibratedSystems: [PaintSystem] {
        PaintSystem.allCases.filter { calibration(for: $0) != nil }
    }

    // MARK: - 喷雾标定

    /// 喷一下大约能维持多少分钟。0 表示未标定。
    static var minutesPerSpray: Double {
        get { store.double(forKey: Key.minutesPerSpray) }
        set { store.set(max(0, newValue), forKey: Key.minutesPerSpray) }
    }

    // MARK: - 通知

    static var notificationsEnabled: Bool {
        get {
            // 默认开启：这个功能的价值就在提醒，默认关闭等于没做。
            if store.object(forKey: Key.notificationsEnabled) == nil { return true }
            return store.bool(forKey: Key.notificationsEnabled)
        }
        set { store.set(newValue, forKey: Key.notificationsEnabled) }
    }

    // MARK: - 默认选项

    static var defaultPaintSystem: PaintSystem {
        get {
            guard let raw = store.string(forKey: Key.defaultPaintSystem),
                  let value = PaintSystem(rawValue: raw) else { return .oil }
            return value
        }
        set { store.set(newValue.rawValue, forKey: Key.defaultPaintSystem) }
    }

    static var defaultClosure: PaletteClosure {
        get {
            guard let raw = store.string(forKey: Key.defaultClosure),
                  let value = PaletteClosure(rawValue: raw) else { return .sealedBox }
            return value
        }
        set { store.set(newValue.rawValue, forKey: Key.defaultClosure) }
    }

    // MARK: - 定位失败时的兜底坐标

    /// 用户手动选定的城市坐标。定位被拒绝或不可用时用它。
    static var manualPlace: (name: String, latitude: Double, longitude: Double)? {
        get {
            guard let name = store.string(forKey: Key.manualPlaceName), !name.isEmpty,
                  store.object(forKey: Key.manualLatitude) != nil else { return nil }
            return (name, store.double(forKey: Key.manualLatitude), store.double(forKey: Key.manualLongitude))
        }
        set {
            if let newValue {
                store.set(newValue.name, forKey: Key.manualPlaceName)
                store.set(newValue.latitude, forKey: Key.manualLatitude)
                store.set(newValue.longitude, forKey: Key.manualLongitude)
            } else {
                store.removeObject(forKey: Key.manualPlaceName)
                store.removeObject(forKey: Key.manualLatitude)
                store.removeObject(forKey: Key.manualLongitude)
            }
        }
    }
}

// 占位：避免上面误留的空属性被编译器当成错误（Swift 不允许无实现的存储属性）。
extension WetnessPreferences {
    /// 供测试使用：清空全部湿润计时器偏好。
    static func resetAllForTesting() {
        let defaults = UserDefaults.standard
        for system in PaintSystem.allCases {
            defaults.removeObject(forKey: "wetness.calibration." + system.rawValue)
        }
        for key in ["wetness.minutesPerSpray", "wetness.notificationsEnabled",
                    "wetness.defaultPaintSystem", "wetness.defaultClosure",
                    "wetness.manualLatitude", "wetness.manualLongitude", "wetness.manualPlaceName"] {
            defaults.removeObject(forKey: key)
        }
    }
}
