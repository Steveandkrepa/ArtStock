//
//  InventoryService.swift
//  ArtStock — 美术材料余量管理
//
//  余量变动的唯一入口。
//
//  铁律：任何对 Material.quantity 的写入都必须经过这里的 apply(...)，
//  否则流水会与余量脱节，历史记录就失去意义了。
//

import Foundation
import SwiftData

/// 一次余量变动的执行结果。
struct StockAdjustmentResult {
    /// 生成的流水记录。
    let entry: StockEntry
    /// 调用方请求的变动量（盘点是"目标绝对值"）。
    let requestedAmount: Double
    /// 实际发生的变动量（带符号）。
    let actualDelta: Double
    /// 因为余量不足被截断过。
    let wasClamped: Bool

    /// 给用户看的一句话说明。
    var summary: String {
        let unit = entry.material?.unit ?? .piece
        if wasClamped {
            return "余量不足，已按实际 \(Fmt.quantity(abs(actualDelta), unit: unit)) 扣减"
        }
        if entry.kind == .adjust {
            return "盘点完成，余量已修正为 \(Fmt.quantity(entry.balanceAfter, unit: unit))"
        }
        return "\(entry.kind.displayName)完成，当前余量 \(Fmt.quantity(entry.balanceAfter, unit: unit))"
    }
}

@MainActor
enum InventoryService {

    // MARK: - 查询

    /// 按编码精确查找（编码已规范化）。
    static func material(code: String, in context: ModelContext) -> Material? {
        let key = Material.normalize(code)
        guard !key.isEmpty else { return nil }

        var descriptor = FetchDescriptor<Material>(
            predicate: #Predicate<Material> { $0.code == key }
        )
        descriptor.fetchLimit = 1
        return try? context.fetch(descriptor).first
    }

    /// 取回全部档案（含归档）。本地库规模有限，排序与筛选放在内存里做更灵活。
    static func allMaterials(in context: ModelContext) -> [Material] {
        let descriptor = FetchDescriptor<Material>(
            sortBy: [SortDescriptor(\Material.name, comparator: .localizedStandard)]
        )
        return (try? context.fetch(descriptor)) ?? []
    }

    /// 是否存在同编码的档案（新建前查重用）。
    static func exists(code: String, in context: ModelContext) -> Bool {
        material(code: code, in: context) != nil
    }

    // MARK: - 建档

    /// 由表单创建新档案，并写入初始余量流水。
    /// - Throws: 表单存在阻断性问题时抛 `InventoryError.invalidForm`。
    @discardableResult
    static func create(
        form: MaterialFormModel,
        in context: ModelContext
    ) throws -> Material {
        let blocking = form.blockingIssues
        guard blocking.isEmpty else {
            throw InventoryError.invalidForm(blocking)
        }

        let normalizedCode = Material.normalize(form.code)
        if let existing = material(code: normalizedCode, in: context) {
            throw InventoryError.duplicateCode(existing.name)
        }

        let material = form.makeMaterial()
        context.insert(material)

        // 初始余量必须留痕，否则历史记录会缺失起点。
        if material.quantity > 0 {
            let entry = StockEntry(
                kind: .initial,
                amount: material.quantity,
                balanceBefore: 0,
                balanceAfter: material.quantity,
                note: "扫码建档初始余量",
                operatorName: form.operatorName,
                scanPayload: form.qrPayload,
                material: material
            )
            context.insert(entry)
        }

        try context.save()
        return material
    }

    /// 保存编辑（只改元数据，余量走 apply）。
    static func update(form: MaterialFormModel, in context: ModelContext) throws {
        guard let material = form.editingMaterial else { return }

        let normalizedCode = Material.normalize(form.code)
        if normalizedCode != material.code, let existing = self.material(code: normalizedCode, in: context) {
            throw InventoryError.duplicateCode(existing.name)
        }

        form.applyMetadata(to: material)

        // 编辑表单里的"余量"字段代表盘点结果，与当前值不同则记一条流水。
        let target = form.quantity.rounded(for: material.unit)
        if abs(target - material.quantity) > 0.0001 {
            _ = apply(
                kind: .adjust,
                amount: target,
                to: material,
                note: "编辑档案时修正余量",
                operatorName: form.operatorName,
                scanPayload: "",
                in: context
            )
        }

        try context.save()
    }

    // MARK: - 余量变动

    /// 执行一次余量变动并生成流水。
    ///
    /// - Parameters:
    ///   - kind: 变动类型。`.adjust` 时 `amount` 表示**目标绝对值**，其余表示增减量。
    ///   - amount: 数量，始终传正数（`.adjust` 例外，见上）。
    ///   - material: 目标档案。
    ///   - note: 备注。
    ///   - operatorName: 操作人。
    ///   - scanPayload: 本次变动的触发扫码内容。
    @discardableResult
    static func apply(
        kind: StockEntryKind,
        amount: Double,
        to material: Material,
        note: String = "",
        operatorName: String = "",
        scanPayload: String = "",
        in context: ModelContext
    ) -> StockAdjustmentResult {

        let unit = material.unit
        let before = material.quantity

        var after: Double
        var wasClamped = false

        switch kind.amountSemantic {
        case .absolute:
            after = amount.rounded(for: unit)

        case .delta:
            let magnitude = abs(amount)
            let raw = kind.isIncrease ? before + magnitude : before - magnitude

            if raw < 0 {
                // 余量不足：截断到 0，并标记，让界面给出提示。
                wasClamped = true
                after = 0
            } else {
                after = raw.rounded(for: unit)
            }
        }

        after = max(0, after)
        let delta = after - before

        material.quantity = after
        material.updatedAt = .now

        // 首次领用视为开封，便于后续估算可用期。
        if kind == .consume, material.openedAt == nil {
            material.openedAt = .now
        }
        // 领到空时顺手归档状态不变，只更新余量即可。

        let entry = StockEntry(
            kind: kind,
            amount: abs(delta),
            balanceBefore: before,
            balanceAfter: after,
            note: note,
            operatorName: operatorName,
            scanPayload: scanPayload,
            material: material
        )
        context.insert(entry)

        try? context.save()

        return StockAdjustmentResult(
            entry: entry,
            requestedAmount: amount,
            actualDelta: delta,
            wasClamped: wasClamped
        )
    }

    /// 快速领用（扫到已知码时的默认动作）。
    @discardableResult
    static func consume(
        _ amount: Double,
        from material: Material,
        note: String = "扫码领用",
        operatorName: String = "",
        scanPayload: String = "",
        in context: ModelContext
    ) -> StockAdjustmentResult {
        apply(kind: .consume, amount: amount, to: material, note: note,
              operatorName: operatorName, scanPayload: scanPayload, in: context)
    }

    /// 快速入库。
    @discardableResult
    static func restock(
        _ amount: Double,
        to material: Material,
        note: String = "扫码入库",
        operatorName: String = "",
        scanPayload: String = "",
        in context: ModelContext
    ) -> StockAdjustmentResult {
        apply(kind: .restock, amount: amount, to: material, note: note,
              operatorName: operatorName, scanPayload: scanPayload, in: context)
    }

    // MARK: - 归档与删除

    static func setArchived(_ archived: Bool, for material: Material, in context: ModelContext) {
        material.isArchived = archived
        material.updatedAt = .now
        try? context.save()
    }

    /// 删除档案。级联删除其全部流水（关系上声明了 .cascade）。
    static func delete(_ material: Material, in context: ModelContext) {
        context.delete(material)
        try? context.save()
    }

    /// 删除多条档案。
    static func delete(_ materials: [Material], in context: ModelContext) {
        for material in materials {
            context.delete(material)
        }
        try? context.save()
    }

    // MARK: - 统计

    /// 从一批档案算出看板指标。纯函数，方便单测与预览。
    static func statistics(for materials: [Material]) -> InventoryStatistics {
        let active = materials.filter { !$0.isArchived }

        var emptyCount = 0
        var lowCount = 0
        var healthyCount = 0
        var totalValue: Double = 0

        for material in active {
            switch material.stockLevel {
            case .empty: emptyCount += 1
            case .low: lowCount += 1
            case .healthy: healthyCount += 1
            }
            totalValue += material.unitPrice * material.quantity
        }

        let categoryCounts = Dictionary(grouping: active, by: { $0.category })
            .mapValues(\.count)

        let expiring = active.filter { $0.isExpiringSoon || $0.isExpired }

        return InventoryStatistics(
            totalCount: active.count,
            archivedCount: materials.count - active.count,
            emptyCount: emptyCount,
            lowCount: lowCount,
            healthyCount: healthyCount,
            totalValue: totalValue,
            categoryCounts: categoryCounts,
            expiringCount: expiring.count
        )
    }

    /// 需要补货的档案，按紧急度升序（最紧急在前）。
    static func materialsNeedingRestock(from materials: [Material]) -> [Material] {
        materials
            .filter { !$0.isArchived && $0.stockLevel.needsAttention }
            .sorted { $0.urgency < $1.urgency }
    }

    /// 临期档案。
    static func expiringMaterials(from materials: [Material]) -> [Material] {
        materials
            .filter { !$0.isArchived && ($0.isExpiringSoon || $0.isExpired) }
            .sorted { ($0.expiryDate ?? .distantFuture) < ($1.expiryDate ?? .distantFuture) }
    }
}

/// 看板用的聚合结果。
struct InventoryStatistics {
    var totalCount: Int
    var archivedCount: Int
    var emptyCount: Int
    var lowCount: Int
    var healthyCount: Int
    var totalValue: Double
    var categoryCounts: [MaterialCategory: Int]
    var expiringCount: Int

    var attentionCount: Int { emptyCount + lowCount }

    func count(for category: MaterialCategory) -> Int {
        categoryCounts[category] ?? 0
    }
}

/// 业务错误。
enum InventoryError: LocalizedError {
    case invalidForm([String])
    case duplicateCode(String)
    case notFound(String)

    var errorDescription: String? {
        switch self {
        case .invalidForm(let issues):
            return issues.joined(separator: "\n")
        case .duplicateCode(let name):
            return "该编码已存在，对应档案「\(name)」。请改用其他编码，或直接打开已有档案。"
        case .notFound(let code):
            return "未找到编码为 \(code) 的材料档案。"
        }
    }
}
