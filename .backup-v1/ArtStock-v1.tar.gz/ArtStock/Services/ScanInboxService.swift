//
//  ScanInboxService.swift
//  ArtStock — 美术材料余量管理
//
//  扫码收件箱。每一次扫码都留痕，未处理的码停在 pending，
//  用户可以稍后从「扫码记录」继续建档，不会因为手滑关掉弹窗而丢码。
//

import Foundation
import SwiftData

@MainActor
enum ScanInboxService {

    /// 记录一次扫码。
    /// - Note: 同一载荷在短时间内被连续扫到（相机连帧）由调用方去重，
    ///         这里只负责落库，不做业务判断。
    @discardableResult
    static func record(
        payload: String,
        symbologyRaw: String,
        source: PayloadSource,
        in context: ModelContext
    ) -> ScanRecord {
        let record = ScanRecord(
            payload: payload,
            symbologyRaw: symbologyRaw,
            source: source,
            status: .pending
        )
        context.insert(record)
        try? context.save()
        return record
    }

    /// 标记为"已关联到已有档案"。
    static func markLinked(_ record: ScanRecord, materialCode: String, in context: ModelContext) {
        record.status = .linked
        record.materialCode = materialCode
        try? context.save()
    }

    /// 标记为"本次建档"。
    static func markCreated(_ record: ScanRecord, materialCode: String, in context: ModelContext) {
        record.status = .created
        record.materialCode = materialCode
        try? context.save()
    }

    /// 标记为"忽略"。
    static func markIgnored(_ record: ScanRecord, note: String = "", in context: ModelContext) {
        record.status = .ignored
        if !note.isBlank { record.note = note }
        try? context.save()
    }

    /// 更新备注。
    static func updateNote(_ record: ScanRecord, note: String, in context: ModelContext) {
        record.note = note
        try? context.save()
    }

    // MARK: - 查询

    /// 最近若干条扫码记录，最新在前。
    static func recent(in context: ModelContext, limit: Int = 200) -> [ScanRecord] {
        var descriptor = FetchDescriptor<ScanRecord>(
            sortBy: [SortDescriptor(\ScanRecord.scannedAt, order: .reverse)]
        )
        descriptor.fetchLimit = limit
        return (try? context.fetch(descriptor)) ?? []
    }

    /// 待处理记录，最旧在前（先扫的先处理）。
    static func pending(in context: ModelContext) -> [ScanRecord] {
        let descriptor = FetchDescriptor<ScanRecord>(
            predicate: #Predicate<ScanRecord> { $0.statusRaw == "pending" },
            sortBy: [SortDescriptor(\ScanRecord.scannedAt, order: .forward)]
        )
        return (try? context.fetch(descriptor)) ?? []
    }

    /// 待处理数量。侧边栏角标用。
    static func pendingCount(in context: ModelContext) -> Int {
        let descriptor = FetchDescriptor<ScanRecord>(
            predicate: #Predicate<ScanRecord> { $0.statusRaw == "pending" }
        )
        return (try? context.fetchCount(descriptor)) ?? 0
    }

    /// 清理已完成的历史记录。
    static func clearCompleted(in context: ModelContext) {
        let descriptor = FetchDescriptor<ScanRecord>(
            predicate: #Predicate<ScanRecord> { $0.statusRaw != "pending" }
        )
        guard let records = try? context.fetch(descriptor) else { return }
        for record in records {
            context.delete(record)
        }
        try? context.save()
    }

    /// 删除单条记录。
    static func delete(_ record: ScanRecord, in context: ModelContext) {
        context.delete(record)
        try? context.save()
    }
}
