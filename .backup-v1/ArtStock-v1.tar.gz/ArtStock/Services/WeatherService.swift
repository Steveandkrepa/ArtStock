//
//  WeatherService.swift
//  ArtStock — 美术材料余量管理
//
//  取当地当前的温度与相对湿度，喂给 DryingModel。
//
//  ── 为什么是这个方案 ──────────────────────────────────────────
//  iOS 没有面向第三方 App 的环境湿度传感器 API。可选途径只有三条：
//    · HomeKit 湿度特征  → 需要 com.apple.developer.homekit entitlement，
//                          免费 Apple ID 签不出来，SideStore 路线上不可用。
//    · WeatherKit        → 需要付费开发者账号配置 App ID 与密钥。
//    · 公开天气 API      → 纯 HTTPS，不需要任何 entitlement。✅ 本文件采用。
//
//  数据源用 Open-Meteo：免费、无需注册、无需 API Key，因此不需要在
//  App 里藏任何密钥（这对一个要放进公开仓库的项目是硬要求）。
//
//  ── 隐私 ────────────────────────────────────────────────────
//  只把经纬度发给 api.open-meteo.com，不带任何设备标识、不上报用途。
//  定位权限被拒绝时不会静默失败，而是回退到用户在设置里手选的城市。
//

import CoreLocation
import Foundation
import Observation

/// 一次天气快照。
struct WeatherSnapshot: Equatable, Sendable {
    var temperatureC: Double
    var relativeHumidity: Double
    var fetchedAt: Date
    /// 数据来源地点名（"当前位置" 或用户手选的城市）。
    var placeName: String
    /// 数据来源说明，直接展示给用户，保证可追溯。
    var sourceDescription: String

    /// 快照是否已经太旧。超过 90 分钟就重新取。
    var isStale: Bool {
        Date.now.timeIntervalSince(fetchedAt) > 90 * 60
    }
}

/// 取天气时的失败原因。全部做成人类可读的中文。
enum WeatherError: LocalizedError {
    case locationDenied
    case locationUnavailable
    case network(String)
    case badResponse
    case noCoordinates

    var errorDescription: String? {
        switch self {
        case .locationDenied:
            return "定位权限被拒绝。可以到「设置 → 隐私与安全性 → 定位服务」里开启，或者在下方手动指定城市。"
        case .locationUnavailable:
            return "暂时取不到位置。稍后再试，或在下方手动指定城市。"
        case .network(let message):
            return "网络请求失败：\(message)"
        case .badResponse:
            return "天气服务返回了无法解析的数据。"
        case .noCoordinates:
            return "没有可用的坐标（既没拿到定位，也没设置城市）。"
        }
    }
}

@MainActor
@Observable
final class WeatherService {

    enum LoadState: Equatable {
        case idle
        case loading
        case loaded
        case failed(String)

        var isLoading: Bool { self == .loading }
    }

    private(set) var state: LoadState = .idle
    private(set) var snapshot: WeatherSnapshot?

    private let session: URLSession
    private let locationProvider = OneShotLocationProvider()

    init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 25
        // 天气是实时数据，绝不能用缓存糊弄。
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)
    }

    // MARK: - 对外入口

    /// 刷新天气。已经拿到的新鲜数据会直接复用，不会重复请求。
    /// - Parameter force: 为 true 时忽略现有快照强制重取。
    func refresh(force: Bool = false) async {
        if !force, let snapshot, !snapshot.isStale {
            state = .loaded
            return
        }

        state = .loading
        do {
            let coordinates = try await resolveCoordinates()
            let snapshot = try await fetch(latitude: coordinates.latitude,
                                           longitude: coordinates.longitude,
                                           placeName: coordinates.name)
            self.snapshot = snapshot
            state = .loaded
        } catch {
            let message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            state = .failed(message)
        }
    }

    /// 清空快照（切换城市后调用）。
    func invalidate() {
        snapshot = nil
        state = .idle
    }

    // MARK: - 坐标解析

    private struct Coordinates {
        var latitude: Double
        var longitude: Double
        var name: String
    }

    /// 优先用定位；被拒绝或不可用时回退到用户手选的城市。
    private func resolveCoordinates() async throws -> Coordinates {
        // 用户手选了城市就优先用它 —— 尊重显式选择，也避免每次都要定位。
        if let manual = WetnessPreferences.manualPlace {
            return Coordinates(latitude: manual.latitude,
                               longitude: manual.longitude,
                               name: manual.name)
        }

        do {
            let location = try await locationProvider.currentLocation()
            return Coordinates(latitude: location.coordinate.latitude,
                               longitude: location.coordinate.longitude,
                               name: "当前位置")
        } catch {
            throw error
        }
    }

    // MARK: - 网络

    private struct OpenMeteoResponse: Decodable {
        struct Current: Decodable {
            let time: String
            let temperature_2m: Double
            let relative_humidity_2m: Double
        }
        let current: Current
        let timezone: String?
    }

    private func fetch(latitude: Double, longitude: Double, placeName: String) async throws -> WeatherSnapshot {
        var components = URLComponents(string: "https://api.open-meteo.com/v1/forecast")
        components?.queryItems = [
            URLQueryItem(name: "latitude", value: String(format: "%.4f", latitude)),
            URLQueryItem(name: "longitude", value: String(format: "%.4f", longitude)),
            URLQueryItem(name: "current", value: "temperature_2m,relative_humidity_2m"),
            URLQueryItem(name: "timezone", value: "auto")
        ]
        guard let url = components?.url else { throw WeatherError.badResponse }

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(from: url)
        } catch {
            throw WeatherError.network(error.localizedDescription)
        }

        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw WeatherError.network("HTTP 状态异常")
        }

        let decoded: OpenMeteoResponse
        do {
            decoded = try JSONDecoder().decode(OpenMeteoResponse.self, from: data)
        } catch {
            throw WeatherError.badResponse
        }

        return WeatherSnapshot(
            temperatureC: decoded.current.temperature_2m,
            relativeHumidity: decoded.current.relative_humidity_2m,
            fetchedAt: .now,
            placeName: placeName,
            sourceDescription: "Open-Meteo · \(decoded.timezone ?? "本地时区")"
        )
    }

    // MARK: - 城市检索（定位不可用时的兜底）

    struct Place: Identifiable, Equatable, Sendable {
        var id: String { "\(name)|\(latitude)|\(longitude)" }
        var name: String
        var admin: String
        var country: String
        var latitude: Double
        var longitude: Double

        var displayName: String {
            [name, admin, country].filter { !$0.isEmpty }.joined(separator: " · ")
        }
    }

    private struct GeocodingResponse: Decodable {
        struct Result: Decodable {
            let name: String
            let latitude: Double
            let longitude: Double
            let country: String?
            let admin1: String?
        }
        let results: [Result]?
    }

    /// 用城市名搜索坐标。中文城市名可以直接搜。
    func searchPlaces(matching query: String) async throws -> [Place] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [] }

        var components = URLComponents(string: "https://geocoding-api.open-meteo.com/v1/search")
        components?.queryItems = [
            URLQueryItem(name: "name", value: trimmed),
            URLQueryItem(name: "count", value: "8"),
            URLQueryItem(name: "language", value: "zh")
        ]
        guard let url = components?.url else { throw WeatherError.badResponse }

        let data: Data
        do {
            (data, _) = try await session.data(from: url)
        } catch {
            throw WeatherError.network(error.localizedDescription)
        }

        guard let decoded = try? JSONDecoder().decode(GeocodingResponse.self, from: data) else {
            throw WeatherError.badResponse
        }

        return (decoded.results ?? []).map {
            Place(name: $0.name,
                  admin: $0.admin1 ?? "",
                  country: $0.country ?? "",
                  latitude: $0.latitude,
                  longitude: $0.longitude)
        }
    }
}

// MARK: - 一次性定位

/// 取一次当前位置就结束。
///
/// 独立成一个类而不是塞进 WeatherService，是因为 CLLocationManager 必须由
/// 一个 NSObject 持有并实现 delegate 回调，混进 @Observable 类里会很难看。
@MainActor
final class OneShotLocationProvider: NSObject, CLLocationManagerDelegate {

    private let manager = CLLocationManager()
    private var continuation: CheckedContinuation<CLLocation, Error>?
    private var isRequesting = false

    override init() {
        super.init()
        manager.delegate = self
        // 只要街区级精度就够算天气了，没必要要精确位置。
        manager.desiredAccuracy = kCLLocationAccuracyKilometer
    }

    /// 当前定位授权状态。
    var authorizationStatus: CLAuthorizationStatus {
        manager.authorizationStatus
    }

    /// 取一次位置。
    func currentLocation() async throws -> CLLocation {
        let status = manager.authorizationStatus
        if status == .denied || status == .restricted {
            throw WeatherError.locationDenied
        }

        return try await withCheckedThrowingContinuation { continuation in
            // 上一次还没结束就再请求会直接失败，这里先把它收掉。
            if let existing = self.continuation {
                existing.resume(throwing: WeatherError.locationUnavailable)
            }
            self.continuation = continuation
            self.isRequesting = true

            if status == .notDetermined {
                manager.requestWhenInUseAuthorization()
            } else {
                manager.requestLocation()
            }
        }
    }

    private func finish(with result: Result<CLLocation, Error>) {
        guard isRequesting, let continuation else { return }
        isRequesting = false
        self.continuation = nil
        continuation.resume(with: result)
    }

    // MARK: Delegate

    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        Task { @MainActor in
            guard self.isRequesting else { return }
            switch status {
            case .authorizedWhenInUse, .authorizedAlways:
                // 刚拿到授权，继续取位置。
                manager.requestLocation()
            case .denied, .restricted:
                self.finish(with: .failure(WeatherError.locationDenied))
            case .notDetermined:
                break
            @unknown default:
                self.finish(with: .failure(WeatherError.locationUnavailable))
            }
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        Task { @MainActor in
            if let location = locations.last {
                self.finish(with: .success(location))
            } else {
                self.finish(with: .failure(WeatherError.locationUnavailable))
            }
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        Task { @MainActor in
            // 定位服务被关闭时 CoreLocation 报 kCLErrorDenied，归到权限问题上更好懂。
            let clError = error as? CLError
            if clError?.code == .denied {
                self.finish(with: .failure(WeatherError.locationDenied))
            } else {
                self.finish(with: .failure(WeatherError.locationUnavailable))
            }
        }
    }
}
