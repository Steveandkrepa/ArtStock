//
//  MaterialFormModel.swift
//  ArtStock — 美术材料余量管理
//
//  建档 / 编辑表单的状态模型。
//  三种来源统一收敛到这里：空白新建、扫码草稿预填、已有档案编辑。
//

import Foundation
import Observation
import SwiftUI

@Observable
final class MaterialFormModel: Identifiable {

    /// 仅供 SwiftUI 的 `.sheet(item:)` 使用，不作为业务标识。
    let id = UUID()

    // MARK: - 字段

    var code: String = ""
    var name: String = ""
    var category: MaterialCategory = .other
    var brand: String = ""
    var specification: String = ""
    var unit: MeasurementUnit = .piece

    var quantity: Double = 0
    var capacity: Double = 0
    var lowStockThreshold: Double = 1

    var location: String = ""
    var supplier: String = ""
    var unitPriceText: String = ""
    var colorHex: String = ""
    var notes: String = ""

    var hasExpiry: Bool = false
    var expiryDate: Date = Calendar.current.date(byAdding: .year, value: 1, to: .now) ?? .now
    var hasOpenedAt: Bool = false
    var openedAt: Date = .now

    var photoData: Data?

    /// 建档时扫到的原始二维码内容。
    var qrPayload: String = ""
    var symbologyRaw: String = ""
    /// 解析来源，用于在表单顶部显示"来自扫码 / 手工录入"。
    var source: PayloadSource?

    /// 操作人。iPad 多人共用时写入流水。
    ///
    /// 默认值取自设置页（`@AppStorage("operatorName")` 写的是同一个 key），
    /// 这样每次建档 / 调整都不必重复填写。
    var operatorName: String = UserDefaults.standard.string(forKey: "operatorName") ?? ""

    /// 扫码解析的提示信息。
    var parseWarnings: [String] = []

    /// 编辑模式下被编辑的档案；nil 表示新建。
    private(set) var editingMaterial: Material?

    // MARK: - 构造

    /// 空白新建。
    init() {}

    /// 从扫码草稿预填。这是「扫码建库」的主路径。
    init(draft: ScannedMaterialDraft) {
        code = draft.code
        name = draft.name ?? ""
        category = draft.category ?? .other
        brand = draft.brand ?? ""
        specification = draft.specification ?? ""
        unit = draft.unit ?? .piece
        quantity = draft.quantity ?? 0
        capacity = draft.capacity ?? 0
        location = draft.location ?? ""
        supplier = draft.supplier ?? ""
        colorHex = draft.colorHex ?? ""
        notes = draft.notes ?? ""
        qrPayload = draft.rawPayload
        symbologyRaw = draft.symbologyRaw
        source = draft.source
        parseWarnings = draft.warnings

        if let price = draft.unitPrice {
            unitPriceText = Fmt.number(price)
        }
        if let expiry = draft.expiryDate {
            hasExpiry = true
            expiryDate = expiry
        }
        if let opened = draft.openedAt {
            hasOpenedAt = true
            openedAt = opened
        }
        if let threshold = draft.lowStockThreshold, threshold > 0 {
            lowStockThreshold = threshold
        } else {
            lowStockThreshold = unit.defaultLowStockThreshold
        }

        // 名称缺失时用编码兜底，避免用户漏填导致列表里全是空白标题。
        if name.isBlank {
            name = draft.suggestedName == draft.code ? "" : draft.suggestedName
        }
    }

    /// 从已有档案进入编辑。
    init(material: Material) {
        editingMaterial = material
        code = material.code
        name = material.name
        category = material.category
        brand = material.brand
        specification = material.specification
        unit = material.unit
        quantity = material.quantity
        capacity = material.capacity
        lowStockThreshold = material.lowStockThreshold
        location = material.location
        supplier = material.supplier
        unitPriceText = material.unitPrice > 0 ? Fmt.number(material.unitPrice) : ""
        colorHex = material.colorHex
        notes = material.notes
        qrPayload = material.qrPayload
        symbologyRaw = material.symbologyRaw
        photoData = material.photoData

        if let expiry = material.expiryDate {
            hasExpiry = true
            expiryDate = expiry
        }
        if let opened = material.openedAt {
            hasOpenedAt = true
            openedAt = opened
        }
    }

    // MARK: - 派生

    var isEditing: Bool { editingMaterial != nil }

    var title: String { isEditing ? "编辑档案" : "新建材料档案" }

    var unitPrice: Double {
        Double(unitPriceText.trimmed.replacingOccurrences(of: ",", with: "")) ?? 0
    }

    /// 表单校验。返回人类可读的问题列表，空数组表示可以保存。
    var validationIssues: [String] {
        var issues: [String] = []

        if code.isBlank { issues.append("编码不能为空，它是二维码与档案的唯一对应关系") }
        if name.isBlank { issues.append("名称不能为空") }
        if quantity < 0 { issues.append("余量不能为负数") }
        if capacity < 0 { issues.append("满量不能为负数") }
        if lowStockThreshold < 0 { issues.append("预警阈值不能为负数") }
        if capacity > 0, quantity > capacity {
            issues.append("余量大于满量，请确认是否填反了")
        }
        if hasExpiry, hasOpenedAt, expiryDate < openedAt {
            issues.append("有效期早于开封日期，请检查")
        }
        if !colorHex.isBlank, Color(hex: colorHex) == nil {
            issues.append("颜色值格式应为 #RRGGBB")
        }

        return issues
    }

    /// 仅包含"阻断保存"的问题（余量与满量不一致这类只是提醒）。
    var blockingIssues: [String] {
        var issues: [String] = []
        if code.isBlank { issues.append("编码不能为空") }
        if name.isBlank { issues.append("名称不能为空") }
        if quantity < 0 || capacity < 0 || lowStockThreshold < 0 { issues.append("数值不能为负数") }
        return issues
    }

    var canSave: Bool { blockingIssues.isEmpty }

    // MARK: - 输出

    /// 生成新档案（未插入 context）。
    func makeMaterial() -> Material {
        Material(
            code: code,
            name: name.trimmed,
            category: category,
            brand: brand.trimmed,
            specification: specification.trimmed,
            unit: unit,
            quantity: quantity.rounded(for: unit),
            capacity: capacity.rounded(for: unit),
            lowStockThreshold: lowStockThreshold.rounded(for: unit),
            location: location.trimmed,
            supplier: supplier.trimmed,
            unitPrice: unitPrice,
            colorHex: colorHex.trimmed,
            expiryDate: hasExpiry ? expiryDate : nil,
            openedAt: hasOpenedAt ? openedAt : nil,
            notes: notes.trimmed,
            qrPayload: qrPayload,
            symbologyRaw: symbologyRaw,
            photoData: photoData
        )
    }

    /// 把表单内容写回已有档案。
    /// - Note: 余量不在这里直接改，必须走 `InventoryService.apply` 留下流水。
    func applyMetadata(to material: Material) {
        material.name = name.trimmed
        material.category = category
        material.brand = brand.trimmed
        material.specification = specification.trimmed
        material.unit = unit
        material.capacity = capacity.rounded(for: unit)
        material.lowStockThreshold = lowStockThreshold.rounded(for: unit)
        material.location = location.trimmed
        material.supplier = supplier.trimmed
        material.unitPrice = unitPrice
        material.colorHex = colorHex.trimmed
        material.expiryDate = hasExpiry ? expiryDate : nil
        material.openedAt = hasOpenedAt ? openedAt : nil
        material.notes = notes.trimmed
        material.photoData = photoData
        material.updatedAt = .now
        // 编码是主键，允许修改但要重新规范化。
        material.code = Material.normalize(code)
        // 二维码内容：编辑时若用户没保留原始码，则清空让它回退到自描述载荷。
        if qrPayload.isBlank {
            material.qrPayload = ""
        }
    }
}
