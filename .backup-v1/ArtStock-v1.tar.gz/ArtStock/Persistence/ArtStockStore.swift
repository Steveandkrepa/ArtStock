//
//  ArtStockStore.swift
//  ArtStock — 美术材料余量管理
//
//  持久化容器工厂。
//
//  重要设计约束（针对 SideStore / 免费 Apple ID 自签名）：
//    · 不使用 CloudKit —— 免费账号没有 iCloud 能力，声明了会导致签名后启动即崩。
//    · 不使用 App Group —— 同理需要 entitlement。
//    · 因此这里把 cloudKitDatabase 与 groupContainer 都显式设为"无"，
//      让 SwiftData 只写 App 沙盒内的本地 SQLite 文件。
//

import Foundation
import SwiftData

/// 启动结果。把"是否降级"作为返回值传递，避免引入可变的全局状态。
struct ArtStockBootstrap {
    let container: ModelContainer
    /// 非 nil 表示磁盘库打开失败、当前跑在内存库上（进程退出即丢数据）。
    let degradedReason: String?

    var isDegraded: Bool { degradedReason != nil }
}

enum ArtStockStore {

    /// 全量模型清单。新增 @Model 后必须登记到这里，否则不会被建表。
    static let schema = Schema([
        Material.self,
        StockEntry.self,
        ScanRecord.self,
        WetnessSession.self
    ])

    // MARK: - 配置

    /// 本地磁盘配置。
    static var localConfiguration: ModelConfiguration {
        ModelConfiguration(
            "ArtStock",
            schema: schema,
            isStoredInMemoryOnly: false,
            allowsSave: true,
            groupContainer: .none,
            cloudKitDatabase: .none
        )
    }

    /// 内存配置，供预览与降级使用。
    static var memoryConfiguration: ModelConfiguration {
        ModelConfiguration(
            "ArtStockMemory",
            schema: schema,
            isStoredInMemoryOnly: true,
            allowsSave: true,
            groupContainer: .none,
            cloudKitDatabase: .none
        )
    }

    // MARK: - 启动

    /// 创建正式容器。
    ///
    /// 数据文件损坏或模型不兼容时**不会崩溃**，而是降级到内存库并回报原因，
    /// 让界面提示用户到设置里重置数据库。
    static func bootstrap() -> ArtStockBootstrap {
        do {
            let container = try ModelContainer(for: schema, configurations: [localConfiguration])
            return ArtStockBootstrap(container: container, degradedReason: nil)
        } catch {
            if let memory = try? ModelContainer(for: schema, configurations: [memoryConfiguration]) {
                return ArtStockBootstrap(
                    container: memory,
                    degradedReason: error.localizedDescription
                )
            }
            // 连内存库都建不起来说明模型定义本身有问题，属于开发期错误。
            fatalError("无法创建 ArtStock 数据容器：\(error)")
        }
    }

    // MARK: - 重置

    /// 删除磁盘上的数据文件，用于设置页的"清空并重建数据库"。
    /// - Returns: 是否全部删除干净（文件本来就不存在也算成功）。
    @discardableResult
    static func destroyLocalStore() -> Bool {
        let fileManager = FileManager.default
        guard let supportURL = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return false
        }

        // SwiftData 默认把 store 放在 Application Support 下，文件名与 ModelConfiguration 名称一致。
        let candidates = [
            "ArtStock.store", "ArtStock.store-shm", "ArtStock.store-wal",
            "default.store", "default.store-shm", "default.store-wal"
        ]

        var succeeded = true
        for name in candidates {
            let url = supportURL.appendingPathComponent(name)
            guard fileManager.fileExists(atPath: url.path) else { continue }
            do {
                try fileManager.removeItem(at: url)
            } catch {
                succeeded = false
            }
        }
        return succeeded
    }
}
