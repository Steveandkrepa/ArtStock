//
//  PreviewData.swift
//  ArtStock — 美术材料余量管理
//
//  预览与首次启动的演示数据。
//

import Foundation
import SwiftData

#if DEBUG
/// SwiftUI 预览用的容器。
@MainActor
enum PreviewData {

    /// 内存容器 + 演示数据。
    static let container: ModelContainer = {
        let container = try! ModelContainer(
            for: ArtStockStore.schema,
            configurations: [ArtStockStore.memoryConfiguration]
        )
        seed(into: container.mainContext)
        return container
    }()

    /// 只建库不填数据，用于测试空状态。
    static let emptyContainer: ModelContainer = {
        try! ModelContainer(
            for: ArtStockStore.schema,
            configurations: [ArtStockStore.memoryConfiguration]
        )
    }()

    /// 写入演示材料与流水。
    static func seed(into context: ModelContext) {
        for material in Material.samples() {
            context.insert(material)

            // 给每条档案补一条建档流水，让历史记录不是空的。
            let entry = StockEntry(
                kind: .initial,
                amount: material.quantity,
                balanceBefore: 0,
                balanceAfter: material.quantity,
                createdAt: material.createdAt,
                note: "建档初始余量",
                operatorName: "系统",
                material: material
            )
            context.insert(entry)
        }

        let payloads: [(String, String, ScanRecordStatus)] = [
            ("ART-PIG-0001", "org.iso.QRCode", .linked),
            ("{\"code\":\"ART-NEW-9001\",\"name\":\"生赭\",\"category\":\"颜料\",\"unit\":\"毫升\",\"quantity\":\"45\",\"capacity\":\"60\"}", "org.iso.QRCode", .pending),
            ("6901234567892", "org.gs1.EAN-13", .created)
        ]

        for (payload, symbology, status) in payloads {
            let parsed = QRPayloadParser.parse(payload: payload, symbologyRaw: symbology)
            let record = ScanRecord(
                payload: payload,
                symbologyRaw: symbology,
                source: parsed.source,
                scannedAt: .now.addingTimeInterval(-Double.random(in: 300...86_400)),
                status: status,
                materialCode: status == .pending ? "" : parsed.code
            )
            context.insert(record)
        }

        try? context.save()
    }
}
#endif
