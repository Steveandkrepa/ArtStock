//
//  ArtStockApp.swift
//  ArtStock — 美术材料余量管理
//
//  iPad 优先的原生美术材料余量管理 App。
//  支持本地二维码扫描识别建库，全部数据留在设备本机。
//

import SwiftData
import SwiftUI

@main
struct ArtStockApp: App {

    /// 容器只创建一次。
    ///
    /// 创建失败时 `ArtStockStore` 会降级到内存库并把原因带出来，
    /// 由设置页提示用户重置数据库——而不是让 App 在启动时崩掉。
    private let bootstrap: ArtStockBootstrap

    init() {
        bootstrap = ArtStockStore.bootstrap()
    }

    var body: some Scene {
        WindowGroup {
            RootView(bootstrap: bootstrap)
        }
        .modelContainer(bootstrap.container)
    }
}
