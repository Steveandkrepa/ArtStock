//
//  RootView.swift
//  ArtStock — 美术材料余量管理
//
//  iPad 三栏布局的骨架。
//
//  栏位职责划分：
//    侧边栏 —— 去哪（库存 / 分类 / 记录 / 工具）
//    中间栏 —— 列表与操作（材料清单、扫码记录、流水、标签、设置）
//    详情栏 —— 检视器（永远显示"当前选中的那一条材料"）
//
//  这样在 iPad 上无论怎么转屏、分屏，右侧始终是同一个语义，
//  用户不需要重新建立空间记忆。
//

import SwiftData
import SwiftUI

struct RootView: View {

    let bootstrap: ArtStockBootstrap

    @Query private var allMaterials: [Material]

    @State private var nav = NavigationModel()
    @State private var columnVisibility: NavigationSplitViewVisibility = .all
    @State private var isShowingScanner = false
    @State private var editorForm: MaterialFormModel?

    var body: some View {
        NavigationSplitView(columnVisibility: $columnVisibility) {
            SidebarView(nav: nav)
        } content: {
            contentColumn
                .navigationSplitViewColumnWidth(min: Theme.contentMinWidth, ideal: 460)
        } detail: {
            detailColumn
                .navigationSplitViewColumnWidth(min: Theme.detailMinWidth, ideal: 620)
        }
        .navigationSplitViewStyle(.balanced)
        .overlay(alignment: .bottomTrailing) {
            scanButton
        }
        .fullScreenCover(isPresented: $isShowingScanner) {
            ScanFlowView()
        }
        .sheet(item: $editorForm) { form in
            MaterialEditorView(form: form) { material in
                // 建档后直接把详情栏切到新档案，符合"扫完就想看看"的直觉。
                if let material { nav.focus(on: material) }
            }
        }
        .task {
            // 首次启动时把演示数据灌进去，让用户一打开就有东西可看可点。
            seedIfEmpty()
        }
    }

    // MARK: - 中间栏

    @ViewBuilder
    private var contentColumn: some View {
        Group {
            switch nav.destination ?? .dashboard {
            case .dashboard:
                DashboardView(nav: nav)

            case .scanHistory:
                ScanHistoryView()

            case .transactions:
                TransactionHistoryView()

            case .labels:
                LabelPreviewView()

            case .settings:
                SettingsView(bootstrap: bootstrap)

            default:
                InventoryBrowserView(nav: nav)
            }
        }
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    editorForm = MaterialFormModel()
                } label: {
                    Label("新建材料", systemImage: "plus")
                }
                .keyboardShortcut("n", modifiers: .command)
                .accessibilityLabel("新建材料档案")
            }
        }
    }

    // MARK: - 详情栏

    @ViewBuilder
    private var detailColumn: some View {
        if let material = selectedMaterial {
            MaterialDetailView(material: material)
                // 切换材料时重建视图，否则详情页内部的 @State（如弹窗）会被带过去。
                .id(material.persistentModelID)
        } else {
            detailPlaceholder
        }
    }

    private var selectedMaterial: Material? {
        guard let id = nav.selectedMaterialID else { return nil }
        return allMaterials.first { $0.persistentModelID == id }
    }

    private var detailPlaceholder: some View {
        ContentUnavailableView {
            Label("选择一条材料", systemImage: "sidebar.right")
        } description: {
            Text("从左侧列表选一条材料查看详情，或者直接扫码建档。")
        } actions: {
            Button {
                isShowingScanner = true
            } label: {
                Label("扫码建库", systemImage: "qrcode.viewfinder")
            }
            .artProminentButton()
            .controlSize(.large)

            if !allMaterials.isEmpty {
                Button {
                    nav.select(.lowStock)
                } label: {
                    Label("查看待补货清单", systemImage: "exclamationmark.triangle")
                }
                .artGlassButton()
            }
        }
    }

    // MARK: - 浮动扫码按钮

    /// iPad 上拇指最难够到的地方是左上角，所以把最高频的动作（扫码）
    /// 做成一枚常驻的浮动按钮放在右下角。
    private var scanButton: some View {
        Button {
            isShowingScanner = true
        } label: {
            Image(systemName: "qrcode.viewfinder")
                .font(.system(size: 26, weight: .semibold))
                .symbolRenderingMode(.hierarchical)
                .frame(width: 66, height: 66)
                .artTintedGlassSurface(tint: Theme.color(for: .pigment), cornerRadius: 33)
        }
        .buttonStyle(.plain)
        .keyboardShortcut("b", modifiers: .command)
        .padding(26)
        .accessibilityLabel("扫码建库")
        .accessibilityHint("按 Command 加 B 也可以呼出")
    }

    // MARK: - 首次启动播种

    private func seedIfEmpty() {
        #if DEBUG
        // 只在开发构建里播种，正式包里保持空库让用户自己建。
        guard allMaterials.isEmpty else { return }
        PreviewData.seed(into: bootstrap.container.mainContext)
        #endif
    }
}

#if DEBUG
#Preview("三栏 · 有数据") {
    RootView(bootstrap: ArtStockBootstrap(container: PreviewData.container, degradedReason: nil))
        .modelContainer(PreviewData.container)
}

#Preview("三栏 · 空库") {
    RootView(bootstrap: ArtStockBootstrap(container: PreviewData.emptyContainer, degradedReason: nil))
        .modelContainer(PreviewData.emptyContainer)
}
#endif
