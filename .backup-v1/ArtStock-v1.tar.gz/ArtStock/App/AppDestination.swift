//
//  AppDestination.swift
//  ArtStock — 美术材料余量管理
//
//  侧边栏目的地。
//
//  刻意放在顶层而不是嵌在 NavigationModel 里：嵌套类型会继承外层
//  @MainActor 的隔离性，导致 InventoryFilter 这类非隔离的纯函数
//  无法读取它的计算属性。
//

import Foundation

enum AppDestination: Hashable, Identifiable {

    case dashboard
    case allMaterials
    case lowStock
    case expiring
    case archived
    case scanHistory
    case transactions
    case labels
    case settings
    case category(MaterialCategory)

    var id: String {
        switch self {
        case .dashboard: return "dashboard"
        case .allMaterials: return "all"
        case .lowStock: return "low"
        case .expiring: return "expiring"
        case .archived: return "archived"
        case .scanHistory: return "scanHistory"
        case .transactions: return "transactions"
        case .labels: return "labels"
        case .settings: return "settings"
        case .category(let category): return "category-\(category.rawValue)"
        }
    }

    var title: String {
        switch self {
        case .dashboard: return "总览"
        case .allMaterials: return "全部材料"
        case .lowStock: return "待补货"
        case .expiring: return "临期提醒"
        case .archived: return "已归档"
        case .scanHistory: return "扫码记录"
        case .transactions: return "出入库流水"
        case .labels: return "标签打印"
        case .settings: return "设置"
        case .category(let category): return category.displayName
        }
    }

    var symbolName: String {
        switch self {
        case .dashboard: return "square.grid.2x2.fill"
        case .allMaterials: return "shippingbox.fill"
        case .lowStock: return "exclamationmark.triangle.fill"
        case .expiring: return "calendar.badge.exclamationmark"
        case .archived: return "archivebox.fill"
        case .scanHistory: return "qrcode.viewfinder"
        case .transactions: return "arrow.left.arrow.right.circle.fill"
        case .labels: return "printer.fill"
        case .settings: return "gearshape.fill"
        case .category(let category): return category.symbolName
        }
    }

    /// 是否在中间栏展示材料清单。
    var showsMaterialBrowser: Bool {
        switch self {
        case .dashboard, .allMaterials, .lowStock, .expiring, .archived, .category:
            return true
        case .scanHistory, .transactions, .labels, .settings:
            return false
        }
    }

    /// 中间栏的副标题。
    var browserSubtitle: String {
        switch self {
        case .dashboard: return "最近更新的材料"
        case .allMaterials: return "全部在库材料"
        case .lowStock: return "余量低于预警阈值"
        case .expiring: return "有效期临近或已过期"
        case .archived: return "已归档，不计入统计"
        case .category(let category): return category.searchAliases.first ?? category.displayName
        default: return ""
        }
    }

    /// 对应的分类（非分类目的地时为 nil）。
    var category: MaterialCategory? {
        if case .category(let category) = self { return category }
        return nil
    }
}
