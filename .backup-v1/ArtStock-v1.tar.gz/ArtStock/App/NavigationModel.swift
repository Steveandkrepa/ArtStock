//
//  NavigationModel.swift
//  ArtStock — 美术材料余量管理
//
//  iPad 三栏导航的状态。用 PersistentIdentifier 而不是模型对象做选中值，
//  因为标识符在数据增删后依然稳定，不会因为对象被重新获取而失配。
//

import Foundation
import Observation
import SwiftData

@MainActor
@Observable
final class NavigationModel {

    /// 当前选中的侧边栏条目。
    var destination: AppDestination? = .dashboard

    /// 中间栏选中的材料。
    var selectedMaterialID: PersistentIdentifier?

    /// 搜索关键词。
    var searchText: String = ""

    /// 排序方式。
    var sortOrder: MaterialSortOrder = .urgency

    /// 余量状态筛选（在分类 / 全部材料视图里生效）。
    var levelFilter: StockLevelFilter = .all

    /// 当前目的地是否展示材料清单。
    var showsMaterialBrowser: Bool {
        (destination ?? .dashboard).showsMaterialBrowser
    }

    /// 当前目的地的标题。
    var currentTitle: String {
        (destination ?? .dashboard).title
    }

    /// 切到某个目的地。
    func select(_ destination: AppDestination) {
        self.destination = destination
        // 切视图时清掉旧选中，避免详情栏显示与当前列表无关的档案。
        selectedMaterialID = nil
        levelFilter = .all
    }

    /// 打开某条材料的详情（列表点选、扫码后跳转都走这里）。
    func focus(on material: Material) {
        selectedMaterialID = material.persistentModelID
    }

    /// 清空选中。
    func clearSelection() {
        selectedMaterialID = nil
    }
}
