//
//  QRScannerViewController.swift
//  ArtStock — 美术材料余量管理
//
//  AVFoundation 取景会话。选它而不是 VisionKit 的 DataScannerViewController 的原因：
//    · DataScannerViewController 需要 A12 及以上且只在真机可用，且无法在模拟器上给出可读提示；
//    · AVFoundation 可以在模拟器上优雅降级成"无相机 → 手输编码"；
//    · 我们需要完全控制连续扫描的去重逻辑与手电筒。
//
//  所有相机操作都在 sessionQueue 上执行，主线程只负责 UI 状态。
//

import AVFoundation
import UIKit

final class QRScannerViewController: UIViewController {

    /// 识别到二维码时的回调：(原始内容, 符号类型 rawValue)。
    var onCode: ((String, String) -> Void)?

    let controller: ScannerController

    // MARK: - 会话

    private let session = AVCaptureSession()
    private let sessionQueue = DispatchQueue(label: "com.artstock.scanner.session")
    private let metadataOutput = AVCaptureMetadataOutput()

    private var videoDevice: AVCaptureDevice?
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private var isConfigured = false
    private var isConfiguring = false

    // MARK: - 视觉元素

    private let highlightView: UIView = {
        let view = UIView()
        view.layer.borderColor = UIColor.systemGreen.cgColor
        view.layer.borderWidth = 3
        view.layer.cornerRadius = 10
        view.layer.cornerCurve = .continuous
        view.backgroundColor = UIColor.systemGreen.withAlphaComponent(0.16)
        view.isHidden = true
        return view
    }()

    /// 屏幕中央的静态取景提示框。
    private let reticleView: UIView = {
        let view = UIView()
        view.layer.borderColor = UIColor.white.withAlphaComponent(0.85).cgColor
        view.layer.borderWidth = 2
        view.layer.cornerRadius = 20
        view.layer.cornerCurve = .continuous
        view.backgroundColor = .clear
        return view
    }()

    // MARK: - Init

    init(controller: ScannerController) {
        self.controller = controller
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) 未实现")
    }

    // MARK: - 生命周期

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setUpPreviewLayer()
        setUpOverlays()
        registerControllerActions()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        requestAccessAndConfigure()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopSession()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
        layoutOverlays()
        applyVideoRotation()
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate { _ in
            self.previewLayer?.frame = CGRect(origin: .zero, size: size)
            self.layoutOverlays()
        } completion: { _ in
            self.applyVideoRotation()
        }
    }

    // MARK: - 视图搭建

    private func setUpPreviewLayer() {
        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill
        layer.frame = view.bounds
        view.layer.addSublayer(layer)
        previewLayer = layer
    }

    private func setUpOverlays() {
        view.addSubview(reticleView)
        view.addSubview(highlightView)
    }

    private func layoutOverlays() {
        let side = min(view.bounds.width, view.bounds.height) * 0.62
        reticleView.frame = CGRect(
            x: (view.bounds.width - side) / 2,
            y: (view.bounds.height - side) / 2,
            width: side,
            height: side
        )
        reticleView.layer.cornerRadius = 24
    }

    // MARK: - 控制通道

    private func registerControllerActions() {
        controller.startAction = { [weak self] in
            self?.startSession()
        }
        controller.stopAction = { [weak self] in
            self?.stopSession()
        }
        controller.toggleTorchAction = { [weak self] in
            self?.toggleTorch()
        }
    }

    // MARK: - 授权

    private func requestAccessAndConfigure() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            controller.authorization = .authorized
            configureAndStart()

        case .notDetermined:
            controller.authorization = .unknown
            // 外层闭包必须捕获 weak self，否则内层 DispatchQueue.main.async 里的
            // self 是非可选类型，`guard let self` 会报
            // "initializer for conditional binding must have Optional type"。
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    guard let self else { return }
                    if granted {
                        self.controller.authorization = .authorized
                        self.configureAndStart()
                    } else {
                        self.controller.authorization = .denied
                    }
                }
            }

        case .denied, .restricted:
            controller.authorization = .denied

        @unknown default:
            controller.authorization = .denied
        }
    }

    // MARK: - 会话配置

    private func configureAndStart() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if !self.isConfigured {
                self.configureSession()
            }
            guard self.isConfigured else { return }
            if !self.session.isRunning {
                self.session.startRunning()
            }
            DispatchQueue.main.async {
                self.controller.isRunning = self.session.isRunning
            }
        }
    }

    /// - Note: 必须在 sessionQueue 上调用。
    private func configureSession() {
        guard !isConfiguring else { return }
        isConfiguring = true
        defer { isConfiguring = false }

        session.beginConfiguration()
        session.sessionPreset = .high

        // 优先后置广角，iPad 上如果没有后置就退回任意可用摄像头。
        let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
            ?? AVCaptureDevice.default(for: .video)

        guard let device else {
            session.commitConfiguration()
            DispatchQueue.main.async {
                self.controller.authorization = .unavailable
                self.controller.captureError = "未检测到可用摄像头"
            }
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: device)
            guard session.canAddInput(input) else { throw ScannerSetupError.cannotAddInput }
            session.addInput(input)
            videoDevice = device
        } catch {
            session.commitConfiguration()
            DispatchQueue.main.async {
                self.controller.captureError = "无法打开摄像头：\(error.localizedDescription)"
            }
            return
        }

        guard session.canAddOutput(metadataOutput) else {
            session.commitConfiguration()
            DispatchQueue.main.async {
                self.controller.captureError = "无法建立识别输出"
            }
            return
        }
        session.addOutput(metadataOutput)
        metadataOutput.setMetadataObjectsDelegate(self, queue: .main)

        // 只订阅真正支持的符号类型，否则 setMetadataObjectTypes 会抛异常。
        let wanted: [AVMetadataObject.ObjectType] = [
            .qr, .ean13, .ean8, .upce, .code128, .code39, .code93, .itf14,
            .pdf417, .aztec, .dataMatrix
        ]
        let supported = wanted.filter { metadataOutput.availableMetadataObjectTypes.contains($0) }
        metadataOutput.metadataObjectTypes = supported.isEmpty
            ? metadataOutput.availableMetadataObjectTypes
            : supported

        session.commitConfiguration()
        isConfigured = true

        DispatchQueue.main.async {
            self.applyVideoRotation()
            self.controller.isTorchAvailable = device.hasTorch && device.isTorchAvailable
        }
    }

    // MARK: - 启停

    private func startSession() {
        sessionQueue.async { [weak self] in
            guard let self, self.isConfigured, !self.session.isRunning else { return }
            self.session.startRunning()
            DispatchQueue.main.async { self.controller.isRunning = self.session.isRunning }
        }
    }

    private func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self, self.session.isRunning else { return }
            // 关掉手电筒再停会话，避免退出后灯还亮着。
            if let device = self.videoDevice, device.hasTorch, device.torchMode != .off {
                try? device.lockForConfiguration()
                device.torchMode = .off
                device.unlockForConfiguration()
            }
            self.session.stopRunning()
            DispatchQueue.main.async {
                self.controller.isRunning = false
                self.controller.isTorchOn = false
            }
        }
    }

    // MARK: - 手电筒

    private func toggleTorch() {
        sessionQueue.async { [weak self] in
            guard let self,
                  let device = self.videoDevice,
                  device.hasTorch,
                  device.isTorchAvailable else { return }

            let turningOn = device.torchMode == .off
            do {
                try device.lockForConfiguration()
                device.torchMode = turningOn ? .on : .off
                device.unlockForConfiguration()
                DispatchQueue.main.async {
                    self.controller.isTorchOn = turningOn
                }
            } catch {
                DispatchQueue.main.async {
                    self.controller.captureError = "手电筒不可用：\(error.localizedDescription)"
                }
            }
        }
    }

    // MARK: - 旋转

    /// 把视频旋转角对齐当前界面方向。
    ///
    /// 这里刻意不使用已废弃的 `videoOrientation`，也不用 `RotationCoordinator`：
    /// 扫码场景不需要"随重力传感器平滑跟随"，只需要跟随界面方向，
    /// 直接由 windowScene 推导更简单，也不引入 KVO 生命周期问题。
    private func applyVideoRotation() {
        let angle = currentVideoRotationAngle()
        if let connection = previewLayer?.connection, connection.isVideoRotationAngleSupported(angle) {
            connection.videoRotationAngle = angle
        }
        if let connection = metadataOutput.connection(with: .video),
           connection.isVideoRotationAngleSupported(angle) {
            connection.videoRotationAngle = angle
        }
    }

    private func currentVideoRotationAngle() -> CGFloat {
        let orientation = view.window?.windowScene?.interfaceOrientation ?? .portrait
        switch orientation {
        case .portrait: return 90
        case .portraitUpsideDown: return 270
        case .landscapeLeft: return 0
        case .landscapeRight: return 180
        // iOS 26 SDK 给 UIInterfaceOrientation 新增了 .unknown 成员。
        // 这里显式列出它，同时保留 @unknown default 以兼容将来新增的成员：
        // 只写 @unknown default 时，新 SDK 下会报 "switch must be exhaustive"。
        case .unknown: return 90
        @unknown default: return 90
        }
    }

    // MARK: - 高亮

    private func showHighlight(_ rect: CGRect) {
        highlightView.frame = rect.insetBy(dx: -6, dy: -6)
        highlightView.isHidden = false

        UIView.animate(withDuration: 0.15) {
            self.highlightView.alpha = 1
        } completion: { _ in
            UIView.animate(withDuration: 0.45, delay: 0.25) {
                self.highlightView.alpha = 0
            } completion: { _ in
                self.highlightView.isHidden = true
                self.highlightView.alpha = 1
            }
        }
    }
}

// MARK: - 元数据回调

extension QRScannerViewController: AVCaptureMetadataOutputObjectsDelegate {

    func metadataOutput(
        _ output: AVCaptureMetadataOutput,
        didOutput metadataObjects: [AVMetadataObject],
        from connection: AVCaptureConnection
    ) {
        guard let object = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              let payload = object.stringValue,
              !payload.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return
        }

        // 把识别框从"设备坐标系"换算到"预览层坐标系"。
        if let transformed = previewLayer?.transformedMetadataObject(for: object) as? AVMetadataMachineReadableCodeObject {
            showHighlight(transformed.bounds)
        }

        onCode?(payload, object.type.rawValue)
    }
}

// MARK: - 错误

private enum ScannerSetupError: LocalizedError {
    case cannotAddInput

    var errorDescription: String? {
        switch self {
        case .cannotAddInput: return "摄像头输入无法加入会话"
        }
    }
}
