//
//  QRScannerView.swift
//  ArtStock — 美术材料余量管理
//
//  把 AVFoundation 取景控制器包进 SwiftUI。
//

import SwiftUI

struct QRScannerView: UIViewControllerRepresentable {

    /// 相机状态与控制通道。
    let controller: ScannerController

    /// 识别到二维码时回调（主线程）。
    let onCode: (String, String) -> Void

    func makeUIViewController(context: Context) -> QRScannerViewController {
        let viewController = QRScannerViewController(controller: controller)
        viewController.onCode = onCode
        return viewController
    }

    func updateUIViewController(_ uiViewController: QRScannerViewController, context: Context) {
        // 闭包可能随视图重建而变化，每次更新都重新挂上，避免捕获旧的 model。
        uiViewController.onCode = onCode
    }
}
