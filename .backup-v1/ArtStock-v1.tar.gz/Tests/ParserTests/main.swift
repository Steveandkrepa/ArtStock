import Foundation

var passed = 0
var failed = 0

func check(_ label: String, _ condition: Bool, _ detail: @autoclosure () -> String = "") {
    if condition { passed += 1; print("  ✅ \(label)") }
    else { failed += 1; print("  ❌ \(label)\(detail().isEmpty ? "" : "  → \(detail())")") }
}

func eq<T: Equatable>(_ label: String, _ actual: T, _ expected: T) {
    check(label, actual == expected, "actual=\(actual) expected=\(expected)")
}

print("═══ 1. 二维码解析器 ═══")

// --- JSON 完整载荷 ---
do {
    let p = #"{"code":"ART-NEW-9001","name":"生赭","category":"颜料","brand":"Old Holland","spec":"40mL 管装","unit":"毫升","quantity":"45","capacity":"60","location":"颜料柜 A-2","expiry":"2027-06-30"}"#
    let d = QRPayloadParser.parse(payload: p, symbologyRaw: "org.iso.QRCode")
    eq("JSON 来源", d.source, .json)
    eq("JSON code", d.code, "ART-NEW-9001")
    eq("JSON name", d.name, "生赭")
    eq("JSON category", d.category, .pigment)
    eq("JSON brand", d.brand, "Old Holland")
    eq("JSON spec", d.specification, "40mL 管装")
    eq("JSON unit", d.unit, .milliliter)
    eq("JSON quantity", d.quantity, 45)
    eq("JSON capacity", d.capacity, 60)
    eq("JSON location", d.location, "颜料柜 A-2")
    check("JSON expiry", d.expiryDate != nil)
    check("JSON 字段充足", d.isFieldRich)
}

// --- JSON 数值型 + 嵌套 ---
do {
    let p = #"{"material":{"code":"A-2","quantity":12,"unit":"支"}}"#
    let d = QRPayloadParser.parse(payload: p)
    eq("嵌套 JSON code", d.code, "A-2")
    eq("嵌套 JSON quantity", d.quantity, 12)
    eq("嵌套 JSON unit", d.unit, .piece)
}

// --- 键值文本（中文键 + 全角冒号 + 分号） ---
do {
    let p = "编码=ART-KV-001；名称：丙烯颜料\n单位：毫升\n数量=250\n阈值=50"
    let d = QRPayloadParser.parse(payload: p)
    eq("KV 来源", d.source, .keyValue)
    eq("KV code", d.code, "ART-KV-001")
    eq("KV name", d.name, "丙烯颜料")
    eq("KV unit", d.unit, .milliliter)
    eq("KV quantity", d.quantity, 250)
    eq("KV threshold", d.lowStockThreshold, 50)
}

// --- URL：编码在路径末段 ---
do {
    let d = QRPayloadParser.parse(payload: "https://art.example.com/m/ART-URL-9?unit=piece&quantity=12")
    eq("URL 来源", d.source, .url)
    eq("URL 路径取码", d.code, "ART-URL-9")
    eq("URL query unit", d.unit, .piece)
    eq("URL query quantity", d.quantity, 12)
}

// --- URL：显式 code 参数 ---
do {
    let d = QRPayloadParser.parse(payload: "artstock://material/whatever?code=ART-XYZ&name=%E5%A2%A8%E6%B1%81")
    eq("URL code 参数优先", d.code, "ART-XYZ")
    eq("URL 百分号解码", d.name, "墨汁")
}

// --- GS1 括号写法（这是修复前会解析失败的关键用例）---
do {
    let d = QRPayloadParser.parse(payload: "(01)06901234567892(17)270101(10)LOT77")
    eq("GS1 来源", d.source, .gs1)
    eq("GS1 GTIN → code", d.code, "06901234567892")
    eq("GS1 批次", d.batchNumber, "LOT77")
    check("GS1 有效期", d.expiryDate != nil)
}

// --- GS1 紧凑写法 + GS 分隔符 ---
do {
    let p = "0106901234567892\u{1D}10LOT88"
    let d = QRPayloadParser.parse(payload: p)
    eq("GS1 紧凑 code", d.code, "06901234567892")
    eq("GS1 紧凑 batch", d.batchNumber, "LOT88")
}

// --- GS1 纯数字 16 位 ---
do {
    let d = QRPayloadParser.parse(payload: "0106901234567892")
    eq("GS1 16 位 code", d.code, "06901234567892")
}

// --- 关键回归：普通编码绝不能被误判成 GS1 ---
for plain in ["ART-PIG-0001", "ART-01", "6901234567892", "X01Y", "ART-KV-001"] {
    let d = QRPayloadParser.parse(payload: plain)
    eq("普通码不被误判为 GS1 [\(plain)] 来源", d.source, .plain)
    eq("普通码原文保留 [\(plain)]", d.code, plain)
}

// --- 纯文本 ---
do {
    let d = QRPayloadParser.parse(payload: "  art-pig-0009  ")
    eq("纯文本来源", d.source, .plain)
    eq("纯文本去空白并大写", d.code, "ART-PIG-0009")
    eq("纯文本字段数", d.fieldCount, 0)
}

// --- 空 / 空白 ---
do {
    let d = QRPayloadParser.parse(payload: "   ")
    eq("空白码 err", d.code, "")
    check("空白码有警告", !d.warnings.isEmpty)
}

// --- 自家标签识别 ---
do {
    let p = #"{"generator":"ArtStock","version":"1","code":"ART-PIG-0001","name":"群青"}"#
    let d = QRPayloadParser.parse(payload: p, symbologyRaw: "org.iso.QRCode")
    check("自家标签被识别", d.isOwnLabel)
    eq("自家标签 code", d.code, "ART-PIG-0001")
}

// --- 数值带单位后缀 ---
do {
    let d = QRPayloadParser.parse(payload: #"{"code":"A1","quantity":"500ml","capacity":"1L"}"#)
    eq("数值带单位 数量", d.quantity, 500)
    eq("数值带单位 推断单位", d.unit, .milliliter)
    eq("数值带单位 容量", d.capacity, 1000)
}

// --- 色号归一化 ---
do {
    let d = QRPayloadParser.parse(payload: ##"{"code":"A1","color":"#ff0000"}"##)
    eq("色号大写归一", d.colorHex, "#FF0000")
    let d2 = QRPayloadParser.parse(payload: #"{"code":"A1","color":"群青"}"#)
    eq("中文色名映射", d2.colorHex, "#2E5BFF")
}

// --- 有名称无编码 → 警告 ---
do {
    let d = QRPayloadParser.parse(payload: #"{"name":"只有名字"}"#)
    check("无编码时有警告", d.warnings.contains { $0.contains("编码") })
}

// --- 日期多格式 ---
for raw in ["2027-06-30", "2027/06/30", "20270630"] {
    let d = QRPayloadParser.parse(payload: #"{"code":"A1","expiry":"\#(raw)"}"#)
    check("日期解析 [\(raw)]", d.expiryDate != nil)
}

print("\n═══ 2. 分类 / 单位宽松匹配 ═══")
eq("分类 水彩→颜料", MaterialCategory.match("水彩"), .pigment)
eq("分类 颜料→pigment", MaterialCategory.match("颜料"), .pigment)
eq("分类 宣纸→纸张", MaterialCategory.match("宣纸"), .paper)
eq("分类 pigment", MaterialCategory.match("PIGMENT"), .pigment)
eq("分类 未知→nil", MaterialCategory.match("外星材料"), nil)
eq("分类 空→nil", MaterialCategory.match("  "), nil)

eq("单位 ml", MeasurementUnit.match("ml"), .milliliter)
eq("单位 毫升", MeasurementUnit.match("毫升"), .milliliter)
eq("单位 公斤", MeasurementUnit.match("公斤"), .kilogram)
eq("单位 支", MeasurementUnit.match("支"), .piece)
eq("单位 加仑→nil", MeasurementUnit.match("加仑"), nil)

print("\n═══ 3. 格式化 ═══")
eq("number 12.0", Fmt.number(12.0), "12")
eq("number 12.5", Fmt.number(12.5), "12.5")
eq("quantity 120 mL", Fmt.quantity(120, unit: .milliliter), "120 mL")
eq("quantity 3 支", Fmt.quantity(3, unit: .piece), "3 支")
eq("signedQuantity -30", Fmt.signedQuantity(-30, unit: .milliliter), "\u{2212}30 mL")
eq("signedQuantity +30", Fmt.signedQuantity(30, unit: .milliliter), "+30 mL")
eq("signedQuantity 0", Fmt.signedQuantity(0, unit: .piece), "\u{00B1}0 支")
eq("percent 42%", Fmt.percent(0.42), "42%")
eq("currency 68", Fmt.currency(68), "¥68.00")

print("\n═══ 4. 枚举元数据完整性 ═══")
check("所有分类有显示名", MaterialCategory.allCases.allSatisfy { !$0.displayName.isEmpty && !$0.symbolName.isEmpty })
check("所有分类可被自身显示名反查", MaterialCategory.allCases.allSatisfy { MaterialCategory.match($0.displayName) == $0 })
check("所有单位有显示名", MeasurementUnit.allCases.allSatisfy { !$0.displayName.isEmpty && !$0.abbreviation.isEmpty })
check("所有单位可被自身显示名反查", MeasurementUnit.allCases.allSatisfy { MeasurementUnit.match($0.displayName) == $0 })
check("所有分类有颜色", MaterialCategory.allCases.allSatisfy { _ = Theme.color(for: $0); return true })
check("所有余量状态有颜色", StockLevel.allCases.allSatisfy { _ = Theme.color(for: $0); return true })

print("\n═══ 5. 双曲正切式边界（本地 QR 生成 → 解析回环）═══")
do {
    // 模拟 Material.effectiveQRPayload 的输出格式
    let generated = ##"{"brand":"Winsor \u0026 Newton","capacity":"37","category":"颜料","code":"ART-PIG-0001","color":"#2E5BFF","expiry":"2027-09-01","generator":"ArtStock","location":"颜料柜 A-1","name":"艺术家级 群青","price":"68","spec":"37mL 管装","supplier":"美术用品城","unit":"毫升","version":"1"}"##
    let d = QRPayloadParser.parse(payload: generated, symbologyRaw: "org.iso.QRCode")
    check("回环：识别为自家标签", d.isOwnLabel)
    eq("回环：code", d.code, "ART-PIG-0001")
    eq("回环：name", d.name, "艺术家级 群青")
    eq("回环：category", d.category, .pigment)
    eq("回环：unit", d.unit, .milliliter)
    eq("回环：capacity", d.capacity, 37)
    eq("回环：price", d.unitPrice, 68)
    eq("回环：brand 转义", d.brand, "Winsor & Newton")
}


print("\n═══ 6. 单位换算（后加）═══")
do {
    let d = QRPayloadParser.parse(payload: ##"{"code":"A1","quantity":"500ml","capacity":"1L"}"##)
    eq("换算 基准单位取余量", d.unit, .milliliter)
    eq("换算 余量不变", d.quantity, 500)
    eq("换算 容量 1L→1000mL", d.capacity, 1000)
    check("换算 有提示", d.warnings.contains { $0.contains("换算") })
}
do {
    let d = QRPayloadParser.parse(payload: ##"{"code":"A1","unit":"升","quantity":"250ml"}"##)
    eq("显式单位优先", d.unit, .liter)
    eq("显式单位下换算 250ml→0.25L", d.quantity, 0.25)
}
do {
    let d = QRPayloadParser.parse(payload: ##"{"code":"A1","quantity":"500ml","capacity":"300g"}"##)
    check("跨量纲 有警告", d.warnings.contains { $0.contains("量纲") })
    eq("跨量纲 原值保留", d.capacity, 300)
}
do {
    let d = QRPayloadParser.parse(payload: ##"{"code":"A1","unit":"毫升","quantity":"12"}"##)
    eq("无单位提示时按基准单位", d.quantity, 12)
    eq("基准单位来自显式字段", d.unit, .milliliter)
}

print("\n═══════════════════════════════════════")
print("通过 \(passed)  失败 \(failed)")
exit(failed == 0 ? 0 : 1)
