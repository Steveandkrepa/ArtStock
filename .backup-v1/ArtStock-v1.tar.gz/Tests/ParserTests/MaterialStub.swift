// 仅用于类型检查的替身：顶替带 @Model 宏的 Material，提供解析器唯一用到的符号。
import Foundation

final class Material {
    static func normalize(_ raw: String) -> String {
        raw.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    }
}
